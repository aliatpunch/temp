console.log('tiktok.js script loaded');

class TikTokModel {
    constructor() {
        this.ComPort = null;
        this.CurrentUser = null;
        this.LastUsername = "";
        this.SharedData = null;
        this.UserTag = "._7UhW9";
        this.StartStory = false;
        this.msg_user = "";
        this.tag_dict = {};
        this.account_dict = {};
        this.that = this;
        this.image_src = "";
        this.story_set = false;
    }

    CreateComPort() {
        this.ComPort = chrome.runtime.connect({
            name: "tiktok"
        });
        this.ComPort.onMessage.addListener(this.OnMessageReceive.bind(this));

        window.addEventListener("message", (event) => {
            if (event.source != window) return;
            if (event.data.Tag && (event.data.Tag == "SharedData")) {
                this.SharedData = event.data.SharedData;
            }
        }, false);
    }

    OnMessageReceive(msg) {
        console.log(msg);

        if (msg.Tag == "UpdateTikTok") {
            console.log(msg.story);
            const videos = document.getElementsByTagName('a');
            for (let kk = 0; kk < videos.length; kk++) {
                console.log(videos[kk]);
                console.log(videos[kk].getAttribute("class"));
                if (videos[kk].getAttribute("class").includes("result-item")) {
                    console.log(videos[kk].getAttribute("href"));
                    this.SendMessage("TikTokTarget", "target", videos[kk].getAttribute("href"));
                }
            }
        } else if (msg.Tag == "LikeFollow") {
            console.log(msg.story);
            this.SendMessage("DoneTikTok", "target", window.location.href);
            const vid = parseInt(Math.floor(Math.random() * 6) + 1);
            console.log(vid);
            let counter = 0;
            const videos = document.getElementsByTagName('a');
            for (let kk = 0; kk < videos.length; kk++) {
                console.log(counter);
                if (videos[kk].getAttribute("class") && videos[kk].getAttribute("class").includes("video-feed-item")) {
                    counter++;
                    if (counter == vid) {
                        videos[kk].click();
                        setTimeout(() => {
                            this.handleLikeFollow(msg);
                        }, 5000);
                        break;
                    }
                }
            }
        }
    }

    handleLikeFollow(msg) {
        const username = window.location.href.split("/")[3];
        const url = window.location.href;
        let img = "https://instoo.com/logo.png";
        const videos = document.getElementsByTagName('a');
        for (let kk = 0; kk < videos.length; kk++) {
            if (videos[kk].getAttribute("class") && videos[kk].getAttribute("class").includes("user-avatar")) {
                console.log(videos[kk].firstElementChild.firstElementChild.src);
                img = videos[kk].firstElementChild.firstElementChild.src;
                break;
            }
        }

        const msg_data = {
            url: url,
            username: username,
            img: img,
            website: "none",
            twitter: "none",
            sales: 0,
            email: "none",
            connected: "none"
        };
        this.SendMessage("DoneTikTokData", "User", msg_data);

        if (msg.story.StartTikTokFollow && msg.story.FollowedPoolTikTokSize < msg.story.MaxTikTokFollows) {
            const buttons = document.getElementsByTagName('button');
            console.log(buttons);
            for (let jj = 0; jj < buttons.length; jj++) {
                if (buttons[jj].getAttribute("class").includes("follow") && !buttons[jj].innerText.includes("Following")) {
                    buttons[jj].click();
                    break;
                }
            }

            const msg_data_follow = {
                url: url,
                username: username,
                img: img
            };
            this.SendMessage("DoneTikTokFollow", "User", msg_data_follow);
        }

        if (msg.story.StartTikTokLike && msg.story.LikedMediaTikTokSize < msg.story.MaxTikTokLikes) {
            setTimeout(() => {
                const buttons = document.getElementsByTagName('div');
                console.log(buttons);
                for (let jj = 0; jj < buttons.length; jj++) {
                    if (buttons[jj].getAttribute("class") && buttons[jj].getAttribute("class").includes("engagement-icon")) {
                        buttons[jj].click();
                        break;
                    }
                }
                const spans = document.getElementsByTagName('span');
                console.log(spans);
                for (let jj = 0; jj < spans.length; jj++) {
                    if (spans[jj].getAttribute("class") && spans[jj].getAttribute("class").includes("icons like")) {
                        spans[jj].click();
                        break;
                    }
                }

                const msg_data_like = {
                    url: url,
                    username: username,
                    img: img
                };
                this.SendMessage("DoneTikTokLike", "User", msg_data_like);
            }, 4000);
        }
    }

    SendMessage(tag, msgTag, msg) {
        const sendObj = { "Tag": tag };
        sendObj[msgTag] = msg;
        if (typeof this.ComPort != "undefined") {
            this.ComPort.postMessage(sendObj);
        }
    }
}

class TikTokView {
    constructor(controller) {
        this.controller = controller;
        $(document).ready(this.onDocumentReady.bind(this));
    }

    onDocumentReady() {
        this.controller.CreateComPort();
        console.log("SETUp!");
        if (window.location.href.includes("tag")) {
            window.scrollTo(0, document.body.scrollHeight);
        }
    }
}

class TikTokController {
    constructor(model) {
        this.model = model;
    }

    CreateComPort() {
        this.model.CreateComPort();
    }

    SendMessage(tag, msgTag, msg) {
        this.model.SendMessage(tag, msgTag, msg);
    }
}

const model = new TikTokModel();
const controller = new TikTokController(model);
const view = new TikTokView(controller);