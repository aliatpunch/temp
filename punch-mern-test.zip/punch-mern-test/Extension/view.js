window.dataLayer = window.dataLayer || [];
(function (global) {
    var MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ];

    var COLORS = [
        '#4dc9f6',
        '#f67019',
        '#f53794',
        '#537bc4',
        '#acc236',
        '#166a8f',
        '#00a950',
        '#58595b',
        '#8549ba'
    ];

    var Samples = global.Samples || (global.Samples = {});
    var Color = global.Color;

    Samples.utils = {
        srand: function (seed) {
            this._seed = seed;
        },

        rand: function (min, max) {
            var seed = this._seed;
            min = min === undefined ? 0 : min;
            max = max === undefined ? 1 : max;
            this._seed = (seed * 9301 + 49297) % 233280;
            return min + (this._seed / 233280) * (max - min);
        },

        numbers: function (config) {
            var cfg = config || {};
            var min = cfg.min || 0;
            var max = cfg.max || 1;
            var from = cfg.from || [];
            var count = cfg.count || 8;
            var decimals = cfg.decimals || 8;
            var continuity = cfg.continuity || 1;
            var dfactor = Math.pow(10, decimals) || 0;
            var data = [];
            var i, value;

            for (i = 0; i < count; ++i) {
                value = (from[i] || 0) + this.rand(min, max);
                if (this.rand() <= continuity) {
                    data.push(Math.round(dfactor * value) / dfactor);
                } else {
                    data.push(null);
                }
            }

            return data;
        },

        labels: function (config) {
            var cfg = config || {};
            var min = cfg.min || 0;
            var max = cfg.max || 100;
            var count = cfg.count || 8;
            var step = (max - min) / count;
            var decimals = cfg.decimals || 8;
            var dfactor = Math.pow(10, decimals) || 0;
            var prefix = cfg.prefix || '';
            var values = [];
            var i;

            for (i = min; i < max; i += step) {
                values.push(prefix + Math.round(dfactor * i) / dfactor);
            }

            return values;
        },

        months: function (config) {
            var cfg = config || {};
            var count = cfg.count || 12;
            var section = cfg.section;
            var values = [];
            var i, value;

            for (i = 0; i < count; ++i) {
                value = MONTHS[Math.ceil(i) % 12];
                values.push(value.substring(0, section));
            }

            return values;
        },

        color: function (index) {
            return COLORS[index % COLORS.length];
        },

        transparentize: function (color, opacity) {
            var alpha = opacity === undefined ? 0.5 : 1 - opacity;
            return Color(color).alpha(alpha).rgbString();
        }
    };

    // DEPRECATED
    window.randomScalingFactor = function () {
        return Math.round(Samples.utils.rand(-100, 100));
    };
    Samples.utils.srand(Date.now());
}(this));

$(document).on('change', '#minPhoto', function (event) {
    d = document.getElementById("minPhoto").value;
    SendMessage("minPhoto", "minPhoto", d);


});

$(document).on('change', '#maxFollower', function (event) {
    d = document.getElementById("maxFollower").value;
    SendMessage("maxFollowers", "maxFollowers", d);


});

$(document).on('change', '#minFollower', function (event) {
    d = document.getElementById("minFollower").value;
    SendMessage("minFollowers", "minFollowers", d);


});

$(document).on('change', '#minFollowing', function (event) {
    d = document.getElementById("minFollowing").value;
    SendMessage("minFollowing", "minFollowing", d);


});
$(document).on('change', '#maxFollowing', function (event) {
    d = document.getElementById("maxFollowing").value;
    SendMessage("maxFollowing", "maxFollowing", d);


});
$(document).on('click', '#whitelist-user', function (event) {
    var user = prompt("Please enter the username exactly");
    if (user) {
        var split_users = user.split(",");
        for (var kk = 0; kk < split_users.length; kk++) {
            SendMessage("AddUserToWhitelistName", "username", split_users[kk].split(',').join('').split(' ').join('').split('@').join(''));
        }

        $("#add-user-results").empty();
        $("#add-user-search").val("");
    }

});

$(document).on('click', '.remove-user-whitelist', function (event) {

    RemoveWhitelistedUser(this);

});

$(document).on('click', '.add-whitelist-user', function (event) {




    AddUserToWhitelist(this);
});
$(document).on('click', '#whitelist-clear', function (event) {
    SendMessage("ClearWhite", "", "");

});
$(document).on('click', '#clear-filter', function (event) {
    SendMessage("ClearFilters", "user", "");
});
$(document).on('click', '#add-filter', function (event) {
    var new_blacklist = prompt("Please enter a word to add it to the fitlers:");
    if (new_blacklist && new_blacklist.includes(",")) {
        var split = new_blacklist.split(",");
        for (var kk = 0; kk < split.length; kk++) {
            SendMessage("AddToFilters", "user", split[kk].split("@").join(""));

        }

    } else if (new_blacklist.includes(" ")) {
        var split = new_blacklist.split(" ");
        for (var kk = 0; kk < split.length; kk++) {
            SendMessage("AddToFilters", "user", split[kk].split("@").join(""));

        }

    } else {

        SendMessage("AddToFilters", "user", new_blacklist.split("@").join(""));
    }

    var followers_string = "";
    for (var kk = 0; kk < user_followers.length; kk++) {
        followers_string += user_followers[kk] + ", ";

    }
    var ideal_targets_string = "";

    for (var kk = 0; kk < IdealTargets.length; kk++) {
        ideal_targets_string += IdealTargets[kk].username + " followers: " + IdealTargets[kk].followers + "<br> ";

    }

    var blacklist_string = "";

    for (var kk = 0; kk < blacklist.length; kk++) {
        blacklist_string += blacklist[kk] + ",  ";

    }


    var filter_string = "";

    for (var kk = 0; kk < filters.length; kk++) {
        filter_string += filters[kk] + ",  ";

    }
    $("#followers_list").html("Followers " + user_followers.length + "/" + follow_count_num + ": " + followers_string + "<br>");
    $("#activity_log").html("<br>Activity Log: <br>" + activity_log);
    $("#blacklist").html("<br>Blacklist of profiles to never re-visit:  <br>" + blacklist_string);
    $("#filters").html("<br>Words to avoid in bio text and photo content:  <br>" + filter_string);

    $("#IdealTargets").html("<br>Ideal Account Targets: <br>" + ideal_targets_string);


});


$(document).on('click', '#add-blacklist', function (event) {
    var new_blacklist = prompt("Please enter a username exactly to add it to the blacklist:");
    if (new_blacklist && new_blacklist.includes(",")) {
        var split = new_blacklist.split(",");
        for (var kk = 0; kk < split.length; kk++) {
            SendMessage("AddToBlacklist", "user", split[kk].split("@").join(""));

        }

    } else if (new_blacklist.includes(" ")) {
        var split = new_blacklist.split(" ");
        for (var kk = 0; kk < split.length; kk++) {
            SendMessage("AddToBlacklist", "user", split[kk].split("@").join(""));

        }

    } else {

        SendMessage("AddToBlacklist", "user", new_blacklist.split("@").join(""));
    }

    var followers_string = "";
    for (var kk = 0; kk < user_followers.length; kk++) {
        followers_string += user_followers[kk] + ", ";

    }
    var ideal_targets_string = "";

    for (var kk = 0; kk < IdealTargets.length; kk++) {
        ideal_targets_string += IdealTargets[kk].username + " followers: " + IdealTargets[kk].followers + "<br> ";

    }

    var blacklist_string = "";

    for (var kk = 0; kk < blacklist.length; kk++) {
        blacklist_string += blacklist[kk] + ",  ";

    }


    var filter_string = "";

    for (var kk = 0; kk < filters.length; kk++) {
        filter_string += filters[kk] + ",  ";

    }
    $("#followers_list").html("Followers " + user_followers.length + "/" + follow_count_num + ": " + followers_string + "<br>");
    $("#activity_log").html("<br>Activity Log: <br>" + activity_log);
    $("#blacklist").html("<br>Blacklist of profiles to never re-visit:  <br>" + blacklist_string);
    $("#filters").html("<br>Words to avoid in bio text and photo content:  <br>" + filter_string);

    $("#IdealTargets").html("<br>Ideal Account Targets: <br>" + ideal_targets_string);



});

$(document).ready(function() {

    $("#userLogin").show();
  
    CreateComPort();
    $("#starttiktok").parent().removeClass("hide");

    $("#startinstagram").parent().addClass("active");
    $("#starttiktok").parent().removeClass("active");
    $(document).on('click', '.remove-user-whitelist', function(event) {

        RemoveWhitelistedUser(this);

    });
    $("#userLogin").click(function() {
        SendMessage("userLogin", "", "");

    });
    SendMessage("GetUserStats", "", "");

    setInterval(function() {
        if(hoursLeft > 0){
        SendMessage("refreshStats", "", "");
    }
        if (roughSizeOfObject(cloud_db) < 15000000) {


          
            
        }

    }, 1000 * 60 * 60)

    setInterval(function() {

        if (update_interval) {
            updated_cloud = true;
            update_interval = false;
        }

    }, 1000 * 60)




    $(document).on('click', '.add-whitelist-user', function(event) {




        AddUserToWhitelist(this);
    });
    $(document).on('click', '#whitelist-clear', function(event) {
        SendMessage("ClearWhite", "", "");

    });
    $("#cloud-backup").click(function() {

        alert("Settings saved to cloud!");
        if (roughSizeOfObject(cloud_db) < 15000000) {
           
        }

    });
    $("#cloud-clear").click(function() {
        SendMessage("ResetAll", "", "");

        alert("Cloud backup cleared!");
      

        SendMessage("ResetAll", "", "");

    });




    version = chrome.runtime.getManifest().version;

    $('#version').attr('name', version);
    $("#sidebar-wrapper").show();
    setTimeout(function() {
        var buttons = document.getElementsByTagName('div');
        for (var kk = 0; kk < buttons.length; kk++) {

            buttons[kk].classList.remove("hide");
        }
        version = chrome.runtime.getManifest().version;

        $('#version').attr('name', version);
        $("#sidebar-wrapper").show();

    }, 5000);
    setTimeout(function() {
        var buttons = document.getElementsByTagName('div');
        for (var kk = 0; kk < buttons.length; kk++) {

            buttons[kk].classList.remove("hide");
        }
        version = chrome.runtime.getManifest().version;

        $('#version').attr('name', version);
        $("#sidebar-wrapper").show();

    }, 10000);



    $(".backup_picture").on("error", function() {
        $(this).attr('src', 'icon.png');
    });
    user_plan = $("#plan").attr("name");
    $("#sidebar-mosaic").click(function() {
        var win = window.open('https://tagmosaic.com', '_blank');
        win.focus();
    });
    $("#overlay").show();

    $("#sidebar-home-tinder2").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("tinder.html", function() {

            dashboardMode = 3;

            var data2 = [];
            if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                data2 = [];
            }
            var chart_data = null;
            chart_data = [];
            var minimum = 10000;
            var labels = [];
            var min = 10000000;
            var max = 0;


            for (var index = 0; index < data2.length; index++) {
                var obj = data2[index];
                if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                    chart_data.push(
                        parseInt(obj.followers)
                    );
                    if (obj.followers > max) {
                        max = obj.followers;
                    }

                    if (obj.followers < min) {
                        min = obj.followers;
                    }
                    labels.push(index);
                    if (parseInt(obj.followers) < minimum) {
                        minimum = parseInt(obj.followers);
                    }
                }
            }
            if (chart_data.length > 1) {
                $('#growth').html('You grown ' + max - min + ' followers using Instoo');
            }
            let config = {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Instagram Followers',
                        backgroundColor: window.chartColors.red,
                        borderColor: window.chartColors.red,
                        data: chart_data,
                        fill: false,
                    }]
                },
                options: {
                    maintainAspectRatio: false,

                    responsive: true,
                    title: {
                        display: false,
                        text: 'Followers'
                    },
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    },
                    scales: {
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Hour'
                            }
                        }],
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Followers'
                            }
                        }]
                    }
                }
            };



            mode = "tinder";
            gotAnalytics = false;


            version = chrome.runtime.getManifest().version;

            setTimeout(function() {
   


                if (CurrentUser && CurrentUser.username) {

                    $(".img-current-user").attr("src", CurrentUser.user_pic_url);
                    $(".img-current-user").show();

                }
            }, 240000);


            $('#version').attr('name', version);
            if (user_plan == "lifetime" || user_plan == "linkstories" || user_plan == "instoo2" || user_plan == "linkyear" || user_plan == "instoogold" || user_plan == "instooyearly" || user_plan == "instoopro" || user_plan == "instoogold2") {
                speed_limit = 300;

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);


            }

            $('#media_accounts').tagsinput({
                trimValue: true
            });

            $('#media_tags').tagsinput({
                trimValue: true
            });
            $('#media_tags2').tagsinput({
                trimValue: true
            });

            $('#comment_tags').tagsinput({
                trimValue: true,
                delimiter: ']',
                confirmKeys: [13]
            });

            $('#location_tags').tagsinput({
                trimValue: true
            });



            $('#my-btns .btn').on('click', function(event) {

                var val = $(this).find('input').val();
                if (val == "Fast") {
                    $("#fast").addClass('active');
                    $("#slow").removeClass('active');
                    $("#medium").removeClass('active');

                    if (paid_sub) {

                        SendMessage("SetSpeedTinder", "Speed", 1);

                    } else {
                        buySub();
                    }
                }

                if (val == "Slow") {
                    $("#slow").addClass('active');
                    $("#fast").removeClass('active');
                    $("#medium").removeClass('active');
                    SendMessage("SetSpeedTinder", "Speed", 8);


                }

                if (val == "Medium") {
                    $("#medium").addClass('active');
                    $("#slow").removeClass('active');
                    $("#fast").removeClass('active');
                    SendMessage("SetSpeedTinder", "Speed", 2);


                }

            });

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);



            $("#comment_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; 
                var tagWidth = $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); 
                if (tagWidth > tagsinputWidth) {
                    var tagsText = event.item; 
                    var res = tagsText.substr(0, 5); 
                    $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags;

                SendMessage("AddCommentToListTinder", "TagName", tags);
             

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags;

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveCommentFromListTinder", "TagName", split_tags[kk]);
                    var index = global_tags.indexOf(split_tags[kk]);
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#customRangeTinderComments").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRangeTinderComments").val()) > 1000) {
                        var input = document.getElementById("customRangeTinderComments");
                        input.value = 1000;

                    }
                }

                var follow_tinder_speed = parseInt($("#customRangeTinderComments").val());

                $("#comment_tinder_set").html("DMs/day: " + $("#customRangeTinderComments").val());


                SendMessage("UpdateTinderCommentLimit", "limit", follow_tinder_speed);




            });


            $("#customRangeTinderLikes").change(function() {
                if (paid_sub == false) {
                    if (parseInt($("#customRangeTinderLikes").val()) > 1000) {
                        var input = document.getElementById("customRangeTinderLikes");
                        input.value = 1000;

                    }
                }


                var follow_tinder_speed = parseInt($("#customRange1").val());
                var like_tinder_speed = parseInt($("#customRangeTinderLikes").val());


                $("#like_tinder_set").html("Likes/day: " + $("#customRangeTinderLikes").val());

                SendMessage("UpdateTinderLikeLimit", "limit", like_tinder_speed);

            });

            SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);
            $("#slow").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedTinder", "Num", 3);
                $("#slow").addClass('active');
                $("#fast").removeClass('active');
                $("#medium").removeClass('active');

            });
            $("#medium").click(function() {
                var user_plan = $("#plan").attr("name");




                SendMessage("SetSpeedTinder", "Num", 2);
                $("#medium").addClass('active');
                $("#slow").removeClass('active');
                $("#fast").removeClass('active');

            });
            $("#fast").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedTinder", "Num", 1);



                $("#fast").addClass('active');
                $("#slow").removeClass('active');
                $("#medium").removeClass('active');

            });

            $("#set-follow-tinder-check").click(function() {
                SendMessage("SetFollowTinder", "Value", $(this).is(':checked'));

            });
            $("#set-like-tinder-check").click(function() {
                SendMessage("SetLikeTinder", "Value", $(this).is(':checked'));

            });
            $("#set-follow-check").click(function() {
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                SetFollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
            });
            $("#set-like-check").click(function() {

                SetLikeValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });


            $("#set-story-check").click(function() {
                SetStoryValue($(this).is(':checked'));


                if ($(this).is(':checked') != true) {
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);

                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-comment-check").prop("checked", false);
                    SetCommentValue(false);
                }

            });
            $("#set-comment-check").click(function() {
                SetCommentValue($(this).is(':checked'));

                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

            });
            $(document).on('click', '.remove-user-collect', function() {
                RemoveCollectJobUser(this);

            });
            $(document).on('click', '.remove-tag-collect', function() {
                RemoveCollectJobTagTikTok(this);
            });
            $(document).on('click', '.remove-location-collect', function() {
                RemoveLocationJobTag(this);
            });
            $(document).on('click', '.remove-comment-collect', function() {

                $(this).closest("tr").remove();
                SendMessage("RemoveCommentFromList", "TagName", $(this).attr("user_id"));
                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);
            });




            $("#set-unfollow-check").click(function() {
                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);

                SetUnfollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            SetActiveSidebarItem("#sidebar-home");


            SendMessage("RequestSettings", "", "");

            $("#customRange1").val(maxFollows);
            $("#customRange2").val(maxUnfollows);
            $("#customRange3").val(maxLikes);
            $("#customRange4").val(maxComments);
            $("#customRange5").val(maxStories);
            $("#follow_set").html("Follows/day: " + maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + maxUnfollows);
            $("#like_set").html("Likes/day: " + maxLikes);
            $("#story_set").html("Stories/day: " + maxStories);
            $("#comment_set").html("DMs/day: " + maxComments);


            SetActiveSidebarItem("#sidebar-home-tinder2");

        });
    });
    $("#sidebar-home-crm").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("crm.html", function() {

            dashboardMode = 6;
            $("#validateInstagramFollowers").click(function() {

                SendMessage("validateInstagramFollowers", "Num", "DisplayLikesNum");

            });

            $("#validateFollowers").click(function() {
                var followers_list = prompt("Enter a comma seperated list of followers to rank targets[dogs, dogsofinstagram, dog]:");
                var splits = followers_list.split(",");
                for (var kk = 0; kk < splits.length; kk++) {
                    splits[kk] = splits[kk].split(" ").join("").split("#").join("").split("@").join("");
                }


                for (var kk = 0; kk < instagram_data.length; kk++) {

                    if (splits.includes(instagram_data[kk].username)) {
                        instagram_data[kk].connected = "yes";
                    }
                }
                for (var kk = 0; kk < linkedin_data.length; kk++) {
                    if (splits.includes(linkedin_data[kk].username)) {
                        linkedin_data[kk].connected = "yes";
                    }
                }




                SendMessage("UpdateInstagramData", "instagram_data", instagram_data);
                SendMessage("UpdateLinkedinData", "linkedin_data", linkedin_data);

            });


            $("#validateSales").click(function() {
                var sales_list = prompt("Enter a comma seperated list of sales to rank targets(dogs, 10, dogsofinstagram, 20, dog, 30):");
                var splits = sales_list.split(",");
                for (var kk = 0; kk < splits.length; kk++) {
                    splits[kk] = splits[kk].split(" ").join("").split("#").join("").split("@").join("");
                }
                for (var kk = 0; kk < instagram_data.length; kk++) {
                    if (splits.includes(instagram_data[kk].username)) {
                        instagram_data[kk].sales += parseFloat(splits[splits.indexOf(instagram_data[kk].username) + 1]);
                    }
                }
                for (var kk = 0; kk < linkedin_data.length; kk++) {
                    if (splits.includes(linkedin_data[kk].username)) {
                        linkedin_data[kk].sales += parseFloat(splits[splits.indexOf(linkedin_data[kk].username) + 1]);
                    }
                }


                SendMessage("UpdateInstagramData", "instagram_data", instagram_data);
                SendMessage("UpdateLinkedinData", "linkedin_data", linkedin_data);
            });
            mode = "crm";
            gotAnalytics = false;


            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


            SetActiveSidebarItem("#sidebar-home-crm");

        });
    });




    $("#sidebar-home-link2").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("linkedin.html", function() {

            dashboardMode = 5;

            var data2 = [];
            if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                data2 = [];
            }
            var chart_data = null;
            chart_data = [];
            var minimum = 10000;
            var labels = [];
            var min = 10000000;
            var max = 0;


            for (var index = 0; index < data2.length; index++) {
                var obj = data2[index];
                if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                    chart_data.push(
                        parseInt(obj.followers)
                    );
                    if (obj.followers > max) {
                        max = obj.followers;
                    }

                    if (obj.followers < min) {
                        min = obj.followers;
                    }
                    labels.push(index);
                    if (parseInt(obj.followers) < minimum) {
                        minimum = parseInt(obj.followers);
                    }
                }
            }
            if (chart_data.length > 1) {
                $('#growth').html('You grown ' + max - min + ' followers using Instoo');
            }
            let config = {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Instagram Followers',
                        backgroundColor: window.chartColors.red,
                        borderColor: window.chartColors.red,
                        data: chart_data,
                        fill: false,
                    }]
                },
                options: {
                    maintainAspectRatio: false,

                    responsive: true,
                    title: {
                        display: false,
                        text: 'Followers'
                    },
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    },
                    scales: {
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Hour'
                            }
                        }],
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Followers'
                            }
                        }]
                    }
                }
            };


            mode = "linkedin";
            gotAnalytics = false;


            version = chrome.runtime.getManifest().version;

            setTimeout(function() {

                if (CurrentUser && CurrentUser.username) {

                    $(".img-current-user").attr("src", CurrentUser.user_pic_url);
                    $(".img-current-user").show();

                }
            }, 240000);


            $('#version').attr('name', version);
            if (user_plan == "lifetime" || user_plan == "linkstories" || user_plan == "instoo2" || user_plan == "linkyear" || user_plan == "instoogold" || user_plan == "instooyearly" || user_plan == "instoopro" || user_plan == "instoogold2") {
                speed_limit = 300;

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);


            }

           


            $('#my-btns .btn').on('click', function(event) {

                var val = $(this).find('input').val();
                if (val == "Fast") {
                    $("#fast").addClass('active');
                    $("#slow").removeClass('active');
                    $("#medium").removeClass('active');

                    if (paid_sub) {

                        SendMessage("SetSpeedLinkedin", "Speed", 1);

                    } else {
                        buySub();
                    }
                }

                if (val == "Slow") {
                    $("#slow").addClass('active');
                    $("#fast").removeClass('active');
                    $("#medium").removeClass('active');
                    SendMessage("SetSpeedLinkedin", "Speed", 8);


                }

                if (val == "Medium") {
                    $("#medium").addClass('active');
                    $("#slow").removeClass('active');
                    $("#fast").removeClass('active');
                    SendMessage("SetSpeedLinkedin", "Speed", 2);


                }

            });
            $('#media_accounts').tagsinput({
                trimValue: true
            });

            $('#media_tags').tagsinput({
                trimValue: true
            });
            $('#media_tags2').tagsinput({
                trimValue: true
            });

            $('#comment_tags').tagsinput({
                trimValue: true,
                delimiter: ']',
                confirmKeys: [13]
            });

            $('#location_tags').tagsinput({
                trimValue: true
            });

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


            $("#media_tags").on('itemAdded', function(event) {

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(" ").join("%20").length > 0) {
                        SendMessage("AddTagToListLinkedin", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(" ").join("%20"));
                        global_tags.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#comment_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; 
                var tagWidth = $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); 
                if (tagWidth > tagsinputWidth) {
                    var tagsText = event.item; 
                    var res = tagsText.substr(0, 5); 
                    $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags;

                SendMessage("AddCommentToListLinkedin", "TagName", tags);
                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags;

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveCommentFromList", "TagName", split_tags[kk]);
                    var index = global_tags.indexOf(split_tags[kk]);
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });
            $("#media_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags.split("#");
                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveTagFromListLinkedin", "TagName", split_tags[kk].split('#').join(''));
                    var index = global_tags.indexOf(split_tags[kk].split('#').join(''));
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#customRangeLinkedinFollows").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRangeLinkedinFollows").val()) > 1000) {
                        var input = document.getElementById("customRangeLinkedinFollows");
                        input.value = 1000;

                    }
                }

                var follow_Linkedin_speed = parseInt($("#customRangeLinkedinFollows").val());
                var like_Linkedin_speed = parseInt($("#customRange3").val());

                $("#follow_Linkedin_set").html("Follows/day: " + $("#customRangeLinkedinFollows").val());


                SendMessage("UpdateLinkedinFollowLimit", "limit", follow_Linkedin_speed);




            });


            $("#customRangeLinkedinLikes").change(function() {
                if (paid_sub == false) {
                    if (parseInt($("#customRangeLinkedinLikes").val()) > 1000) {
                        var input = document.getElementById("customRangeLinkedinLikes");
                        input.value = 1000;

                    }
                }


                var follow_Linkedin_speed = parseInt($("#customRange1").val());
                var like_Linkedin_speed = parseInt($("#customRangeLinkedinLikes").val());


                $("#like_Linkedin_set").html("Likes/day: " + $("#customRangeLinkedinLikes").val());

                SendMessage("UpdateLinkedinLikeLimit", "limit", like_Linkedin_speed);

            });

            SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);

            $("#export_linkedin").click(function() {
                var json = linkedin_data
                for (var kk = 0; kk < json.length; kk++) {
                    json[kk].html = "";
                }


                var fields = Object.keys(json)
                var replacer = function(key, value) {
                    return value === null ? '' : value
                }
                var csv = json.map(function(row) {
                    return fields.map(function(fieldName) {
                        return JSON.stringify(row[fieldName], replacer)
                    }).join(',')
                })
                csv.unshift(fields.join(',')) // add header column
                csv = csv.join('\r\n');
                SendMessage("DownloadJson", "url", linkedin_data);

            });
            $("#slow").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedLinkedin", "Num", 3);
                $("#slow").addClass('active');
                $("#fast").removeClass('active');
                $("#medium").removeClass('active');

            });
            $("#medium").click(function() {
                var user_plan = $("#plan").attr("name");




                SendMessage("SetSpeedLinkedin", "Num", 2);
                $("#medium").addClass('active');
                $("#slow").removeClass('active');
                $("#fast").removeClass('active');

            });
            $("#fast").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedLinkedin", "Num", 1);



                $("#fast").addClass('active');
                $("#slow").removeClass('active');
                $("#medium").removeClass('active');

            });

            $("#set-follow-Linkedin-check").click(function() {
                SendMessage("SetFollowLinkedin", "Value", $(this).is(':checked'));

            });
            $("#set-like-Linkedin-check").click(function() {
                SendMessage("SetLikeLinkedin", "Value", $(this).is(':checked'));

            });
            $("#set-follow-check").click(function() {
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                SetFollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
            });
            $("#set-like-check").click(function() {

                SetLikeValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            $("#set-Linkedin-check").click(function() {
                SetLinkedinValue($(this).is(':checked'));
                $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> To automate Linkedin, open Linkedin.com in a new tab, then log in. Instoo will use your hashtags to like/follow automatically, so add some hashtags.<br> Linkedin is growing 2x faster than Instagram, so it's a useful platform to crosspromote both. Simply add a link to your Instagram in Linkedin bios/videos, or add Linkedin links in Instagram. Let us know how this new feature works for you! :)<br></div>");

            });

            $("#set-story-check").click(function() {
                SetStoryValue($(this).is(':checked'));


                if ($(this).is(':checked') != true) {
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);

                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-comment-check").prop("checked", false);
                    SetCommentValue(false);
                }

            });
            $("#set-comment-check").click(function() {
                SetCommentValue($(this).is(':checked'));

                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

            });
            $(document).on('click', '.remove-user-collect', function() {
                RemoveCollectJobUser(this);

            });
            $(document).on('click', '.remove-tag-collect', function() {
                RemoveCollectJobTagLinkedin(this);
            });
            $(document).on('click', '.remove-location-collect', function() {
                RemoveLocationJobTag(this);
            });
            $(document).on('click', '.remove-comment-collect', function() {

                $(this).closest("tr").remove();
                SendMessage("RemoveCommentFromList", "TagName", $(this).attr("user_id"));
                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);
            });




            $("#set-unfollow-check").click(function() {
                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);

                SetUnfollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            SetActiveSidebarItem("#sidebar-home");


            SendMessage("RequestSettings", "", "");

            $("#customRange1").val(maxFollows);
            $("#customRange2").val(maxUnfollows);
            $("#customRange3").val(maxLikes);
            $("#customRange4").val(maxComments);
            $("#customRange5").val(maxStories);
            $("#follow_set").html("Follows/day: " + maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + maxUnfollows);
            $("#like_set").html("Likes/day: " + maxLikes);
            $("#story_set").html("Stories/day: " + maxStories);
            $("#comment_set").html("DMs/day: " + maxComments);

            //getFollowers();

            SetActiveSidebarItem("#sidebar-home-link2");

        });
    });


    $("#sidebar-home-tiktok").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("tiktok.html", function() {

            dashboardMode = 1;

            var data2 = [];
            if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                data2 = [];
            }
            var chart_data = null;
            chart_data = [];
            var minimum = 10000;
            var labels = [];
            var min = 10000000;
            var max = 0;


            for (var index = 0; index < data2.length; index++) {
                var obj = data2[index];
                if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                    chart_data.push(
                        parseInt(obj.followers)
                    );
                    if (obj.followers > max) {
                        max = obj.followers;
                    }

                    if (obj.followers < min) {
                        min = obj.followers;
                    }
                    labels.push(index);
                    if (parseInt(obj.followers) < minimum) {
                        minimum = parseInt(obj.followers);
                    }
                }
            }
            if (chart_data.length > 1) {
                $('#growth').html('You grown ' + max - min + ' followers using Instoo');
            }
            let config = {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Instagram Followers',
                        backgroundColor: window.chartColors.red,
                        borderColor: window.chartColors.red,
                        data: chart_data,
                        fill: false,
                    }]
                },
                options: {
                    maintainAspectRatio: false,

                    responsive: true,
                    title: {
                        display: false,
                        text: 'Followers'
                    },
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    },
                    scales: {
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Hour'
                            }
                        }],
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Followers'
                            }
                        }]
                    }
                }
            };


            mode = "tiktok";
            gotAnalytics = false;


            version = chrome.runtime.getManifest().version;

            setTimeout(function() {


                if (CurrentUser && CurrentUser.username) {

                    $(".img-current-user").attr("src", CurrentUser.user_pic_url);
                    $(".img-current-user").show();

                }
            }, 240000);


            $('#version').attr('name', version);
            if (user_plan == "lifetime" || user_plan == "linkstories" || user_plan == "instoo2" || user_plan == "linkyear" || user_plan == "instoogold" || user_plan == "instooyearly" || user_plan == "instoopro" || user_plan == "instoogold2") {
                speed_limit = 300;

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);


            }

            $('#media_accounts').tagsinput({
                trimValue: true
            });

            $('#media_tags').tagsinput({
                trimValue: true
            });
            $('#media_tags2').tagsinput({
                trimValue: true
            });

            $('#comment_tags').tagsinput({
                trimValue: true,
                delimiter: ']',
                confirmKeys: [13]
            });

            $('#location_tags').tagsinput({
                trimValue: true
            });



            $('#my-btns .btn').on('click', function(event) {

                var val = $(this).find('input').val();
                if (val == "Fast") {
                    $("#fast").addClass('active');
                    $("#slow").removeClass('active');
                    $("#medium").removeClass('active');

                    if (paid_sub) {

                        SendMessage("SetSpeedTikTok", "Speed", 1);

                    } else {
                        buySub();
                    }
                }

                if (val == "Slow") {
                    $("#slow").addClass('active');
                    $("#fast").removeClass('active');
                    $("#medium").removeClass('active');
                    SendMessage("SetSpeedTikTok", "Speed", 8);


                }

                if (val == "Medium") {
                    $("#medium").addClass('active');
                    $("#slow").removeClass('active');
                    $("#fast").removeClass('active');
                    SendMessage("SetSpeedTikTok", "Speed", 2);


                }

            });

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


            $("#media_tags").on('itemAdded', function(event) {

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('').length > 0) {
                        SendMessage("AddTagToListTikTok", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                        global_tags.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#comment_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags;

                SendMessage("AddCommentToListTikTok", "TagName", tags);

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags;

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveCommentFromList", "TagName", split_tags[kk]);
                    var index = global_tags.indexOf(split_tags[kk]);
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });
            $("#media_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags.split("#");
                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveTagFromListTikTok", "TagName", split_tags[kk].split('#').join(''));
                    var index = global_tags.indexOf(split_tags[kk].split('#').join(''));
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#customRangeTikTokFollows").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRangeTikTokFollows").val()) > 1000) {
                        var input = document.getElementById("customRangeTikTokFollows");
                        input.value = 1000;

                    }
                }

                var follow_tiktok_speed = parseInt($("#customRangeTikTokFollows").val());
                var like_tiktok_speed = parseInt($("#customRange3").val());

                $("#follow_tiktok_set").html("Follows/day: " + $("#customRangeTikTokFollows").val());


                SendMessage("UpdateTikTokFollowLimit", "limit", follow_tiktok_speed);




            });


            $("#customRangeTikTokLikes").change(function() {
                if (paid_sub == false) {
                    if (parseInt($("#customRangeTikTokLikes").val()) > 1000) {
                        var input = document.getElementById("customRangeTikTokLikes");
                        input.value = 1000;

                    }
                }


                var follow_tiktok_speed = parseInt($("#customRange1").val());
                var like_tiktok_speed = parseInt($("#customRangeTikTokLikes").val());


                $("#like_tiktok_set").html("Likes/day: " + $("#customRangeTikTokLikes").val());

                SendMessage("UpdateTikTokLikeLimit", "limit", like_tiktok_speed);

            });

            SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);
            $("#slow").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedTikTok", "Num", 3);
                $("#slow").addClass('active');
                $("#fast").removeClass('active');
                $("#medium").removeClass('active');

            });
            $("#medium").click(function() {
                var user_plan = $("#plan").attr("name");




                SendMessage("SetSpeedTikTok", "Num", 2);
                $("#medium").addClass('active');
                $("#slow").removeClass('active');
                $("#fast").removeClass('active');

            });
            $("#fast").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedTikTok", "Num", 1);



                $("#fast").addClass('active');
                $("#slow").removeClass('active');
                $("#medium").removeClass('active');

            });

            $("#set-follow-tiktok-check").click(function() {
                SendMessage("SetFollowTikTok", "Value", $(this).is(':checked'));

            });
            $("#set-like-tiktok-check").click(function() {
                SendMessage("SetLikeTikTok", "Value", $(this).is(':checked'));

            });
            $("#set-follow-check").click(function() {
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                SetFollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
            });
            $("#set-like-check").click(function() {

                SetLikeValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            $("#set-tiktok-check").click(function() {
                SetTikTokValue($(this).is(':checked'));
                $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> To automate TikTok, open tiktok.com in a new tab, then log in. Instoo will use your hashtags to like/follow automatically, so add some hashtags.<br> Tiktok is growing 2x faster than Instagram, so it's a useful platform to crosspromote both. Simply add a link to your Instagram in Tiktok bios/videos, or add TikTok links in Instagram. Let us know how this new feature works for you! :)<br></div>");

            });

            $("#set-story-check").click(function() {
                SetStoryValue($(this).is(':checked'));


                if ($(this).is(':checked') != true) {
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);

                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-comment-check").prop("checked", false);
                    SetCommentValue(false);
                }

            });
            $("#set-comment-check").click(function() {
                SetCommentValue($(this).is(':checked'));

                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

            });
            $(document).on('click', '.remove-user-collect', function() {
                RemoveCollectJobUser(this);

            });
            $(document).on('click', '.remove-tag-collect', function() {
                RemoveCollectJobTagTikTok(this);
            });
            $(document).on('click', '.remove-location-collect', function() {
                RemoveLocationJobTag(this);
            });
            $(document).on('click', '.remove-comment-collect', function() {

                $(this).closest("tr").remove();
                SendMessage("RemoveCommentFromList", "TagName", $(this).attr("user_id"));
                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);
            });




            $("#set-unfollow-check").click(function() {
                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);

                SetUnfollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            SetActiveSidebarItem("#sidebar-home");


            SendMessage("RequestSettings", "", "");

            $("#customRange1").val(maxFollows);
            $("#customRange2").val(maxUnfollows);
            $("#customRange3").val(maxLikes);
            $("#customRange4").val(maxComments);
            $("#customRange5").val(maxStories);
            $("#follow_set").html("Follows/day: " + maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + maxUnfollows);
            $("#like_set").html("Likes/day: " + maxLikes);
            $("#story_set").html("Stories/day: " + maxStories);
            $("#comment_set").html("DMs/day: " + maxComments);


            SetActiveSidebarItem("#sidebar-home-tiktok");

        });
    });

    $("#sidebar-home-facebook").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("facebook.html", function() {

            dashboardMode = 7;

            var data2 = [];
            if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                data2 = [];
            }
            var chart_data = null;
            chart_data = [];
            var minimum = 10000;
            var labels = [];
            var min = 10000000;
            var max = 0;


            for (var index = 0; index < data2.length; index++) {
                var obj = data2[index];
                if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                    chart_data.push(
                        parseInt(obj.followers)
                    );
                    if (obj.followers > max) {
                        max = obj.followers;
                    }

                    if (obj.followers < min) {
                        min = obj.followers;
                    }
                    labels.push(index);
                    if (parseInt(obj.followers) < minimum) {
                        minimum = parseInt(obj.followers);
                    }
                }
            }
            if (chart_data.length > 1) {
                $('#growth').html('You grown ' + max - min + ' followers using Instoo');
            }
            let config = {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Instagram Followers',
                        backgroundColor: window.chartColors.red,
                        borderColor: window.chartColors.red,
                        data: chart_data,
                        fill: false,
                    }]
                },
                options: {
                    maintainAspectRatio: false,

                    responsive: true,
                    title: {
                        display: false,
                        text: 'Followers'
                    },
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    },
                    scales: {
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Hour'
                            }
                        }],
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Followers'
                            }
                        }]
                    }
                }
            };

           

            mode = "facebook";
            gotAnalytics = false;


            version = chrome.runtime.getManifest().version;

            setTimeout(function() {
             


                if (CurrentUser && CurrentUser.username) {

                    $(".img-current-user").attr("src", CurrentUser.user_pic_url);
                    $(".img-current-user").show();

                }
            }, 240000);


            $('#version').attr('name', version);
            if (user_plan == "lifetime" || user_plan == "linkstories" || user_plan == "instoo2" || user_plan == "linkyear" || user_plan == "instoogold" || user_plan == "instooyearly" || user_plan == "instoopro" || user_plan == "instoogold2") {
                speed_limit = 300;

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);


            }

            $('#media_accounts').tagsinput({
                trimValue: true
            });

            $('#media_tags').tagsinput({
                trimValue: true
            });
            $('#media_tags2').tagsinput({
                trimValue: true
            });

            $('#comment_tags').tagsinput({
                trimValue: true,
                delimiter: ']',
                confirmKeys: [13]
            });

            $('#location_tags').tagsinput({
                trimValue: true
            });



            $('#my-btns .btn').on('click', function(event) {

                var val = $(this).find('input').val();
                if (val == "Fast") {
                    $("#fast").addClass('active');
                    $("#slow").removeClass('active');
                    $("#medium").removeClass('active');

                    if (paid_sub) {

                        SendMessage("SetSpeedfacebook", "Speed", 1);

                    } else {
                        buySub();
                    }
                }

                if (val == "Slow") {
                    $("#slow").addClass('active');
                    $("#fast").removeClass('active');
                    $("#medium").removeClass('active');
                    SendMessage("SetSpeedfacebook", "Speed", 8);


                }

                if (val == "Medium") {
                    $("#medium").addClass('active');
                    $("#slow").removeClass('active');
                    $("#fast").removeClass('active');
                    SendMessage("SetSpeedfacebook", "Speed", 2);


                }

            });

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


            $("#media_tags").on('itemAdded', function(event) {

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('').length > 0) {
                        SendMessage("AddTagToListfacebook", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                        global_tags.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#media_accounts").on('itemAdded', function(event) {
                console.log("CODES THAT RUS 2");

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_accounts').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_accounts').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('').length > 0) {
                        SendMessage("AddAccountToListfacebook", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                        global_tags.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags;

                SendMessage("AddCommentToListfacebook", "TagName", tags);

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags;

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveCommentFromList", "TagName", split_tags[kk]);
                    var index = global_tags.indexOf(split_tags[kk]);
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });
            $("#media_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags.split("#");
                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveTagFromListfacebook", "TagName", split_tags[kk].split('#').join(''));
                    var index = global_tags.indexOf(split_tags[kk].split('#').join(''));
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#customRangefacebookFollows").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRangefacebookFollows").val()) > 1000) {
                        var input = document.getElementById("customRangefacebookFollows");
                        input.value = 1000;

                    }
                }

                var follow_facebook_speed = parseInt($("#customRangefacebookFollows").val());
                var like_facebook_speed = parseInt($("#customRange3").val());

                $("#follow_facebook_set").html("Friends/day: " + $("#customRangefacebookFollows").val());


                SendMessage("UpdatefacebookFollowLimit", "limit", follow_facebook_speed);




            });


            $("#customRangefacebookLikes").change(function() {
                if (paid_sub == false) {
                    if (parseInt($("#customRangefacebookLikes").val()) > 1000) {
                        var input = document.getElementById("customRangefacebookLikes");
                        input.value = 1000;

                    }
                }


                var follow_facebook_speed = parseInt($("#customRange1").val());
                var like_facebook_speed = parseInt($("#customRangefacebookLikes").val());


                $("#like_facebook_set").html("Likes/day: " + $("#customRangefacebookLikes").val());

                SendMessage("UpdatefacebookLikeLimit", "limit", like_facebook_speed);

            });

            SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);
            $("#slow").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedfacebook", "Num", 3);
                $("#slow").addClass('active');
                $("#fast").removeClass('active');
                $("#medium").removeClass('active');

            });
            $("#medium").click(function() {
                var user_plan = $("#plan").attr("name");




                SendMessage("SetSpeedfacebook", "Num", 2);
                $("#medium").addClass('active');
                $("#slow").removeClass('active');
                $("#fast").removeClass('active');

            });
            $("#fast").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedfacebook", "Num", 1);



                $("#fast").addClass('active');
                $("#slow").removeClass('active');
                $("#medium").removeClass('active');

            });

            $("#set-follow-facebook-check").click(function() {
                SendMessage("SetFollowfacebook", "Value", $(this).is(':checked'));

            });
            $("#set-like-facebook-check").click(function() {
                SendMessage("SetLikefacebook", "Value", $(this).is(':checked'));

            });
            $("#set-follow-check").click(function() {
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                SetFollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
            });
            $("#set-like-check").click(function() {

                SetLikeValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            $("#set-facebook-check").click(function() {
                SetfacebookValue($(this).is(':checked'));
                $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> To automate facebook, open facebook.com in a new tab, then log in. Instoo will use your hashtags to like/follow automatically, so add some hashtags.<br> facebook is growing 2x faster than Instagram, so it's a useful platform to crosspromote both. Simply add a link to your Instagram in facebook bios/videos, or add facebook links in Instagram. Let us know how this new feature works for you! :)<br></div>");

            });

            $("#set-story-check").click(function() {
                SetStoryValue($(this).is(':checked'));


                if ($(this).is(':checked') != true) {
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);

                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-comment-check").prop("checked", false);
                    SetCommentValue(false);
                }

            });
            $("#set-comment-check").click(function() {
                SetCommentValue($(this).is(':checked'));

                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

            });
            $(document).on('click', '.remove-user-collect', function() {
                RemoveCollectJobUser(this);

            });
            $(document).on('click', '.remove-tag-collect', function() {
                RemoveCollectJobTagfacebook(this);
            });
            $(document).on('click', '.remove-location-collect', function() {
                RemoveLocationJobTag(this);
            });
            $(document).on('click', '.remove-comment-collect', function() {

                $(this).closest("tr").remove();
                SendMessage("RemoveCommentFromList", "TagName", $(this).attr("user_id"));
                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);
            });




            $("#set-unfollow-check").click(function() {
                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);

                SetUnfollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            SetActiveSidebarItem("#sidebar-home");


            SendMessage("RequestSettings", "", "");

            $("#customRange1").val(maxFollows);
            $("#customRange2").val(maxUnfollows);
            $("#customRange3").val(maxLikes);
            $("#customRange4").val(maxComments);
            $("#customRange5").val(maxStories);
            $("#follow_set").html("Follows/day: " + maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + maxUnfollows);
            $("#like_set").html("Likes/day: " + maxLikes);
            $("#story_set").html("Stories/day: " + maxStories);
            $("#comment_set").html("DMs/day: " + maxComments);

            //getFollowers();

            SetActiveSidebarItem("#sidebar-home-facebook");

        });
    });


    $("#sidebar-home-pinterest").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("pinterest.html", function() {

            dashboardMode = 6;

            var data2 = [];
            if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                data2 = [];
            }
            var chart_data = null;
            chart_data = [];
            var minimum = 10000;
            var labels = [];
            var min = 10000000;
            var max = 0;


            for (var index = 0; index < data2.length; index++) {
                var obj = data2[index];
                if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                    chart_data.push(
                        parseInt(obj.followers)
                    );
                    if (obj.followers > max) {
                        max = obj.followers;
                    }

                    if (obj.followers < min) {
                        min = obj.followers;
                    }
                    labels.push(index);
                    if (parseInt(obj.followers) < minimum) {
                        minimum = parseInt(obj.followers);
                    }
                }
            }
            if (chart_data.length > 1) {
                $('#growth').html('You grown ' + max - min + ' followers using Instoo');
            }
            let config = {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Instagram Followers',
                        backgroundColor: window.chartColors.red,
                        borderColor: window.chartColors.red,
                        data: chart_data,
                        fill: false,
                    }]
                },
                options: {
                    maintainAspectRatio: false,

                    responsive: true,
                    title: {
                        display: false,
                        text: 'Followers'
                    },
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    },
                    scales: {
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Hour'
                            }
                        }],
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Followers'
                            }
                        }]
                    }
                }
            };

            mode = "pinterest";
            gotAnalytics = false;


            version = chrome.runtime.getManifest().version;

            setTimeout(function() {


                if (CurrentUser && CurrentUser.username) {

                    $(".img-current-user").attr("src", CurrentUser.user_pic_url);
                    $(".img-current-user").show();

                }
            }, 240000);


            $('#version').attr('name', version);
            if (user_plan == "lifetime" || user_plan == "linkstories" || user_plan == "instoo2" || user_plan == "linkyear" || user_plan == "instoogold" || user_plan == "instooyearly" || user_plan == "instoopro" || user_plan == "instoogold2") {
                speed_limit = 300;

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);


            }

            $('#media_accounts').tagsinput({
                trimValue: true
            });

            $('#media_tags').tagsinput({
                trimValue: true
            });
            $('#media_tags2').tagsinput({
                trimValue: true
            });

            $('#comment_tags').tagsinput({
                trimValue: true,
                delimiter: ']',
                confirmKeys: [13]
            });

            $('#location_tags').tagsinput({
                trimValue: true
            });



            $('#my-btns .btn').on('click', function(event) {

                var val = $(this).find('input').val();
                if (val == "Fast") {
                    $("#fast").addClass('active');
                    $("#slow").removeClass('active');
                    $("#medium").removeClass('active');

                    if (paid_sub) {

                        SendMessage("SetSpeedPinterest", "Speed", 1);

                    } else {
                        buySub();
                    }
                }

                if (val == "Slow") {
                    $("#slow").addClass('active');
                    $("#fast").removeClass('active');
                    $("#medium").removeClass('active');
                    SendMessage("SetSpeedPinterest", "Speed", 8);


                }

                if (val == "Medium") {
                    $("#medium").addClass('active');
                    $("#slow").removeClass('active');
                    $("#fast").removeClass('active');
                    SendMessage("SetSpeedPinterest", "Speed", 2);


                }

            });

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


            $("#media_tags").on('itemAdded', function(event) {

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('').length > 0) {
                        SendMessage("AddTagToListPinterest", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                        global_tags.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#comment_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags;

                SendMessage("AddCommentToListPinterest", "TagName", tags);
       

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags;

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveCommentFromList", "TagName", split_tags[kk]);
                    var index = global_tags.indexOf(split_tags[kk]);
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });
            $("#media_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags.split("#");
                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveTagFromListPinterest", "TagName", split_tags[kk].split('#').join(''));
                    var index = global_tags.indexOf(split_tags[kk].split('#').join(''));
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#customRangePinterestFollows").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRangePinterestFollows").val()) > 1000) {
                        var input = document.getElementById("customRangePinterestFollows");
                        input.value = 1000;

                    }
                }

                var follow_pinterest_speed = parseInt($("#customRangePinterestFollows").val());
                var like_pinterest_speed = parseInt($("#customRange3").val());

                $("#follow_pinterest_set").html("Follows/day: " + $("#customRangePinterestFollows").val());


                SendMessage("UpdatePinterestFollowLimit", "limit", follow_pinterest_speed);




            });


            $("#customRangePinterestLikes").change(function() {
                if (paid_sub == false) {
                    if (parseInt($("#customRangePinterestLikes").val()) > 1000) {
                        var input = document.getElementById("customRangePinterestLikes");
                        input.value = 1000;

                    }
                }


                var follow_pinterest_speed = parseInt($("#customRange1").val());
                var like_pinterest_speed = parseInt($("#customRangePinterestLikes").val());


                $("#like_pinterest_set").html("Likes/day: " + $("#customRangePinterestLikes").val());

                SendMessage("UpdatePinterestLikeLimit", "limit", like_pinterest_speed);

            });

            SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);
            $("#slow").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedPinterest", "Num", 3);
                $("#slow").addClass('active');
                $("#fast").removeClass('active');
                $("#medium").removeClass('active');

            });
            $("#medium").click(function() {
                var user_plan = $("#plan").attr("name");




                SendMessage("SetSpeedPinterest", "Num", 2);
                $("#medium").addClass('active');
                $("#slow").removeClass('active');
                $("#fast").removeClass('active');

            });
            $("#fast").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedPinterest", "Num", 1);



                $("#fast").addClass('active');
                $("#slow").removeClass('active');
                $("#medium").removeClass('active');

            });

            $("#set-follow-pinterest-check").click(function() {
                SendMessage("SetFollowPinterest", "Value", $(this).is(':checked'));

            });
            $("#set-like-pinterest-check").click(function() {
                SendMessage("SetLikePinterest", "Value", $(this).is(':checked'));

            });
            $("#set-follow-check").click(function() {
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                SetFollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
            });
            $("#set-like-check").click(function() {

                SetLikeValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });



            $("#set-story-check").click(function() {
                SetStoryValue($(this).is(':checked'));


                if ($(this).is(':checked') != true) {
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);

                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-comment-check").prop("checked", false);
                    SetCommentValue(false);
                }

            });
            $("#set-comment-check").click(function() {
                SetCommentValue($(this).is(':checked'));

                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

            });
            $(document).on('click', '.remove-user-collect', function() {
                RemoveCollectJobUser(this);

            });
            $(document).on('click', '.remove-tag-collect', function() {
                RemoveCollectJobTagPinterest(this);
            });
            $(document).on('click', '.remove-location-collect', function() {
                RemoveLocationJobTag(this);
            });
            $(document).on('click', '.remove-comment-collect', function() {

                $(this).closest("tr").remove();
                SendMessage("RemoveCommentFromList", "TagName", $(this).attr("user_id"));
                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);
            });




            $("#set-unfollow-check").click(function() {
                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);

                SetUnfollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            SetActiveSidebarItem("#sidebar-home");


            SendMessage("RequestSettings", "", "");

            $("#customRange1").val(maxFollows);
            $("#customRange2").val(maxUnfollows);
            $("#customRange3").val(maxLikes);
            $("#customRange4").val(maxComments);
            $("#customRange5").val(maxStories);
            $("#follow_set").html("Follows/day: " + maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + maxUnfollows);
            $("#like_set").html("Likes/day: " + maxLikes);
            $("#story_set").html("Stories/day: " + maxStories);
            $("#comment_set").html("DMs/day: " + maxComments);

            //getFollowers();

            SetActiveSidebarItem("#sidebar-home-pinterest");

        });
    });



    $("#sidebar-home-tw").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("twitter.html", function() {

            dashboardMode = 2;

            var data2 = [];
            if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                data2 = [];
            }
            var chart_data = null;
            chart_data = [];
            var minimum = 10000;
            var labels = [];
            var min = 10000000;
            var max = 0;


            for (var index = 0; index < data2.length; index++) {
                var obj = data2[index];
                if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                    chart_data.push(
                        parseInt(obj.followers)
                    );
                    if (obj.followers > max) {
                        max = obj.followers;
                    }

                    if (obj.followers < min) {
                        min = obj.followers;
                    }
                    labels.push(index);
                    if (parseInt(obj.followers) < minimum) {
                        minimum = parseInt(obj.followers);
                    }
                }
            }
            if (chart_data.length > 1) {
                $('#growth').html('You grown ' + max - min + ' followers using Instoo');
            }
            let config = {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Instagram Followers',
                        backgroundColor: window.chartColors.red,
                        borderColor: window.chartColors.red,
                        data: chart_data,
                        fill: false,
                    }]
                },
                options: {
                    maintainAspectRatio: false,

                    responsive: true,
                    title: {
                        display: false,
                        text: 'Followers'
                    },
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    },
                    hover: {
                        mode: 'nearest',
                        intersect: true
                    },
                    scales: {
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Hour'
                            }
                        }],
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'Followers'
                            }
                        }]
                    }
                }
            };


            mode = "twitter";
            gotAnalytics = false;


            version = chrome.runtime.getManifest().version;

            setTimeout(function() {

                if (CurrentUser && CurrentUser.username) {

                    $(".img-current-user").attr("src", CurrentUser.user_pic_url);
                    $(".img-current-user").show();

                }
            }, 240000);


            $('#version').attr('name', version);
            if (user_plan == "lifetime" || user_plan == "linkstories" || user_plan == "instoo2" || user_plan == "linkyear" || user_plan == "instoogold" || user_plan == "instooyearly" || user_plan == "instoopro" || user_plan == "instoogold2") {
                speed_limit = 300;

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);


            }

            $('#media_accounts').tagsinput({
                trimValue: true
            });

            $('#media_tags').tagsinput({
                trimValue: true
            });
            $('#media_tags2').tagsinput({
                trimValue: true
            });

            $('#comment_tags').tagsinput({
                trimValue: true,
                delimiter: ']',
                confirmKeys: [13]
            });

            $('#location_tags').tagsinput({
                trimValue: true
            });



            $('#my-btns .btn').on('click', function(event) {

                var val = $(this).find('input').val();
                if (val == "Fast") {
                    $("#fast").addClass('active');
                    $("#slow").removeClass('active');
                    $("#medium").removeClass('active');

                    if (paid_sub) {

                        SendMessage("SetSpeedTwitter", "Speed", 1);

                    } else {
                        buySub();
                    }
                }

                if (val == "Slow") {
                    $("#slow").addClass('active');
                    $("#fast").removeClass('active');
                    $("#medium").removeClass('active');
                    SendMessage("SetSpeedTwitter", "Speed", 8);


                }

                if (val == "Medium") {
                    $("#medium").addClass('active');
                    $("#slow").removeClass('active');
                    $("#fast").removeClass('active');
                    SendMessage("SetSpeedTwitter", "Speed", 2);


                }

            });

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


            $("#media_tags").on('itemAdded', function(event) {

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('%20').length > 0) {
                        SendMessage("AddTagToListTwitter", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join('%20'));
                        global_tags.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join('%20'));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#comment_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags;

                SendMessage("AddCommentToListTwitter", "TagName", tags);


                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags;

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveCommentFromList", "TagName", split_tags[kk]);
                    var index = global_tags.indexOf(split_tags[kk]);
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });
            $("#media_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags.split("#");
                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveTagFromListTwitter", "TagName", split_tags[kk].split('#').join(''));
                    var index = global_tags.indexOf(split_tags[kk].split('#').join(''));
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });


            $("#customRangeTwitterFollows").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRangeTwitterFollows").val()) > 1000) {
                        var input = document.getElementById("customRangeTwitterFollows");
                        input.value = 1000;

                    }
                }

                var follow_Twitter_speed = parseInt($("#customRangeTwitterFollows").val());
                var like_Twitter_speed = parseInt($("#customRange3").val());

                $("#follow_Twitter_set").html("Retweets/day: " + $("#customRangeTwitterFollows").val());


                SendMessage("UpdateTwitterFollowLimit", "limit", follow_Twitter_speed);




            });


            $("#customRangeTwitterLikes").change(function() {
                if (paid_sub == false) {
                    if (parseInt($("#customRangeTwitterLikes").val()) > 1000) {
                        var input = document.getElementById("customRangeTwitterLikes");
                        input.value = 1000;

                    }
                }


                var follow_Twitter_speed = parseInt($("#customRange1").val());
                var like_Twitter_speed = parseInt($("#customRangeTwitterLikes").val());


                $("#like_Twitter_set").html("Likes/day: " + $("#customRangeTwitterLikes").val());

                SendMessage("UpdateTwitterLikeLimit", "limit", like_Twitter_speed);

            });

            SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);
            $("#slow").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedTwitter", "Num", 3);
                $("#slow").addClass('active');
                $("#fast").removeClass('active');
                $("#medium").removeClass('active');

            });
            $("#medium").click(function() {
                var user_plan = $("#plan").attr("name");




                SendMessage("SetSpeedTwitter", "Num", 2);
                $("#medium").addClass('active');
                $("#slow").removeClass('active');
                $("#fast").removeClass('active');

            });
            $("#fast").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeedTwitter", "Num", 1);



                $("#fast").addClass('active');
                $("#slow").removeClass('active');
                $("#medium").removeClass('active');

            });

            $("#set-follow-twitter-check").click(function() {
                SendMessage("SetFollowTwitter", "Value", $(this).is(':checked'));
                ////////////console.log();

            });
            $("#set-like-twitter-check").click(function() {
                SendMessage("SetLikeTwitter", "Value", $(this).is(':checked'));

            });
            $("#set-follow-check").click(function() {
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                SetFollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
            });
            $("#set-like-check").click(function() {

                SetLikeValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            $("#set-twitter-check").click(function() {
                SetTwitterValue($(this).is(':checked'));
                $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> To automate Twitter, open Twitter.com in a new tab, then log in. Instoo will use your hashtags to like/follow automatically, so add some hashtags.<br> Twitter is growing 2x faster than Instagram, so it's a useful platform to crosspromote both. Simply add a link to your Instagram in Twitter bios/videos, or add Twitter links in Instagram. Let us know how this new feature works for you! :)<br></div>");

            });

            $("#set-story-check").click(function() {
                SetStoryValue($(this).is(':checked'));


                if ($(this).is(':checked') != true) {
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);

                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-comment-check").prop("checked", false);
                    SetCommentValue(false);
                }

            });
            $("#set-comment-check").click(function() {
                SetCommentValue($(this).is(':checked'));

                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

            });
            $(document).on('click', '.remove-user-collect', function() {
                RemoveCollectJobUser(this);

            });
            $(document).on('click', '.remove-tag-collect', function() {
                RemoveCollectJobTagTwitter(this);
            });
            $(document).on('click', '.remove-location-collect', function() {
                RemoveLocationJobTag(this);
            });
            $(document).on('click', '.remove-comment-collect', function() {

                $(this).closest("tr").remove();
                SendMessage("RemoveCommentFromList", "TagName", $(this).attr("user_id"));
                //  var index = global_tags.indexOf(user_id);
                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);
                //  SendMessage("RemoveCommentFromList", "TagName", );
            });




            $("#set-unfollow-check").click(function() {
                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);

                SetUnfollowValue($(this).is(':checked'));
                if ($(this).is(':checked')) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }

            });

            SetActiveSidebarItem("#sidebar-home");


            SendMessage("RequestSettings", "", "");

            $("#customRange1").val(maxFollows);
            $("#customRange2").val(maxUnfollows);
            $("#customRange3").val(maxLikes);
            $("#customRange4").val(maxComments);
            $("#customRange5").val(maxStories);
            $("#follow_set").html("Follows/day: " + maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + maxUnfollows);
            $("#like_set").html("Likes/day: " + maxLikes);
            $("#story_set").html("Stories/day: " + maxStories);
            $("#comment_set").html("DMs/day: " + maxComments);


            SetActiveSidebarItem("#sidebar-home-tw");

        });
    });
    $("#sidebar-home").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("home.html", function() {


            dashboardMode = 0;

            $("#tiktoksettings").hide();


            mode = "instagram";
            var data2 = user_stats;
            console.log(data2);
            var chart_data = null;
            chart_data = [];
            follower_data = data2;
            var min = 10000000;
            var max = 0;
            var counter = 0;
            if (started) {
                var minimum = 10000;
                var labels = [];
                for (var index = data2.length - 1; index > data2.length - 100; index--) {
                    if (index >= 0) {
                        var obj = data2[index];
                        if (CurrentUser && obj.user_id == CurrentUser.user_id && (chart_data.length < 2 || Math.abs(parseInt(obj.followers) - chart_data[chart_data.length - 1]) < 200)) {
                            chart_data.push(
                                parseInt(obj.followers)
                            );
                            if (obj.followers > max) {
                                max = obj.followers;
                            }

                            if (obj.followers < min) {
                                min = obj.followers;
                            }
                            labels.push(counter);
                            counter++;
                            if (parseInt(obj.followers) < minimum) {
                                minimum = parseInt(obj.followers);
                            }
                        }
                    }
                }
                chart_data.reverse();

                if (chart_data.length > 1) {
                    $('#growth').html(max - min);
                    if (max - min > 100) {
                    }
                }
                let config = {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Instagram Followers',
                            backgroundColor: window.chartColors.red,
                            borderColor: window.chartColors.red,
                            data: chart_data,
                            fill: false,
                        }]
                    },
                    options: {
                        maintainAspectRatio: false,

                        responsive: true,
                        title: {
                            display: false,
                            text: 'Followers'
                        },
                        tooltips: {
                            mode: 'index',
                            intersect: false,
                        },
                        hover: {
                            mode: 'nearest',
                            intersect: true
                        },
                        scales: {
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Hour'
                                }
                            }],
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Folowers'
                                }
                            }]
                        }
                    }
                };

                let ctx = document.getElementById('canvas').getContext('2d');
                ctx.height = 250;

                let myLine = new Chart(ctx, config);
            }
            gotAnalytics = false;

            version = chrome.runtime.getManifest().version;

            setTimeout(function() {

                if (CurrentUser && CurrentUser.username) {

                    $(".img-current-user").attr("src", CurrentUser.user_pic_url);
                    $(".img-current-user").show();

                }
            }, 240000);


            $('#version').attr('name', version);
            if (user_plan == "lifetime" || user_plan == "linkstories" || user_plan == "instoo2" || user_plan == "linkyear" || user_plan == "instoogold" || user_plan == "instooyearly" || user_plan == "instoopro" || user_plan == "instoogold2") {
                speed_limit = 1000;

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);


            } else {


            }


            $('#media_accounts').tagsinput({
                trimValue: true
            });

            $('#media_tags').tagsinput({
                trimValue: true
            });
            $('#media_tags2').tagsinput({
                trimValue: true
            });


            $("#finalstep").click(function() {
                $("#set-story-check").prop("checked", true);
                $("#set-follow-check").prop("checked", true);
                $("#set-like-check").prop("checked", true);

                SetStoryValue(true);
                SetLikeValue(true);
                SetFollowValue(true);

            });
            $('#comment_tags').tagsinput({
                trimValue: true,
                delimiter: ']',
                confirmKeys: [13]
            });

            $('#location_tags').tagsinput({
                trimValue: true
            });



            $('#my-btns .btn').on('click', function(event) {

                var val = $(this).find('input').val();
                if (val == "Fast") {
                    $("#fast").addClass('active');
                    $("#slow").removeClass('active');
                    $("#medium").removeClass('active');

                    if (paid_sub) {

                        SendMessage("SetSpeed", "Speed", 1);

                    } else {
                        buySub();
                    }
                }

                if (val == "Slow") {
                    $("#slow").addClass('active');
                    $("#fast").removeClass('active');
                    $("#medium").removeClass('active');
                    SendMessage("SetSpeed", "Speed", 8);


                }

                if (val == "Medium") {
                    $("#medium").addClass('active');
                    $("#slow").removeClass('active');
                    $("#fast").removeClass('active');
                    SendMessage("SetSpeed", "Speed", 2);


                }

            });



            $(".backup_picture").on("error", function() {
                $(this).attr('src', 'icon.png');
            });



            if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
                $("#progress").attr("src", "disk.gif");
            } else {
                $("#progress").attr("src", "icon.gif");
            }

            if (paid_sub) {
                $("#sub_msg").hide();
            }
            if (paid_sub) {
                $(".sub-user").hide();

                $("#purchase").hide();
                $("#upgrade").hide();

                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);
            } else {


                $("#customRange1").attr("max", speed_limit);
                $("#customRange2").attr("max", speed_limit);
                $("#customRange3").attr("max", speed_limit);

            }

            SetActiveSidebarItem("#sidebar-likes_comments");

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);



            $("#location_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#location_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#location_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('').length > 0) {
                        SendMessage("AddLocationToList", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                        global_locations.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });



            $("#media_tags").on('itemAdded', function(event) {

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags.split(",");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('').length > 0) {
                        SendMessage("AddTagToList", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                        global_tags.push(split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#media_tags2").on('itemAdded', function(event) {


                var tags = event.item;
                var split_tags = tags.split(",");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split('#').join('').split(',').join('').split(' ').join('').length > 0) {
                        SendMessage("AddTagToList", "TagName", split_tags[kk].split('#').join('').split(',').join('').split(' ').join(''));
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemAdded', function(event) {


                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#comment_tags').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }


                var tags = event.item;
                var split_tags = tags;
                SendMessage("AddCommentToList", "TagName", tags);
              

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#comment_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags;

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveCommentFromList", "TagName", split_tags[kk]);
                    var index = global_tags.indexOf(split_tags[kk]);
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });
            $("#media_tags").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveTagFromList", "TagName", split_tags[kk].split('#').join(''));
                    var index = global_tags.indexOf(split_tags[kk].split('#').join(''));
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });
            $("#media_tags2").on('itemRemoved', function(event) {


                var tags = event.item;
                var split_tags = tags.split("#");

                for (var kk = 0; kk < split_tags.length; kk++) {

                    SendMessage("RemoveTagFromList", "TagName", split_tags[kk].split('#').join(''));
                    var index = global_tags.indexOf(split_tags[kk].split('#').join(''));
                    if (index > -1) {
                        global_tags.splice(index, 1);
                    }
                }

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);

            });

            $("#media_accounts").on('itemAdded', function(event) {
                SendMessage("AddAccountToList", "TagName", event.item);

                console.log("CODES THAT RUS 1");

                var tagsinputWidth = 200; // Width of Bootstrap Tags Input.
                var tagWidth = $('#media_accounts').parent().find('.bootstrap-tagsinput span.tag').last().width(); // To get the Width of individual Tag.
                if (tagWidth > tagsinputWidth) {
                    //If Width of the Tag is more than the width of Container then we crop text of the Tag
                    var tagsText = event.item; // To Get Tags Value
                    var res = tagsText.substr(0, 5); // Here I'm displaying only first 5 Characters.(You can give any number)
                    $('#media_accounts').parent().find('.bootstrap-tagsinput span.tag').last().html(res + "..." + '<i class="fas fa-times"></i>');
                }



                var account_name;


                var tags = event.item;
                var split_tags = tags.split(",");

                for (var kk = 0; kk < split_tags.length; kk++) {
                    if (split_tags[kk].split(',').join('').split(' ').join('').split('@').join('').length > 0) {

                        account_name = split_tags[kk].split(',').join('').split(' ').join('').split('@').join('');

                        global_accounts.push(account_name);
                        if (account_name.match(/^[0-9a-z._]+$/) || account_name.includes(".") || account_name.includes("_")) {
                            if (account_name.includes("https://")) {
                                account_name = account_name.split("/")[3];
                            }
                            SendMessage("CollectFromAccount", "account_name", account_name);
                        }



                    }
                }


            });




            $("#media_accounts").on('itemRemoved', function(event) {
                SendMessage("RemoveAccountFromList", "TagName", event.item);
                var index = global_accounts.indexOf(event.item);
                if (index > -1) {
                    global_accounts.splice(index, 1);
                }
                var index = global_tags.indexOf(event.item);
                if (index > -1) {
                    global_tags.splice(index, 1);
                }
                var account_name = event.item;





            });




            $("#customRange5").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRange5").val()) > 10000) {
                        var input = document.getElementById("customRange5");
                        input.value = 10000;

                    }
                }
                follow_speed = parseInt($("#customRange1").val());
                unfollow_speed = parseInt($("#customRange2").val());
                like_speed = parseInt($("#customRange3").val());
                story_speed = parseInt($("#customRange5").val());
                comment_speed = parseInt($("#customRange4").val());


                $("#story_set").html("Stories/day: " + $("#customRange5").val());


                var settings = {
                    FollowSettings: {},
                    UnfollowSettings: {},
                    LikeSettings: {},
                    CommentSettings: {},
                    CollectFollowers: {},
                    CollectFollowings: {},
                    StorySettings: {},
                    TikTokSettings: {}
                };
                settings.FollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.UnfollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowers = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.LikeSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CommentSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.StorySettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };

                settings.TikTokSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.FollowSettings.TimeMin = follow_speed;
                settings.FollowSettings.TimeMax = follow_speed + 10;
                settings.FollowSettings.ErrorTime = 400;

                settings.UnfollowSettings.TimeMin = unfollow_speed;
                settings.UnfollowSettings.TimeMax = unfollow_speed + 10;
                settings.UnfollowSettings.ErrorTime = 400;


                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = like_speed;
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 400;

                settings.StorySettings.TimeMin = story_speed;
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 400;
                settings.CollectFollowers.Pool = 1000;
                settings.CollectFollowers.Interval = 100;
                settings.CollectFollowers.ErrorTime = 200;

                settings.CollectFollowings.Pool = 1000;
                settings.CollectFollowings.Interval = 100;
                settings.CollectFollowings.ErrorTime = 200;


                settings.TikTokSettings.TimeMin = tiktok_speed;
                settings.TikTokSettings.TimeMax = tiktok_speed + 10;
                settings.TikTokSettings.ErrorTime = 400;

                settings.UnfollowAfterDays = UnfollowAfterDays;



                SendMessage("UpdateSettings", "Settings", settings);


                settings.FollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin));
                settings.FollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin)) + 10;
                settings.FollowSettings.ErrorTime = 200;

                settings.UnfollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin));
                settings.UnfollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin)) + 10;
                settings.UnfollowSettings.ErrorTime = 200;

                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.LikeSettings.TimeMin));
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 200;

                settings.StorySettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.StorySettings.TimeMin));
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 200;
                global_settings = settings;

            });
            $("#customRange4").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRange4").val()) > 1000) {
                        var input = document.getElementById("customRange4");
                        input.value = 1000;

                    }
                }
                follow_speed = parseInt($("#customRange1").val());
                unfollow_speed = parseInt($("#customRange2").val());
                like_speed = parseInt($("#customRange3").val());
                story_speed = parseInt($("#customRange5").val());
                comment_speed = parseInt($("#customRange4").val());


                $("#comment_set").html("DMs/day: " + $("#customRange4").val());


                var settings = {
                    FollowSettings: {},
                    UnfollowSettings: {},
                    LikeSettings: {},
                    CommentSettings: {},
                    CollectFollowers: {},
                    CollectFollowings: {},
                    StorySettings: {},
                    TikTokSettings: {}
                };
                settings.FollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.UnfollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowers = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.LikeSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CommentSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.StorySettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };

                settings.TikTokSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.FollowSettings.TimeMin = follow_speed;
                settings.FollowSettings.TimeMax = follow_speed + 10;
                settings.FollowSettings.ErrorTime = 400;

                settings.UnfollowSettings.TimeMin = unfollow_speed;
                settings.UnfollowSettings.TimeMax = unfollow_speed + 10;
                settings.UnfollowSettings.ErrorTime = 400;


                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = like_speed;
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 400;

                settings.StorySettings.TimeMin = story_speed;
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 400;
                settings.CollectFollowers.Pool = 1000;
                settings.CollectFollowers.Interval = 100;
                settings.CollectFollowers.ErrorTime = 200;

                settings.CollectFollowings.Pool = 1000;
                settings.CollectFollowings.Interval = 100;
                settings.CollectFollowings.ErrorTime = 200;


                settings.TikTokSettings.TimeMin = tiktok_speed;
                settings.TikTokSettings.TimeMax = tiktok_speed + 10;
                settings.TikTokSettings.ErrorTime = 400;

                settings.UnfollowAfterDays = UnfollowAfterDays;



                SendMessage("UpdateSettings", "Settings", settings);


                settings.FollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin));
                settings.FollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin)) + 10;
                settings.FollowSettings.ErrorTime = 200;

                settings.UnfollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin));
                settings.UnfollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin)) + 10;
                settings.UnfollowSettings.ErrorTime = 200;

                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.LikeSettings.TimeMin));
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 200;

                settings.StorySettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.StorySettings.TimeMin));
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 200;
                global_settings = settings;

            });

            $("#customRange1").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRange1").val()) > 1000) {
                        var input = document.getElementById("customRange1");
                        input.value = 1000;

                    }
                }

                follow_speed = parseInt($("#customRange1").val());
                unfollow_speed = parseInt($("#customRange2").val());
                like_speed = parseInt($("#customRange3").val());
                story_speed = parseInt($("#customRange5").val());
                comment_speed = parseInt($("#customRange4").val());

                $("#follow_set").html("Follows/day: " + $("#customRange1").val());


                var settings = {
                    FollowSettings: {},
                    UnfollowSettings: {},
                    LikeSettings: {},
                    CommentSettings: {},
                    CollectFollowers: {},
                    CollectFollowings: {},
                    StorySettings: {},
                    TikTokSettings: {}
                };
                settings.FollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.UnfollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowers = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.LikeSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CommentSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.StorySettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.TikTokSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.FollowSettings.TimeMin = follow_speed;
                settings.FollowSettings.TimeMax = follow_speed + 10;
                settings.FollowSettings.ErrorTime = 400;

                settings.UnfollowSettings.TimeMin = unfollow_speed;
                settings.UnfollowSettings.TimeMax = unfollow_speed + 10;
                settings.UnfollowSettings.ErrorTime = 400;

                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = like_speed;
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 400;


                settings.StorySettings.TimeMin = story_speed;
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 400;

                settings.CollectFollowers.Pool = 1000;
                settings.CollectFollowers.Interval = 100;
                settings.CollectFollowers.ErrorTime = 200;

                settings.CollectFollowings.Pool = 1000;
                settings.CollectFollowings.Interval = 100;
                settings.CollectFollowings.ErrorTime = 200;


                settings.TikTokSettings.TimeMin = tiktok_speed;
                settings.TikTokSettings.TimeMax = tiktok_speed + 10;
                settings.TikTokSettings.ErrorTime = 400;
                settings.UnfollowAfterDays = UnfollowAfterDays;



                SendMessage("UpdateSettings", "Settings", settings);

                settings.FollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin));
                settings.FollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin)) + 10;
                settings.FollowSettings.ErrorTime = 200;

                settings.UnfollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin));
                settings.UnfollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin)) + 10;
                settings.UnfollowSettings.ErrorTime = 200;

                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.LikeSettings.TimeMin));
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 200;

                settings.StorySettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.StorySettings.TimeMin));
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 200;

                global_settings = settings;


            });

            $("#customRange2").change(function() {
                if (paid_sub === false) {
                    if (parseInt($("#customRange2").val()) > 1000) {
                        var input = document.getElementById("customRange2");
                        input.value = 1000;

                    }
                }
                follow_speed = parseInt($("#customRange1").val());
                unfollow_speed = parseInt($("#customRange2").val());
                like_speed = parseInt($("#customRange3").val());
                story_speed = parseInt($("#customRange5").val());
                comment_speed = parseInt($("#customRange4").val());

                $("#unfollow_set").html("Unfollows/day: " + $("#customRange2").val());


                var settings = {
                    FollowSettings: {},
                    UnfollowSettings: {},
                    LikeSettings: {},
                    CommentSettings: {},
                    CollectFollowers: {},
                    CollectFollowings: {},
                    StorySettings: {},
                    TikTokSettings: {}
                };
                settings.FollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.UnfollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowers = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.LikeSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CommentSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.StorySettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.TikTokSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.FollowSettings.TimeMin = follow_speed;
                settings.FollowSettings.TimeMax = follow_speed + 10;
                settings.FollowSettings.ErrorTime = 200;

                settings.UnfollowSettings.TimeMin = unfollow_speed;
                settings.UnfollowSettings.TimeMax = unfollow_speed + 10;
                settings.UnfollowSettings.ErrorTime = 200;


                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = like_speed;
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 200;

                settings.StorySettings.TimeMin = story_speed;
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 400;

                settings.CollectFollowers.Pool = 1000;
                settings.CollectFollowers.Interval = 100;
                settings.CollectFollowers.ErrorTime = 200;

                settings.CollectFollowings.Pool = 1000;
                settings.CollectFollowings.Interval = 100;
                settings.CollectFollowings.ErrorTime = 200;


                settings.TikTokSettings.TimeMin = tiktok_speed;
                settings.TikTokSettings.TimeMax = tiktok_speed + 10;
                settings.TikTokSettings.ErrorTime = 400;


                settings.UnfollowAfterDays = UnfollowAfterDays;

                SendMessage("UpdateSettings", "Settings", settings);

                settings.FollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin));
                settings.FollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin)) + 10;
                settings.FollowSettings.ErrorTime = 200;

                settings.UnfollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin));
                settings.UnfollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin)) + 10;
                settings.UnfollowSettings.ErrorTime = 200;

                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.LikeSettings.TimeMin));
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 200;

                settings.StorySettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.StorySettings.TimeMin));
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 200;
                global_settings = settings;


            });

            $("#customRange3").change(function() {
                if (paid_sub == false) {
                    if (parseInt($("#customRange3").val()) > 1000) {
                        var input = document.getElementById("customRange3");
                        input.value = 1000;

                    }
                }

                follow_speed = parseInt($("#customRange1").val());
                unfollow_speed = parseInt($("#customRange2").val());
                like_speed = parseInt($("#customRange3").val());
                story_speed = parseInt($("#customRange5").val());
                comment_speed = parseInt($("#customRange4").val());

                $("#like_set").html("Likes/day: " + $("#customRange3").val());

                var settings = {
                    FollowSettings: {},
                    UnfollowSettings: {},
                    LikeSettings: {},
                    CommentSettings: {},
                    CollectFollowers: {},
                    CollectFollowings: {},
                    StorySettings: {},
                    TikTokSettings: {}
                };
                settings.FollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.UnfollowSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowers = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CollectFollowings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.LikeSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.CommentSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };
                settings.StorySettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };

                settings.TikTokSettings = {
                    TimeMin: 0,
                    TimeMax: 0,
                    ErrorTime: 0
                };

                settings.FollowSettings.TimeMin = follow_speed;
                settings.FollowSettings.TimeMax = follow_speed + 10;
                settings.FollowSettings.ErrorTime = 200;

                settings.UnfollowSettings.TimeMin = unfollow_speed;
                settings.UnfollowSettings.TimeMax = unfollow_speed + 10;
                settings.UnfollowSettings.ErrorTime = 200;

                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = like_speed;
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 200;


                settings.StorySettings.TimeMin = story_speed;
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 400;

                settings.CollectFollowers.Pool = 1000;
                settings.CollectFollowers.Interval = 100;
                settings.CollectFollowers.ErrorTime = 200;

                settings.CollectFollowings.Pool = 1000;
                settings.CollectFollowings.Interval = 100;
                settings.CollectFollowings.ErrorTime = 200;



                settings.TikTokSettings.TimeMin = tiktok_speed;
                settings.TikTokSettings.TimeMax = tiktok_speed + 10;
                settings.TikTokSettings.ErrorTime = 400;



                settings.UnfollowAfterDays = UnfollowAfterDays;

                SendMessage("UpdateSettings", "Settings", settings);


                settings.FollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin));
                settings.FollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.FollowSettings.TimeMin)) + 10;
                settings.FollowSettings.ErrorTime = 200;

                settings.UnfollowSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin));
                settings.UnfollowSettings.TimeMax = Math.floor((16 * 60 * 60) / parseInt(settings.UnfollowSettings.TimeMin)) + 10;
                settings.UnfollowSettings.ErrorTime = 200;

                settings.CommentSettings.TimeMin = comment_speed;
                settings.CommentSettings.TimeMax = 450;
                settings.CommentSettings.ErrorTime = 1800;

                settings.LikeSettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.LikeSettings.TimeMin));
                settings.LikeSettings.TimeMax = like_speed + 10;
                settings.LikeSettings.ErrorTime = 200;

                settings.StorySettings.TimeMin = Math.floor((16 * 60 * 60) / parseInt(settings.StorySettings.TimeMin));
                settings.StorySettings.TimeMax = story_speed + 10;
                settings.StorySettings.ErrorTime = 200;
                global_settings = settings;

            });

            SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);
            $("#slow").click(function() {
                var user_plan = $("#plan").attr("name");

                SendMessage("SetSpeed", "Num", 3);
                $("#slow").addClass('active');
                $("#fast").removeClass('active');
                $("#medium").removeClass('active');

            });
            $("#medium").click(function() {
                var user_plan = $("#plan").attr("name");




                SendMessage("SetSpeed", "Num", 2);
                $("#medium").addClass('active');
                $("#slow").removeClass('active');
                $("#fast").removeClass('active');

            });
            $("#fast").click(function() {
                var user_plan = $("#plan").attr("name");


                SendMessage("SetSpeed", "Num", 1);



                $("#fast").addClass('active');
                $("#slow").removeClass('active');
                $("#medium").removeClass('active');
            });
            $("#set-follow-check").click(function() {
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                SetFollowValue($(this).is(':checked'));
                follow_val = $(this).is(':checked');
                if (follow_val) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
                if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
                    $("#progress").attr("src", "disk.gif");
                } else {
                    $("#progress").attr("src", "icon.gif");
                }

            });
            $("#set-like-check").click(function() {

                SetLikeValue($(this).is(':checked'));
                like_val = $(this).is(':checked');
                if (like_val) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

                if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
                    $("#progress").attr("src", "disk.gif");
                } else {
                    $("#progress").attr("src", "icon.gif");
                }

            });


            $("#set-story-check").click(function() {
                SetStoryValue($(this).is(':checked'));
                like_val = $(this).is(':checked');
                if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
                    $("#progress").attr("src", "disk.gif");
                } else {
                    $("#progress").attr("src", "icon.gif");
                }

                if (like_val != true) {
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);

                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-comment-check").prop("checked", false);
                    SetCommentValue(false);
                }

            });
            $("#set-comment-check").click(function() {
                SetCommentValue($(this).is(':checked'));
                comment_val = $(this).is(':checked');
                if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
                    $("#progress").attr("src", "disk.gif");
                } else {
                    $("#progress").attr("src", "icon.gif");
                }
                if (comment_val) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", status.StartLike);
                }

            });
            $(document).on('click', '.remove-user-collect', function() {
                RemoveCollectJobUser(this);

            });
            $(document).on('click', '.remove-tag-collect', function() {
                RemoveCollectJobTag(this);
            });
            $(document).on('click', '.remove-location-collect', function() {
                RemoveLocationJobTag(this);
            });
            $(document).on('click', '.remove-comment-collect', function() {

                var user_id = $(this).attr("user_id");
                $(this).closest("tr").remove();


                SendMessage("RemoveCommentFromList", "TagName", user_id);
                //  var index = global_tags.indexOf(user_id);

                SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);
                //  SendMessage("RemoveCommentFromList", "TagName", );
            });




            $("#set-unfollow-check").click(function() {
                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);

                SetUnfollowValue($(this).is(':checked'));
                unfollow_val = $(this).is(':checked');
                if (unfollow_val) {
                    SetStoryValue($(this).is(':checked'));
                    $("#set-story-check").prop("checked", true);
                }
                if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
                    $("#progress").attr("src", "disk.gif");
                } else {
                    $("#progress").attr("src", "icon.gif");
                }

            });

            SetActiveSidebarItem("#sidebar-home");



            if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
                $("#progress").attr("src", "disk.gif");
            } else {
                $("#progress").attr("src", "icon.gif");
            }


            SendMessage("RequestSettings", "", "");

            $("#customRange1").val(maxFollows);
            $("#customRange2").val(maxUnfollows);
            $("#customRange3").val(maxLikes);
            $("#customRange4").val(maxComments);
            $("#customRange5").val(maxStories);
            $("#follow_set").html("Follows/day: " + maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + maxUnfollows);
            $("#like_set").html("Likes/day: " + maxLikes);
            $("#story_set").html("Stories/day: " + maxStories);
            $("#comment_set").html("DMs/day: " + maxComments);







            $("#startinstagram").parent().addClass("active");

            SetActiveSidebarItem("#sidebar-home");


        });




    });

    function onClick(e) {

        $("#snapshots").html("<h4>Settings Used:</h4> <br>Likes/Day:" + live_snapshots[e.dataPoint.x].LikeSettings.TimeMin + "<br>Follows/day:" + live_snapshots[e.dataPoint.x].FollowSettings.TimeMin + "<br>Unfollows/Day:" + live_snapshots[e.dataPoint.x].UnfollowSettings.TimeMin + "<br>");
        $("#tags").html("<h4>Hashtag Targets:</h4> <br>" + live_tags[e.dataPoint.x]);
        $("#accounts").html("<h4>Account Targets:</h4> <br>" + live_accounts[e.dataPoint.x]);

    }






    $("#sidebar-settings").click(function() {
        $(".content-wrapper").empty();
        $(".content-wrapper").load("settings.html", function() {
            var followers_string = "";
            for (var kk = 0; kk < user_followers.length; kk++) {
                followers_string += user_followers[kk] + ", ";

            }
            var ideal_targets_string = "";

            for (var kk = 0; kk < IdealTargets.length; kk++) {
                ideal_targets_string += IdealTargets[kk].username + " followers: " + IdealTargets[kk].followers + "<br> ";

            }

            let element = document.getElementById("minPhoto");
            element.value = minPhotos;

            let element1 = document.getElementById("minFollowing");
            element1.value = minFollowing;

            let element2 = document.getElementById("maxFollowing");
            element2.value = maxFollowing;
            let element3 = document.getElementById("minFollower");
            element3.value = minFollowers;
            let element4 = document.getElementById("maxFollower");
            element4.value = maxFollowers;
            var blacklist_string = "";

            for (var kk = 0; kk < blacklist.length; kk++) {
                blacklist_string += blacklist[kk] + ",  ";

            }


            var filter_string = "";

            for (var kk = 0; kk < filters.length; kk++) {
                filter_string += filters[kk] + ",  ";

            }
            $("#followers_list").html("Followers " + user_followers.length + "/" + follow_count_num + ": " + followers_string + "<br>");
            $("#activity_log").html("<br>Activity Log: <br>" + activity_log);
            $("#blacklist").html("<br>Blacklist of profiles to never re-visit:  <br>" + blacklist_string);
            $("#filters").html("<br>Words to avoid in bio text and photo content:  <br>" + filter_string);

            $("#IdealTargets").html("<br>Ideal Account Targets: <br>" + ideal_targets_string);

            $("#export").click(function() {
                    SendMessage("ExportDatabase", "", "");


                }

            );
            $("#switch-account").click(function() {
                    SendMessage("switch-account", "", "");
                    alert("Please wait 30 seconds while the Instagram tab navigates to your new profile. Make sure to log into the correct account at Instagram.com first. You can also re-install the extension to switch accounts.");


                }

            );
            $(document).on('change', '#import-file-input', function(event) {
                ImportDatabase(event);
            });

            $("#import").click(function() {
                $("#import-file-input").click();
            });

            $("#generateHashtags").click(function() {
                var theme = prompt("Enter the theme of the profile(1 word only).");
                theme = theme.split(" ")[0];


                $.ajax({
                        url: "https://instoo.com/user/getBestTargets",
                        method: "POST",
                        data: {
                            "theme": theme
                        },
                        error: function(request, status, error) {
                            var Error = {};
                            Error.String = "CollectMediaFromAccountError";
                            Error.Request = request;
                            Error.Status = status;
                            Error.AjaxError = error;

                        }
                    })
                    .done(function(dataobj) {

                        $('#hashtagsOutput').append("<h3>Best hashtags based on our logs:" + dataobj + "</h3>");

                    });


            });



            $("#cloud-backup").click(function() {

                alert("Settings saved to cloud!");

                if (roughSizeOfObject(cloud_db) < 15000000) {
                    
                }

            });
            $("#cloud-clear").click(function() {

                alert("Cloud backup cleared!");
         

                SendMessage("ResetAll", "", "");

            });




            $("#add_followers").click(function() {
                var whitelist_users = [];

                for (var kk = 0; kk < user_followers.length; kk++) {
                    whitelist_users.push(user_followers[kk]);

                }
                SendMessage("AddUserToWhitelistNameList", "username", whitelist_users);

            });

            $("#set-backgrounddm-check").click(function() {
                SendMessage("SetDMMode", "mode", $(this).is(':checked'));


            });

            $("#set-enablefilters-check").click(function() {
                SendMessage("SetEnableFilters", "mode", $(this).is(':checked'));


            });
            $("#set-collectfollowers-check").click(function() {
                SendMessage("SetCollectFollowers", "mode", $(this).is(':checked'));
            });
        

            


            $("#white_accounts").on('itemAdded', function(event) {
               

            });




            $("#set-slow-check").click(function() {
                SetFollowValue();
                SendMessage("SetSlowMode", "slow", $(this).is(':checked'));

            });


            $("#set-unfollowinstoo-check").prop("checked", unfollow_mode);
            $("#set-unfollowinstoo-check").click(function() {
                SendMessage("Setunfollowinstoo", "unfollowInstoo", $(this).is(':checked'));

            });

            $("#set-addideal-check").prop("checked", addIdeal);

            $("#set-addideal-check").click(function() {
                SendMessage("Setaddideal", "addideal", $(this).is(':checked'));

            });

         

            $("#set-collectfollowers-check").prop("checked", collectSelfFollowers);

            $("#set-backgrounddm-check").prop("checked", DMMode);
            $("#set-enablefilters-check").prop("checked", EnableFilters);

            $("#set-react-check").prop("checked", StartReact);
            $("#set-react-check").click(function() {
                StartReact = $(this).is(':checked');
                SendMessage("SetReactMode", "reacts", StartReact);
                var result = $('input[type="checkbox"]:checked') // this return collection of items checked
                if (result.length > 0) {
                    reacts = [];
                    result.each(function() {
                        reacts.push($(this).val());
                    });

                    SendMessage("SetReacts", "reacts", reacts);


                }

            });

            $("#set-cloud-check").click(function() {

                if (cloud_backup === false) {
                    buyCloud();
                    $("#set-cloud-check").click();
                } else {
                    user_cloud = $(this).is(':checked');
                }
            });


            $("#set-unfollowmode-check").prop("checked", unfollow_mode);

            $("#set-unfollowmode-check").click(function() {
                enable_get_followers = $(this).is(':checked');
                SendMessage("SetUnfollowMode", "unfollow", $(this).is(':checked'));
            });


            $("#input-unfollow-days").bind('keyup mouseup', function() {
                SendMessage("SetUnfollowDays", "days", $("#input-unfollow-days").val());

            });
            $("#input-unfollow-days").val(UnfollowAfterDays);

            SendMessage("RequestWhitelistStatus", "", "");

            var modal = $('body').siblings("#AddUserToWhitelistModal");
            if (modal.length > 0) {
                modal.remove();
            }
            $('#AddUserToWhitelistModal').insertAfter($('body'));

            SendMessage("RequestWhitelist", "", "");
            $("#whitelist-followings").click(function() {
                WhitelistFollowings($(this).is(':checked'));
            });


            $("#user-search").keyup(function(event) {
                event.preventDefault();

                FilterWhitelistSearch(this);

            });


            $("#add-user-search").keyup(function() {
                NewWhitelistUserSearch(this);
            });


            SetActiveSidebarItem("#sidebar-likes_comments");

            SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


            SendMessage("RequestSettings", "", "");

            var modal = $('body').siblings("#confirm-reset-modal");
            if (modal.length > 0) {
                modal.remove();
            }
            $('#confirm-reset-modal').insertAfter($('body'));

            $("#default-settings").click(function() {
                SendMessage("ResetPool", "", "");

            });

            $("#save-settings").click(function() {
                SaveSettings();
            });




            $("#export-database").click(function() {
                SendMessage("ExportDatabase", "", "");
            });

            $("#reset-all").click(function() {
                $("#confirm-reset-modal").modal('show');
            });

            $("#confirm-modal-btn-yes").click(function() {
                SendMessage("ResetAll", "", "");
            });

            SetActiveSidebarItem("#sidebar-settings");
        });
    });



   

    $("#sidebar-home").click();

    SendMessage("OpenInstagramFast", "Speed", 1);
})

function SetActiveSidebarItem(sidebar_id) { 
    $("#sidebar-home").addClass("sidebar-item");
    $("#sidebar-home-tiktok").addClass("sidebar-item");
    $("#sidebar-home-facebook").addClass("sidebar-item");

    $("#sidebar-home-tw").addClass("sidebar-item");
    $("#sidebar-home-tinder2").addClass("sidebar-item");
    $("#sidebar-home-link2").addClass("sidebar-item");
    $("#sidebar-home-crm").addClass("sidebar-item");
    $("#sidebar-home-pinterest").addClass("sidebar-item");

    $("#sidebar-whitelist").addClass("sidebar-item");
    $("#sidebar-settings").addClass("sidebar-item");
    $("#sidebar-analytics").addClass("sidebar-item");
    $("#sidebar-upgrades").addClass("sidebar-item");

    $("#sidebar-help").addClass("sidebar-item");
    $("#sidebar-likes_comments").addClass("sidebar-item");

    $("#sidebar-home").removeClass("sidebar-item-active");
    $("#sidebar-home-tiktok").removeClass("sidebar-item-active");
    $("#sidebar-home-facebook").removeClass("sidebar-item-active");

    $("#sidebar-home-tinder2").removeClass("sidebar-item-active");
    $("#sidebar-home-link2").removeClass("sidebar-item-active");
    $("#sidebar-home-crm").removeClass("sidebar-item-active");
    $("#sidebar-home-pinterest").removeClass("sidebar-item-active");

    $("#sidebar-home-tw").removeClass("sidebar-item-active");

    $("#sidebar-whitelist").removeClass("sidebar-item-active");
    $("#sidebar-analytics").removeClass("sidebar-item-active");
    $("#sidebar-upgrades").removeClass("sidebar-item-active");

    $("#sidebar-settings").removeClass("sidebar-item-active");
    $("#sidebar-help").removeClass("sidebar-item-active");
    $("#sidebar-likes_comments").removeClass("sidebar-item-active");

    $(sidebar_id).removeClass("sidebar-item");
    $(sidebar_id).addClass("sidebar-item-active");
}


function OnMessageReceive(msg) {

    if (msg.Tag == "UserFollowComplete") {
        OnFollowedUser(msg.User);
    } else if (msg.Tag == "ReloadCharts") {
        instagram_data = msg.data.instagram_data;
        linkedin_data = msg.data.linkedin_data;
        var target_dic = {};

        var like_block = $("#crm-table");
        var like_table = $(like_block).find("tbody");
        $(like_table).empty();
        var html = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td></td><td>Contact</td><td>Email</td><td>Sales</td><td>Target</td><td>Website</td><td>Twitter</td><td>Birthday</td><td>Connected</td></tr>";
        for (var i = 0; i < linkedin_data.length; i++) {
            if (typeof linkedin_data[i] != "undefined")
                html += "<tr><td><img width='100px' src='" + linkedin_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='https://linkedin" + linkedin_data[i].url.split("linkedin")[1] + "'>" + linkedin_data[i].username + "</a></td><td><a href='#' onclick='editEmail(" + i + ")'>" + linkedin_data[i].email + "</a></td><td><a href='#' onclick='editSales(" + i + ")'>" + linkedin_data[i].sales + "</a></td><td><a href='#' onclick='editTargret(" + i + ")'>" + linkedin_data[i].target + "</a></td><td><a href='#' onclick='editWebsite(" + i + ")'>" + linkedin_data[i].website + "</a></td><td><a href='#' onclick='editTwitter(" + i + ")'>" + linkedin_data[i].twitter + "</a></td><td><a href='#' onclick='editBirthday(" + i + ")'>" + linkedin_data[i].birthday + "</a></td><td><a href='#' onclick='editConnected(" + i + ")'>" + linkedin_data[i].connected + "</a></td></tr>";
            if (linkedin_data[i].target in target_dic) {
                target_dic[linkedin_data[i].target].leads++;
                target_dic[linkedin_data[i].target].sales += parseInt(linkedin_data[i].sales);
                if (linkedin_data[i].connected != "none") {
                    target_dic[linkedin_data[i].target].connected++;
                }
            } else {
                var did_connect = 0;
                if (linkedin_data[i].connected != "none") {
                    did_connect = 1;
                }


                target_dic[linkedin_data[i].target] = {
                    leads: 1,
                    sales: parseInt(linkedin_data[i].sales),
                    connected: did_connect
                };
            }

        }


        for (var i = 0; i < instagram_data.length; i++) {
            if (typeof instagram_data[i] != "undefined")
                html += "<tr><td><img width='100px' src='" + instagram_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='" + instagram_data[i].url + "'>" + instagram_data[i].username + "</a></td><td><a href='#' onclick='editInstaEmail(" + i + ")'>" + instagram_data[i].email + "</a></td><td><a href='#' onclick='editInstaSales(" + i + ")'>" + instagram_data[i].sales + "</a></td><td><a href='#' onclick='editInstaTargret(" + i + ")'>" + instagram_data[i].target + "</a></td><td><a href='#' onclick='editInstaWebsite(" + i + ")'>" + instagram_data[i].website + "</a></td><td><a href='#' onclick='editInstaTwitter(" + i + ")'>" + instagram_data[i].twitter + "</a></td><td><a href='#' onclick='editInstaBirthday(" + i + ")'>" + instagram_data[i].birthday + "</a></td><td><a href='#' onclick='editInstaConnected(" + i + ")'>" + instagram_data[i].connected + "</a></td></tr>";
            if (instagram_data[i].target in target_dic) {
                target_dic[instagram_data[i].target].leads++;
                target_dic[instagram_data[i].target].sales += parseInt(instagram_data[i].sales);
                if (instagram_data[i].connected != "none") {
                    target_dic[instagram_data[i].target].connected++;
                }
            } else {

                var did_connect = 0;
                if (instagram_data[i].connected != "none") {
                    did_connect = 1;
                }

                target_dic[instagram_data[i].target] = {
                    leads: 1,
                    sales: parseInt(instagram_data[i].sales),
                    connected: did_connect
                };
            }

        }
        html += "</table><script>function editInstaConnected(num){ window.postMessage({mode: 'Instaconnected' ,edit: num} , '*');} function editInstaBirthday(num){ window.postMessage({mode: 'Instabirthday' ,edit: num} , '*');}function editInstaTwitter(num){ window.postMessage({mode: 'Instatwitter' ,edit: num} , '*');} function editInstaWebsite(num){ window.postMessage({mode: 'Instawebsite' ,edit: num} , '*');} function editInstaTarget(num){ window.postMessage({mode: 'Instatarget' ,edit: num} , '*');} function editInstaSales(num){ window.postMessage({mode: 'Instasales' ,edit: num} , '*');}function editInstaEmail(num){ window.postMessage({mode: 'Instaemail' ,edit: num} , '*');}function editConnected(num){ window.postMessage({mode: 'connected' ,edit: num} , '*');} function editBirthday(num){ window.postMessage({mode: 'birthday' ,edit: num} , '*');}function editTwitter(num){ window.postMessage({mode: 'twitter' ,edit: num} , '*');} function editWebsite(num){ window.postMessage({mode: 'website' ,edit: num} , '*');} function editTarget(num){ window.postMessage({mode: 'target' ,edit: num} , '*');} function editSales(num){ window.postMessage({mode: 'sales' ,edit: num} , '*');}function editEmail(num){ window.postMessage({mode: 'email' ,edit: num} , '*');}</script>";
        $(like_block).html(html);

        var target_block = $("#target-table");
        var target_table = $(target_block).find("tbody");
        $(target_table).empty();
        var html_target = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td>Target</td><td>Sales</td><td>Leads</td><td>Gained Followers</td></tr>";
        for (var key in target_dic) {
            if (target_dic.hasOwnProperty(key)) {
                html_target += "<tr><td>" + key + "</td><td>" + target_dic[key].sales + "</td><td> " + target_dic[key].leads + "</td><td>" + target_dic[key].connected + "</td></tr>";
            }

        }
        html_target += "</table>";

        $(target_block).html(html_target);




    } else if (msg.Tag == "setLanguage") { 
        $("#errors").prepend("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Instoo has detected that the langauge at instagram.com is not set to English. Please follow these steps: <br>1) Click your profile picture in the top right corner, then click Profile. <br>2) Click Edit Profile.<br>3) Click Language at the very bottom of the page and select a new language.<br>4) Select English. It's in small gray text on the last line of the page to make it easy.</div>");


    } else if (msg.Tag == "UserFollowCompleteTikTok") { 

        OnFollowedUserTikTok(msg.User);



    } else if (msg.Tag == "UserFollowCompletefacebook") { 

        OnFollowedUserfacebook(msg.User);



    } else if (msg.Tag == "UserFollowCompletePinterest") { 

        OnFollowedUserPinterest(msg.User);



    } else if (msg.Tag == "UserFollowCompleteLinkedin") { 

        OnFollowedUserLinkedin(msg.User);



    } else if (msg.Tag == "RefreshPage") { 
        window.location.reload(true);


    } else if (msg.Tag == "UserFollowCompleteTwitter") { 

        OnFollowedUserTwitter(msg.User);



    } else if (msg.Tag == "UserLikeCompleteTikTok") { 
        OnLikedMediaTikTok(msg.User);



    } else if (msg.Tag == "UserLikeCompletefacebook") {


        OnLikedMediafacebook(msg.User);



    } else if (msg.Tag == "UserLikeCompletePinterest") { 



        OnLikedMediaPinterest(msg.User);



    } else if (msg.Tag == "UserLikeCompleteLinkedin") { 




        OnLikedMediaLinkedin(msg.User);



    } else if (msg.Tag == "UserLikeCompleteTinder") { 



        OnLikedMediaTinder(msg.User);



    } else if (msg.Tag == "UserLikeCompleteTwitter") {


        OnLikedMediaTwitter(msg.User);



    } else if (msg.Tag == "DispatchFollowStatus") {
        UpdateFollowStatus(msg.AllUsers);
    } else if (msg.Tag == "SetPhoto") {
        $(".img-current-user").attr("src", msg.user.profile_pic_url);
        CurrentUser = msg.user;

        user_email = $("#email").attr("name");
        var user_plan = $("#plan").attr("name");

        $.post('https://instoo.com/user/postInst', {
                email: user_email,
                username: CurrentUser.username
            },
            function(returnedData) {
                if (returnedData && returnedData.length > 1 && CurrentUser.username != "nala_awoon" && !user_email.includes("ikeda.group")) {
                    $("#trial").show();
                    SetFollowValue(false);
                    SetUnfollowValue(false);
                    SetStoryValue(false);
                    $("#set-story-check").prop("checked", false);

                    $("#set-follow-check").prop("checked", false);
                    $("#set-unfollow-check").prop("checked", false);
                    $("#set-story-check").prop("checked", false);
                    $("#set-like-check").prop("checked", false);
                    $("#set-comment-check").prop("checked", false);
                }
            });

    } else if (msg.Tag == "LoadCloud") {
        started = true;
        var loaded = false;
        var obj = [];
  
        SendMessage("loadLocal", "Database", "obj");


    } else if (msg.Tag == "RecentFollowers") {
        var recentFollowers = msg.ExtractedUsers;
        instooData = [];
        for (var kk = 0; kk < recentFollowers.length; kk++) {
            var found = checkObject(recentFollowers[kk].user_id, instooData);
            if (found.length > 0) {
              
            }

        }

    } else if (msg.Tag == "RankedID") {


    } else if (msg.Tag == "LoopingTargets") {

        $("#errors").prepend("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Instoo is looping your targets("  +  msg.Media + "), which means they do not actively gain followers fast enough.<br><b> If you have 20+ account targets, please remove these. You should add 20 more account targets with under 100k followers.</b><br> Bot auto-turned off to avoid looping the same targets. The first day after adding new targets, make sure they actively gain relevant followers. It will tell you which target all profiles came from on the Instagram tab and Instoo tab,so you can remove irrelevant ones. </div>");

        $("#set-story-check").prop("checked", false);
        $("#set-follow-check").prop("checked", false);
        $("#set-like-check").prop("checked", false);

        SetStoryValue(false);
        SetLikeValue(false);
        SetFollowValue(false);

       

    } else if (msg.Tag == "userData") {
        $("#follow_count").html("followers: " + msg.User.edge_followed_by.count);
        follow_count_num = msg.User.edge_followed_by.count;
        if (follow_count_num < 1000) {
            SendMessage("SetSpeed", "Num", 2);
            
        $("#fast").removeClass('active');
        $("#slow").removeClass('active');
        $("#medium").addClass('active');
        }

        if (follow_count_num < 200) {
            SendMessage("SetSpeed", "Num", 8);
            
        $("#fast").removeClass('active');
        $("#slow").addClass('active');
        $("#medium").removeClass('active');
        }
        var account_id = msg.User.id;

        var UserData = {
            "username": msg.User.username,
            "user_id": msg.User.id,
            "full_name": msg.User.full_name,
            "user_pic_url": msg.User.profile_pic_url
        };


        var CollectJob = {};
        CollectJob.user_id = account_id;
        CollectJob.cursor_key = null;
        CollectJob.user = UserData;
        myCollectJob = CollectJob;
        SendMessage("myCollectJob", "Job", CollectJob);



    } else if (msg.Tag == "gotStats") {
        follow_count_num = parseInt(msg.followers.followers.split(",").join("").split(".").join("").split(" ").join(""));
        following_count_num = parseInt(msg.followers.following.split(",").join("").split(".").join("").split(" ").join(""));

        var d = new Date();
        var currentHour = d.getHours();
        if (follow_count_num < 1000) {
            SendMessage("SetSpeed", "Num", 2);
            
        $("#fast").removeClass('active');
        $("#slow").removeClass('active');
        $("#medium").addClass('active');
        }

        if (follow_count_num < 200) {
            SendMessage("SetSpeed", "Num", 3);
            
        $("#fast").removeClass('active');
        $("#slow").addClass('active');
        $("#medium").removeClass('active');

        }
        var d_num = Date.parse(d);
        d_num = Math.floor(d_num / (1000 * 60 * 60));
        var dat = {
            followers: follow_count_num,
            hour: d_num,
            user_id: msg.followers.CurrentUser.user_id,
            mode: mode
        };
        if (follow_count_num > 10) {
            var data = {
                followers: follow_count_num,
                hour: d_num,
                user_id: CurrentUser.user_id,
                mode: "instagram"
            };

             SendMessage("PostStats", "data", data);

        }

    } else if (msg.Tag == "SendUserHeader") {
        SendMessage("GotUserHeader", "User", CurrentUser);
    } else if (msg.Tag == "BackupCloud") {

        if (enable_get_followers) {
        }
        if (true) {


        }

    } else if (msg.Tag == "StatusUpdate") {
        UpdateStatus(msg.Status);
    } else if (msg.Tag == "SkipFollowStory") {
        $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>" + msg.text + " </div>");
    } else if (msg.Tag == "UpdateStory") {

    } else if (msg.Tag == "GotDatabase") {
        GotDatabase(msg.Database);
    } else if (msg.Tag == "SendFollowers") {
        UpdateFollowers(msg.Status);
    } else if (msg.Tag == "blocked") {
        window.location.href = "https://instoo.com/pause";

        $("#set-story-check").prop("checked", false);
        $("#set-follow-check").prop("checked", false);
        $("#set-like-check").prop("checked", false);

        SetStoryValue(false);
        SetLikeValue(false);
        SetFollowValue(false);
    } else if (msg.Tag == "SendAccountsDict") {
        UpdateAccountsDict(msg.Accounts);

    } else if (msg.Tag == "SendTagsDict") {
        UpdateTagsDict(msg.Hashtags);

    } else if (msg.Tag == "UserUnfollowComplete") {



        OnUnfollowedUser(msg.User);


    } else if (msg.Tag == "OnLikedMediaComplete") {

        OnLikedMedia(msg.Media);
    } else if (msg.Tag == "OnStoryMediaComplete") {

        OnStoryMedia(msg.Media);
    } else if (msg.Tag == "Pause") {

        $("#set-follow-check").prop("checked", false);
        $("#set-unfollow-check").prop("checked", false);
        $("#set-story-check").prop("checked", false);
        $("#set-like-check").prop("checked", false);
        $("#set-comment-check").prop("checked", false);

        // OnStoryMedia(msg.Media);
    } else if (msg.Tag == "OnCommentedMediaComplete") {


        OnCommentedMedia(msg.Media);
    } else if (msg.Tag == "Settings") {
        SetSettings(msg.Settings);
    } else if (msg.Tag == "AddedWhitelistUsers") {
        ClearWhitelistTable();
        AddedWhitelistUsers(msg.Users);
    } else if (msg.Tag == "UpdatedWhitelistUsers") {
        AddedWhitelistUsers(msg.Users);
    } else if (msg.Tag == "UserLoggedIn") {

        logged_in = true;
        loadedAccounts = false;

        SendMessage("RequestFollowStatus", "Num", DisplayFollowersNum);
        $("#overlay").hide();
        if (paid_sub) {
            SendMessage("SetPaidMode", "paid", true);
            $('.sub-user').hide();
            $("#purchase").hide();
            $("#upgrade").hide();

            $("#customRange1").attr("max", speed_limit);
            $("#customRange2").attr("max", speed_limit);
            $("#customRange3").attr("max", speed_limit);
        } else {

            $("#customRange1").attr("max", speed_limit);
            $("#customRange2").attr("max", speed_limit);
            $("#customRange3").attr("max", speed_limit);
        }

        if (comment_val == true || like_val == true || follow_val == true || unfollow_val == true) {
            $("#progress").attr("src", "disk.gif");
        } else {
            $("#progress").attr("src", "icon.gif");
        }
  


    } else if (msg.Tag == "UserLoggedOut") {
        logged_in = false;
        loadedAccounts = false;
        if (!(mode == "twitter") && !(mode == "tiktok") && !$("#set-story-check").is(':checked') && !$("#set-like-check").is(':checked') && !$("#set-follow-check").is(':checked') && !$("#set-unfollow-check").is(':checked') && !$("#set-comment-check").is(':checked')) {
            $("#overlay").show();

        }
        setTimeout(function() {
            if (!logged_in) {
                SendMessage("OpenInstagram", "Speed", 1);
            }
        }, 10000);
    } else if (msg.Tag == "ReceiveFilteredFollowings") {
        ProcessFilteredFollowings(msg.Users);
    } else if (msg.Tag == "RankTargets") {

        RankTargets(msg.recents);


    } else if (msg.Tag == "ReceiveWhitelistStatus") {
        SetWhitelistStatus(msg.Status);
    } else if (msg.Tag == "UpdateMediaStatus") {
        UpdateMediaStatus(msg.Status);
    } else if (msg.Tag == "Error" && msg.type == "FollowError") {
        $("#errors").html("<div class='alert alert-danger alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button><strong>Follow Usage Limit Warning!</strong> The bot is slowing down on follows for 30 minutes. Log out at Instagram.com to delete your cookies. If this message persists, test Instagram.com to check if you have a 3 day block, and wait if you do. We recommend using the story viewer, since it has much higher limits. </div>");

    } else if (msg.Tag == "Error" && msg.type == "UnfollowError") {
        $("#errors").html("<div class='alert alert-danger alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button><strong>Unfollow Usage Limit Warning!</strong> The bot is slowing down on unfollows for 30 minutes.  Log out at Instagram.com to delete your cookies. If this message persists, test Instagram.com to check if you have a 3 day block, and wait if you do. We recommend using the story viewer, since it has much higher limits. </div>");
    } else if (msg.Tag == "Error" && msg.type == "LikeError") {
        $("#errors").html("<div class='alert alert-danger alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button><strong>Likes Usage Limit Warning!</strong> The bot is sleeping on likes for 30 minutes.  Log out at Instagram.com to delete your cookies. If this message persists, test Instagram.com to check if you have a 3 day block, and wait if you do. We recommend using the story viewer, since it has much higher limits. </div>");
    } else if (msg.Tag == "Error" && msg.type == "StoryError") {
        $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Randomly sleeping on story viewing for a bit to appear human. Hang tight for 2-30 minutes.</div>");
    } else if (msg.Tag == "Error" && msg.type == "CommentError") {
        $("#errors").html("<div class='alert alert-danger alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button><strong>Comments Usage Limit Warning!</strong> The bot is sleeping on comments for 30 minutes.  Log out at Instagram.com to delete your cookies. If this message persists, test Instagram.com to check if you have a 3 day block, and wait if you do. We recommend using the story viewer, since it has much higher limits. </div>");
    }
}

function SetSettings(settings) {

    $("#input-follow-time-min").val(settings.FollowSettings.TimeMin);
    $("#input-follow-time-max").val(settings.FollowSettings.TimeMax);
    $("#input-follow-error-time").val(settings.FollowSettings.ErrorTime);

    $("#input-unfollow-time-min").val(settings.UnfollowSettings.TimeMin);
    $("#input-unfollow-time-max").val(settings.UnfollowSettings.TimeMax);
    $("#input-unfollow-error-time").val(settings.UnfollowSettings.ErrorTime);

    $("#input-user-pool-num").val(settings.CollectFollowers.Pool);
    $("#input-user-collect-time").val(settings.CollectFollowers.Interval);
    $("#input-user-error-time").val(settings.CollectFollowers.ErrorTime);

    $("#input-following-pool-num").val(settings.CollectFollowings.Pool);
    $("#input-following-collect-time").val(settings.CollectFollowings.Interval);
    $("#input-following-error-time").val(settings.CollectFollowings.ErrorTime);

    $("#input-unfollow-days").val(settings.UnfollowAfterDays);
    $("#set-slow-check").prop("checked", settings.slow);
    $("#set-cloud-check").prop("checked", user_cloud && cloud_backup);
  

}


