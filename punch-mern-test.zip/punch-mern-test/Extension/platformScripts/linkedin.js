console.log('content.linkedin.js script loaded');

class LinkedinModel {
    constructor() {
        this.ComPort = null;
        this.CurrentUser = null;
        this.LastUsername = "";
        this.SharedData = null;
        this.UserTag = "._7UhW9";
        this.StartStory = false;
        this.msg_user = "";
        this.tag_dict = {};
        this.account_dict = {};
        this.that = this;
        this.image_src = "";
        this.story_set = false;
        this.result = "";
        this.target = "";
        this.completed = [];
        this.story = {};
    }

    CreateComPort() {
        this.ComPort = chrome.runtime.connect({
            name: "linkedin"
        });
        this.ComPort.onMessage.addListener(this.OnMessageReceive.bind(this));

        window.addEventListener("message", (event) => {
            if (event.source != window) return;
            if (event.data.Tag && (event.data.Tag == "SharedData")) {
                this.SharedData = event.data.SharedData;
            }
        }, false);
    }

    scrollLike(num) {
        window.scrollBy(0, 300);
        let counter = 0;
        const vid = parseInt(Math.floor(Math.random() * 6) + 1);

        let username = "none";
        let email = "none";
        let twitter = "none";
        let website = "none";
        let birthday = "none";
        let connected = "none";
        let profile = "none";

        const img = "https://instoo.com/logo.png";
        const links = document.getElementsByTagName('span');

        for (let kk = 0; kk < links.length; kk++) {
            if (links[kk] && links[kk].getAttribute("class") && links[kk].getAttribute("class").includes("entity-result__title-text ") && !links[kk].innerHTML.includes("<img") && !this.completed.includes(links[kk].getAttribute("href"))) {
                counter++;
                if (counter == vid) {
                    this.completed.push(links[kk].getAttribute("href"));
                    links[kk].children[0].click();
                    if (num > 0) {
                        setTimeout(() => {
                            if (this.story.StartLinkedinFollow) {
                                const buttons = document.getElementsByTagName('button');
                                for (let kk = 0; kk < buttons.length; kk++) {
                                    if (buttons[kk] && buttons[kk].getAttribute("aria-label") && buttons[kk].getAttribute("data-control-name") && buttons[kk].getAttribute("data-control-name").includes("connect") && buttons[kk].getAttribute("aria-label").includes("Connect")) {
                                        buttons[kk].click();
                                        setTimeout(() => {
                                            const sendButtons = document.getElementsByTagName('button');
                                            for (let kk = 0; kk < sendButtons.length; kk++) {
                                                if (sendButtons[kk] && sendButtons[kk].getAttribute("aria-label") && sendButtons[kk].getAttribute("aria-label").includes("Send now")) {
                                                    sendButtons[kk].click();
                                                }
                                            }
                                        }, 2000);

                                        const msg_data = {
                                            target: this.target,
                                            username: username,
                                            url: profile,
                                            img: img
                                        };

                                        this.SendMessage("DoneLinkedinFollow", "User", msg_data);
                                        break;
                                    }
                                }
                            }
                        }, 3000);

                        if (this.story.StartLinkedinLike || this.story.StartLinkedinFollow) {
                            setTimeout(() => {
                                const contactLinks = document.getElementsByTagName('a');
                                for (let kk = 0; kk < contactLinks.length; kk++) {
                                    if (contactLinks[kk] && contactLinks[kk].getAttribute("data-control-name") && contactLinks[kk].getAttribute("data-control-name") == "contact_see_more") {
                                        contactLinks[kk].click();
                                        setTimeout(() => {
                                            const divs = document.getElementsByTagName('div');
                                            for (let kk = 0; kk < divs.length; kk++) {
                                                if (divs[kk] && divs[kk].getAttribute("class") && divs[kk].getAttribute("class").includes("section-info")) {
                                                    if (!this.result.includes(divs[kk].outerHTML)) {
                                                        this.result += divs[kk].outerHTML;
                                                        const h1s = document.getElementsByTagName('h1');
                                                        for (let kk = 0; kk < h1s.length; kk++) {
                                                            if (h1s[kk] && h1s[kk].getAttribute("id") && h1s[kk].getAttribute("id").includes("pv-contact-info")) {
                                                                username = h1s[kk].innerText;
                                                            }
                                                        }

                                                        const sections = document.getElementsByTagName('section');
                                                        for (let kk = 0; kk < sections.length; kk++) {
                                                            if (sections[kk] && sections[kk].getAttribute("class") && sections[kk].getAttribute("class").includes("vanity")) {
                                                                profile = sections[kk].innerText;
                                                            }
                                                            if (sections[kk] && sections[kk].getAttribute("class") && sections[kk].getAttribute("class").includes("email")) {
                                                                email = sections[kk].innerText;
                                                            }
                                                            if (sections[kk] && sections[kk].getAttribute("class") && sections[kk].getAttribute("class").includes("birthday")) {
                                                                birthday = sections[kk].innerText;
                                                            }
                                                            if (sections[kk] && sections[kk].getAttribute("class") && sections[kk].getAttribute("class").includes("connected")) {
                                                                connected = sections[kk].innerText;
                                                            }
                                                            if (sections[kk] && sections[kk].getAttribute("class") && sections[kk].getAttribute("class").includes("twitter")) {
                                                                twitter = sections[kk].innerText;
                                                            }
                                                            if (sections[kk] && sections[kk].getAttribute("class") && sections[kk].getAttribute("class").includes("website")) {
                                                                website = sections[kk].innerText;
                                                            }
                                                        }

                                                        const msg_data = {
                                                            target: this.target,
                                                            sales: 0,
                                                            email: email,
                                                            html: "",
                                                            username: username,
                                                            birthday: birthday,
                                                            connected: connected,
                                                            twitter: twitter,
                                                            url: profile,
                                                            img: img
                                                        };
                                                        this.SendMessage("LinkedinLead", "User", msg_data);
                                                        window.history.back(2);
                                                    }

                                                    setTimeout(() => {
                                                        window.history.back(2);
                                                        if (num > 0) {
                                                            setTimeout(() => {
                                                                this.scrollLike(num - 1);
                                                            }, 10000);
                                                        }
                                                    }, 7000);
                                                }
                                            }
                                        }, 7000);
                                    }
                                }
                            }, 7000);
                        }
                        break;
                    }
                }
            }
        }
    }

    OnMessageReceive(msg) {
        console.log(msg);
        if (msg.Tag == "LikeFollow") {
            this.target = msg.story.target;
            this.story = msg.story;
            this.scrollLike(10);
        }
    }

    SendMessage(tag, msgTag, msg) {
        const sendObj = { "Tag": tag };
        sendObj[msgTag] = msg;
        this.ComPort.postMessage(sendObj);
    }
}

class LinkedinView {
    constructor(controller) {
        this.controller = controller;
        $(document).ready(this.onDocumentReady.bind(this));
    }

    onDocumentReady() {
        this.controller.CreateComPort();
        if (window.location.href.includes("tag")) {
            window.scrollTo(0, document.body.scrollHeight);
            this.scrollTop(20);
        }
    }

    scrollTop(starter) {
        if (starter > 0) {
            window.scrollTo(0, document.body.scrollHeight);
            setTimeout(() => {
                this.scrollTop(starter - 1);
            }, 300);
        }
    }
}

class LinkedinController {
    constructor(model) {
        this.model = model;
    }

    CreateComPort() {
        this.model.CreateComPort();
    }
}

const model = new LinkedinModel();
const controller = new LinkedinController(model);
const view = new LinkedinView(controller);