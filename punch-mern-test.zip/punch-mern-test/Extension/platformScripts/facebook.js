class FacebookModel {
    constructor() {
        this.ComPort;
        // this.CurrentUser;
        // this.LastUsername = "";
        this.SharedData = null;
        // this.UserTag = "._7UhW9";
        // this.StartStory = false;
        // this.msg_user = "";
        // this.tag_dict = {};
        // this.account_dict = {};
        // this.that = this;
        // this.image_src = "";
        // this.story_set = false;
    }
    CreateComPort() {
        this.ComPort = chrome.runtime.connect({
            name: "facebook"
        });
        this.ComPort.onMessage.addListener(this.OnMessageReceive);

        window.addEventListener("message", function (event) {
            // We only accept messages from ourselves
            if (event.source != window)
                return;

            if (event.data.Tag && (event.data.Tag == "SharedData")) {
                this.SharedData = event.data.SharedData;
            }
        }, false);
    }
    scrollLike(num) {
        var t1 = parseInt(Math.floor(Math.random() * 30000) + 1000);

        setTimeout(function () {
            window.scrollTo(0, document.body.scrollHeight);
            var total = 0;
            var videos = document.getElementsByTagName('div');

            for (var kk = 0; kk < videos.length; kk++) {
                //console.log(videos[kk]);
                //console.log(videos[kk].getAttribute("class"));
                if (videos[kk] && videos[kk].getAttribute("aria-label") && videos[kk].getAttribute("aria-label").includes("Add Friend")) {
                    total++;

                }

            }

            var counter = 0;
            var vid = parseInt(Math.floor(Math.random() * total) + 1);

            for (var kk = 0; kk < videos.length; kk++) {
                //console.log(videos[kk]);
                //console.log(videos[kk].getAttribute("class"));
                if (videos[kk] && videos[kk].getAttribute("aria-label") && videos[kk].getAttribute("aria-label").includes("Add Friend")) {
                    counter++;
                    if (vid == counter) {
                        videos[kk].click();
                        var msg_data = {
                            url: "https://facebook.com/" + videos[kk].parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.children[0].children[0].children[0].children[0].getAttribute("href"),
                            username: videos[kk].parentNode.parentNode.parentNode.parentNode.parentNode.children[0].innerText,
                            img: videos[kk].parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.children[0].children[0].children[0].children[0].children[0].children[0].children[1].children[0].getAttribute("xlink:href")
                        };
                        this.SendMessage("DonefacebookFollow", "User", msg_data);
                        window.scrollTo(0, document.body.scrollHeight);

                        break;


                    }


                }


            }


            if (num > 0) {
                this.scrollLike(num - 1);

            }

        }, t1);
    }
    OnMessageReceive(msg) {
        console.log(msg);

        if (msg.Tag == "Updatefacebook") {
            console.log(msg.story);

        } else if (msg.Tag == "LikeFollow") {

            window.scrollTo(0, document.body.scrollHeight);


            if (msg.story.StartfacebookFollow && msg.story.FollowedPoolfacebookSize < msg.story.MaxfacebookFollows) {
                this.scrollLike(5);
            }

        }
    }
    SendMessage(tag, msgTag, msg) {
        var sendObj = {
            "Tag": tag
        };
        sendObj[msgTag] = msg;
        console.log(sendObj);
        console.log(this.ComPort);
        this.ComPort.postMessage(sendObj);
    }

}

class FacebookView {
    constructor(controller) {
        this.controller = controller;
        $(document).ready(this.onDocumentReady.bind(this));
    }
    onDocumentReady() {
        this.controller.CreateComPort();
        console.log("SETUp!");
        if (window.location.href.includes("tag")) {
            window.scrollTo(0, document.body.scrollHeight);
            //  scrollTop(20);
        }
    }
}

class FacebookController {
    constructor(model) {
        this.model = model;
    }
    CreateComPort() {
        this.model.CreateComPort();
    }
}

const model = new FacebookModel();
const controller = new FacebookController(model);
const view = new FacebookView(controller);
