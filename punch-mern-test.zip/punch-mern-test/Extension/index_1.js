var CurrentUser;
var ComPort;
var follow_count_num = 0;
var following_count_num = 0;
var linkedin_data = [];
var instagram_data = [];
var user_stats = [];
var last_ten_min = 1000000;
var last_ten_max = 0;
var DisplayFollowersNum = 10;
var DisplayLikesNum = 20;
var user_email = "";
var dashboardMode = 0;
var postedInst = false;
var follow_speed = 0;
var emailed = false;
var enable_get_followers = false;
var unfollow_speed = 0;
var story_speed = 0;
var unfollowInstoo = false;
var post_stats = false;
var tiktok_data = [];
var tiktok_data = [];
var hoursLeft = 8;
var twitter_data = [];
var like_speed = 0;
var follower_data = [];
var daily_data = [];
var blacklist = [];
var filters = [];
var minPhotos = 1;
var minFollowers = 100;
var minFollowing = 100;
var maxFollowers = 100000;
var maxFollowing = 100000;
var EnableFilters = false;
var update_interval = false;
var IdealTargets = [];
var addIdeal = true;
var follower_growth = 0;
var set_update = false;
var collectSelfFollowers = false;
var tiktok_speed = 0;
var twitter_speed = 0;
var facebook_speed = 0;

var unfollow_mode = false;
var DMMode = true;
window.chartColors = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(75, 192, 192)',
    blue: 'rgb(54, 162, 235)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(201, 203, 207)'
};

var mode = "instagram";
var StartTime = "";
var AutoActions = [];
var analytics = [];
var startDate = "";
var chart_data;
var analytics_chart;
var stopDate = "";
var cal_events = [];
var activity_log = "";
var instooData = [];
var schedule_list = "";
var user_followers = [];
var calendar;
var chart3;
var chart;
var chart2;
var canvas;
var Duration = 8;
var logged_in = false;
var startedTutorial = false;
var likeCount = 0;
var myCollectJob = {};
var maxStories = 1000;
var user_plan;
var comment_speed = 0;
var global_settings = {};
var global_accounts = [];
var gotAnalytics = false;
var global_tags = [];
var global_locations = [];
var started = false;
var paid_sub = false;
var my_followers = [];
var first = false;
var cloud_backup = false;
var start_license = 0;
var last_follow_count = 0;
var clicks = {};
var version = "";

var StartReact = false;
var StartSchedule = false;
var reacts = [];

var follow_val = false;
var like_val = false;
var comment_val = false;
var unfollow_val = false;
var user_cloud = true;
var UnfollowedPoolSize = 0;
var FollowedPoolSize = 0;
var LikePoolSize = 0;
var StoryPoolSize = 0;
var CommentPoolSize = 0;
var last_day = 0;
var day = 0;
var bar_follow;
var maxLikes = 1000;
var maxFollows = 1000;
var maxUnfollows = 1000;
var maxComments = 10;
var bar_like;
var bar_story;
var bar_comment;
var bar_unfollow;
var hashtag_dict = {};
var account_dict = {};
var counted_dict = {};
var clicks_dict = {};
var email_name;
var speed_limit = 100;
var UnfollowAfterDays;
var cloud_db;

var live_snapshots = [];
var live_tags = [];
var like_accounts = [];

var selectedAccount = "";
var loadedAccounts = false;
var updated_cloud = false;
var lastProcessedHour = -1;




Array.prototype.unique = function() {
    var a = this.concat();
    for (var i = 0; i < a.length; ++i) {
        for (var j = i + 1; j < a.length; ++j) {
            if (a[i] === a[j])
                a.splice(j--, 1);
        }
    }

    return a;
};



function ResetSettings() {
    SendMessage("ResetSettings", "", "");
}

function SetFollowValue(value) {
    SendMessage("SetFollowValue", "Value", value);
}

function SetCommentValue(value) {
    SendMessage("SetCommentValue", "Value", value);
}


function SetLikeValue(value) {
    SendMessage("SetLikeValue", "Value", value);
}

function SetStoryValue(value) {
    SendMessage("SetStoryValue", "Value", value);
}

function SetUnfollowValue(value) {
    SendMessage("SetUnfollowValue", "Value", value);
}

function WhitelistFollowings(start) {
    SendMessage("WhitelistFollowings", "Start", start);
}

function SetWhitelistStatus(status) {
    $("#whitelist-followings").prop("checked", status.Enabled);

}

function RemoveWhitelistedUser(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();

    SendMessage("RemoveWhitelistUser", "user_id", user_id);
}

function RemoveCollectJobTagLinkedin(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();


    SendMessage("RemoveTagFromListLinkedin", "TagName", user_id);
    var index = global_tags.indexOf(user_id);
    if (index > -1) {
        global_tags.splice(index, 1);
    }
    SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


}

function RemoveCollectJobTagPinterest(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();


    SendMessage("RemoveTagFromListPinterest", "TagName", user_id);
    var index = global_tags.indexOf(user_id);
    if (index > -1) {
        global_tags.splice(index, 1);
    }
    SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


}

function RemoveCollectJobTagTikTok(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();


    SendMessage("RemoveTagFromListTikTok", "TagName", user_id);
    var index = global_tags.indexOf(user_id);
    if (index > -1) {
        global_tags.splice(index, 1);
    }
    SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


}

function RemoveCollectJobTagfacebook(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();


    SendMessage("RemoveTagFromListfacebook", "TagName", user_id);
    var index = global_tags.indexOf(user_id);
    if (index > -1) {
        global_tags.splice(index, 1);
    }
    SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


}

function RemoveCollectJobTagTwitter(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();


    SendMessage("RemoveTagFromListTwitter", "TagName", user_id);
    var index = global_tags.indexOf(user_id);
    if (index > -1) {
        global_tags.splice(index, 1);
    }
    SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


}

function RemoveCollectJobTag(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();


    SendMessage("RemoveTagFromList", "TagName", user_id);
    var index = global_tags.indexOf(user_id);
    if (index > -1) {
        global_tags.splice(index, 1);
    }
    SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


}

function RemoveLocationJobTag(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();


    SendMessage("RemoveLocationFromList", "TagName", user_id);
    if (index > -1) {
    }
    SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


}

function RemoveCollectJobUser(button) {
    var user_id = $(button).attr("user_id");
    $(button).closest("tr").remove();
    SendMessage("RemoveCollectJob", "user_id", user_id);
    SendMessage("RemoveAccountFromList", "TagName", user_id);
}

function UpdateFollowers(status) {
    my_followers = my_followers.concat(status);
    SendMessage("SendMyFollowers", "followers", my_followers);

}
Date.prototype.isSameDateAs = function(pDate) {
    return (
        this.getFullYear() === pDate.getFullYear() &&
        this.getMonth() === pDate.getMonth() &&
        this.getDate() === pDate.getDate()
    );
}

function UpdateAccountsDict(status) {
    account_dict = status;


}

function UpdateTagsDict(status) {
    hashtag_dict = status;


}

function UpdateStatus(status) {


    hoursLeft = status.hoursLeft;


    if (updated_cloud) {
        if (roughSizeOfObject(cloud_db) < 15000000) {

           
        }
        updated_cloud = false;
    }
    if (emailed == false && follow_count_num < 1000 && follow_count_num != 0) {
        SendMessage("SetSpeed", "Num", 2);
        
        $("#fast").removeClass('active');
        $("#slow").removeClass('active');
        $("#medium").addClass('active');

        $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account with under 1,000 followers. Speeds will naturally ramp up to 2x faster after you pass 1,000 followers.<br><br></div>");

    }


    if (emailed == false && following_count_num < 1000 && following_count_num != 0) {
        SendMessage("SetSpeed", "Num", 2);
        
        $("#fast").removeClass('active');
        $("#slow").removeClass('active');
        $("#medium").addClass('active');

        $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account that is following under 1000 other users(as in people you follow). Speeds will naturally ramp up to 2x faster after you follow more than 1000 users.<br><br></div>");

    }
    if (emailed == false && following_count_num < 200 && following_count_num != 0) {

        $("#fast").removeClass('active');
        $("#slow").addClass('active');
        $("#medium").removeClass('active');

        SendMessage("SetSpeed", "Num", 8);
        $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account, following under 200 users(meaning users you follow). Please pause Instoo and manually follow over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers and following. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. <br><br></div>");
        alert("Instoo has detected you have a smaller account, following under 200 users(meaning users you follow). Please pause Instoo and manually follow over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers and following. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. ");
       
        SetFollowValue(false);
        SetUnfollowValue(false);
        SetStoryValue(false);
        $("#set-story-check").prop("checked", false);

        $("#set-follow-check").prop("checked", false);
        $("#set-unfollow-check").prop("checked", false);
        $("#set-story-check").prop("checked", false);
        $("#set-like-check").prop("checked", false);
        $("#set-comment-check").prop("checked", false);
        if (emailed == false) {
          
            emailed = true;
        }
    }


    if (emailed == false && follow_count_num < 200 && follow_count_num != 0) {


        SendMessage("SetSpeed", "Num", 8);

        
        $("#fast").removeClass('active');
        $("#slow").addClass('active');
        $("#medium").removeClass('active');

        $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account with under 200 followers. Please pause Instoo and manually raise your followers over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. <br><br></div>");
        alert(" Instoo has detected you have a smaller account with under 200 followers. Please pause Instoo and manually raise your followers over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. ");
        
        SetFollowValue(false);
        SetUnfollowValue(false);
        SetStoryValue(false);
        $("#set-story-check").prop("checked", false);

        $("#set-follow-check").prop("checked", false);
        $("#set-unfollow-check").prop("checked", false);
        $("#set-story-check").prop("checked", false);
        $("#set-like-check").prop("checked", false);
        $("#set-comment-check").prop("checked", false);
        if (emailed == false) {
         
            emailed = true;
        }
    }
    // console.log(status);
    user_stats = status.user_stats;
    reacts = status.reacts;
    StartReact = status.StartReact;
    EnableFilters = status.EnableFilters;
    unfollow_mode = status.unfollow_mode;
    activity_log = status.activity_log;
    blacklist = status.blacklist;
    filters = status.filters;
    minFollowing = status.minFollowing;
    maxFollowing = status.maxFollowing;
    minPhotos = status.minPhotos;
    minFollowers = status.minFollowers;
    maxFollowers = status.maxFollowers;

    user_followers = status.user_followers;
    analytics = status.true_analytics;
    IdealTargets = status.IdealTargets;
    DMMode = status.backgroundDMs;
    addIdeal = status.addIdeal;
    unfollowInstoo = status.unfollowInstoo;
    collectSelfFollowers = status.collectSelfFollowers;
    if (status.UserPool.length > 1000 || status.MediaPool.length > 1000) {
        SendMessage("ClearMemory", "story", "");
    }

    UnfollowedPoolSize = status.UnfollowedPoolSize;
    FollowedPoolSize = status.FollowedPoolSize;
    LikePoolSize = status.LikePoolSize;
    StoryPoolSize = status.StoryPoolSize;
    CommentPoolSize = status.CommentPoolSize;

    if (dashboardMode == 1) {

        $("#follow-pool-tiktok-num").text(status.FollowedPoolTikTokSize);
        $("#like-pool-tiktok-num").text(status.LikedPoolTikTokSize);
        $("#tiktok-pool-num").text(status.TikTokSize);
        $("#customRangeTikTokFollows").val(status.MaxTikTokFollows);
        $("#customRangeTikTokLikes").val(status.MaxTikTokLikes);

        $("#follow_tiktok_set").html("Follows/day: " + status.MaxTikTokFollows);
        $("#like_tiktok_set").html("Likes/day: " + status.MaxTikTokLikes);

        $("#set-follow-tiktok-check").prop("checked", status.StartTikTokFollow);
        $("#set-like-tiktok-check").prop("checked", status.StartTikTokLike);
    } else if (dashboardMode == 7) {

        $("#follow_facebook_set").html("Friends/day: " + status.MaxfacebookFollows);
        $("#like_facebook_set").html("Likes/day: " + status.MaxfacebookLikes);

        $("#follow-pool-facebook-num").text(status.FollowedPoolfacebook.length);
        $("#like-pool-facebook-num").text(status.LikedPoolfacebookSize);
        $("#facebook-pool-num").text(status.facebookSize);
        $("#customRangefacebookFollows").val(status.MaxfacebookFollows);
        $("#customRangefacebookLikes").val(status.MaxfacebookLikes);

        $("#set-follow-facebook-check").prop("checked", status.StartfacebookFollow);
        $("#set-like-facebook-check").prop("checked", status.StartfacebookLike);
    } else if (dashboardMode == 6) {

        $("#follow-pool-pinterest-num").text(status.FollowedPoolPinterestSize);
        $("#like-pool-pinterest-num").text(status.LikedPoolPinterestSize);
        $("#pinterest-pool-num").text(status.PinterestSize);
        $("#customRangePinterestFollows").val(status.MaxPinterestFollows);
        $("#customRangePinterestLikes").val(status.MaxPinterestLikes);

        $("#follow_pinterest_set").html("Follows/day: " + status.MaxPinterestFollows);
        $("#like_pinterest_set").html("Likes/day: " + status.MaxPinterestLikes);

        $("#set-follow-pinterest-check").prop("checked", status.StartPinterestFollow);
        $("#set-like-pinterest-check").prop("checked", status.StartPinterestLike);
    } else if (dashboardMode == 0) {


        $("#user-pool-num").text(status.UserPoolSize);
        $("#follow-pool-num").text(status.FollowedPoolSize);
        $("#unfollow-pool-num").text(status.UnfollowedPoolSize);
        $("#like-pool-num").text(status.LikePoolSize);

        $("#story-pool-num").text(status.StoryCount);
        $("#comment-pool-num").text(status.CommentPoolSize);

        $("#customRange1").val(status.maxFollows);
        $("#customRange2").val(status.maxUnfollows);
        $("#customRange3").val(status.maxLikes);
        $("#customRange4").val(status.maxComments);
        $("#customRange5").val(status.maxStories);
        $("#follow_set").html("Follows/day: " + status.maxFollows);
        $("#unfollow_set").html("Unfollows/day: " + status.maxUnfollows);
        $("#like_set").html("Likes/day: " + status.maxLikes);
        $("#story_set").html("Stories/day: " + status.maxStories);
        $("#comment_set").html("DMs/day: " + status.maxComments);

        $("#set-follow-check").prop("checked", status.StartFollow);
        $("#set-unfollow-check").prop("checked", status.StartUnfollow);
        $("#set-story-check").prop("checked", status.StartStory);
        $("#set-like-check").prop("checked", status.StartLike);
        $("#set-comment-check").prop("checked", status.StartComment);
    } else if (dashboardMode == 2) {
        $("#follow-pool-twitter-num").text(status.FollowedPoolTwitter.length);
        $("#like-pool-twitter-num").text(status.LikedMediaTwitter.length);
        $("#customRangeTwitterFollows").val(status.MaxTwitterFollows);
        $("#customRangeTwitterLikes").val(status.MaxTwitterLikes);

        $("#follow_twitter_set").html("Retweets/day: " + status.MaxTwitterFollows);
        $("#like_twitter_set").html("Likes/day: " + status.MaxTwitterLikes);

        $("#set-follow-twitter-check").prop("checked", status.StartTwitterFollow);
        $("#set-like-twitter-check").prop("checked", status.StartTwitterLike);
    } else if (dashboardMode == 3) {


        $("#like-pool-tinder-num").text(status.LikedMediaTinder.length);
        $("#customRangeTinderLikes").val(status.MaxTinderLikes);
        $("#customRangeTinderComments").val(status.maxTinderComments);
        $("#comment_tinder_set").html("DMs/day: " + status.maxTinderComments);

        $("#like_tinder_set").html("Likes/day: " + status.MaxTinderLikes);
        $("#set-comment-tinder-check").prop("checked", status.StartComment);

        $("#set-like-tinder-check").prop("checked", status.StartTinderLike);
    } else if (dashboardMode == 5) {
        linkedin_data = status.linkedin_data;
        $("#follow-pool-linkedin-num").text(status.FollowedPoolLinkedin.length);

        $("#like-pool-linkedin-num").text(status.linkedin_data.length);
        $("#customRangeLinkedinLikes").val(status.MaxLinkedinLikes);
        $("#customRangeLinkedinFollows").val(status.maxLinkedinFollows);
        $("#follow_linkedin_set").html("Connections/day: " + status.MaxLinkedinFollows);

        $("#like_linkedin_set").html("Leads/day: " + status.MaxLinkedinLikes);
        $("#set-follow-Linkedin-check").prop("checked", status.StartLinkedinFollow);

        $("#set-like-Linkedin-check").prop("checked", status.StartLinkedinLike);
    }
    if (status.CurrentUser) {

        $("#overlay").hide();


        $(".img-current-user").attr("src", status.CurrentUser.user_pic_url);
        $(".img-current-user").show();
        if (typeof CurrentUser != "undefined" && CurrentUser.username != status.CurrentUser.username && status.CurrentUser.username.length > 0) {
            SendMessage("LoadAccount", "account", status.CurrentUser.username);

        }
        CurrentUser = status.CurrentUser;

        if (CurrentUser.username.length > 0 && postedInst == false) {
            postedInst = true;
            user_email = $("#email").attr("name");
            var user_plan = $("#plan").attr("name");

            $.post('https://instoo.com/user/postInst', {
                    email: user_email,
                    username: CurrentUser.username
                },
                function(returnedData) {
                    if (returnedData && returnedData.length > 1 && user_plan != "lifetime") {
                        $("#trial").show();
                        SetFollowValue(false);
                        SetUnfollowValue(false);
                        SetStoryValue(false);
                        $("#set-story-check").prop("checked", false);

                        $("#set-follow-check").prop("checked", false);
                        $("#set-unfollow-check").prop("checked", false);
                        $("#set-story-check").prop("checked", false);
                        $("#set-like-check").prop("checked", false);
                        $("#set-comment-check").prop("checked", false);
                    }
                });
        }

        $("#accounts").val(CurrentUser.username);

        if (started == false) {


            $("#errors").html("");
            var user_plan ="lifetime";
     
     
            if (status.CurrentUser.user_id) {
                var data2 = status.user_stats;
                if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                    data2 = [];
                }
                var chart_data = null;
                chart_data = [];
                follower_data = data2;
                var min = 10000000;
                var max = 0;

                var dailys = [];
                daily_data = dailys;
                var minimum = 10000;
                var labels = [];
                var counter = 0;
                var minimum = 10000;
                var labels = [];
                for (var index = data2.length - 1; index > data2.length - 100; index--) {
                    if (index >= 0) {
                        var obj = data2[index];
                        if (CurrentUser && obj.user_id == CurrentUser.user_id && (chart_data.length < 2 || Math.abs(parseInt(obj.followers) - chart_data[chart_data.length - 1]) < 200)) {
                            chart_data.push(
                                parseInt(obj.followers)
                            );
                            if (obj.followers > max) {
                                max = obj.followers;
                            }

                            if (obj.followers < min) {
                                min = obj.followers;
                            }
                            labels.push(counter);
                            counter++;
                            if (parseInt(obj.followers) < minimum) {
                                minimum = parseInt(obj.followers);
                            }
                        }
                    }
                }
                chart_data.reverse();

                if (chart_data.length > 1) {
                    $('#growth').html(max - min);
                    if (max - min > 100) {
                    }
                }
                let config = {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Instagram Followers',
                            backgroundColor: window.chartColors.red,
                            borderColor: window.chartColors.red,
                            data: chart_data,
                            fill: false,
                        }]
                    },
                    options: {
                        maintainAspectRatio: false,

                        responsive: true,
                        title: {
                            display: false,
                            text: 'Followers'
                        },
                        tooltips: {
                            mode: 'index',
                            intersect: false,
                        },
                        hover: {
                            mode: 'nearest',
                            intersect: true
                        },
                        scales: {
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Hour'
                                }
                            }],
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Folowers'
                                }
                            }]
                        }
                    }
                };

                let ctx = document.getElementById('canvas').getContext('2d');
                ctx.height = 250;

                let myLine = new Chart(ctx, config);

            }




            started = true;
            if (status.hoursLeft > 0) {
                setTimeout(function() {
                    hoursLeft = 0;
                    $("#set-follow-check").prop("checked", false);
                    SetFollowValue(false);
                    $("#set-like-check").prop("checked", false);
                    SetLikeValue(false);
                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    $("#set-unfollow-check").prop("checked", false);
                    SetUnfollowValue(false);
                    SendMessage("ZeroHour", "Database", "obj");

                    SetStoryValue(false);
                    $("#set-story-check").prop("checked", false);

                    $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Congrats! Instoo has run for a full day. All actions turned off after 8 hours automatically. Turn it on again tomorrow to grow constantly daily =)</div>");
                    var data2 = [];
                    if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                        data2 = [];
                    }
                    var chart_data = null;
                    chart_data = [];
                    var minimum = 10000;
                    var labels = [];
                    var min = 10000000;
                    var max = 0;


                    for (var index = 0; index < data2.length; index++) {
                        var obj = data2[index];
                        if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                            chart_data.push(
                                parseInt(obj.followers)
                            );

                        }

                    }

                    for (var kk = chart_data.length - 1; kk > chart_data.length - 11; kk--) {
                        if (chart_data[kk] < last_ten_min) {
                            last_ten_min = chart_data[kk];
                        }
                        if (chart_data[kk] > last_ten_max) {
                            last_ten_max = chart_data[kk];
                        }
                    }






                    var email_msg = "";
                    if (StoryPoolSize > 0 && Math.abs(last_ten_max - last_ten_min) > 5 && Math.abs(last_ten_max - last_ten_min) != 10000000 && Math.abs(last_ten_max - last_ten_min) < 1000) {
                        if (user_plan == "lifetime") {
                            email_msg = "Based on your activity logs, it appears you figured out how to use Instoo properly. We recommend a/b testing targets and photos to optimize your growth rate to 30-50 per day. Also increase your followers and following counter over 1000 to be able to use fast mode. If you have free time anytime, please consider leaving a short review: https://appsumo.com/instoo/#reviews";
                        } else {
                            email_msg = "Based on your activity logs, it appears you figured out how to use Instoo properly. We recommend a/b testing targets and photos to optimize your growth rate to 30-50 per day. Also increase your followers and following counter over 1000 to be able to use fast mode.";

                        }
                    }

                    if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize > 100 && Math.abs(last_ten_max - last_ten_min) == 0) {
                        email_msg = "Based on your activity logs, you did not gain followers despite running all day. We recommend changing targets and posting more photos with the same theme. Contact the live chat for help researching targets.";

                    }

                    if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize == 0 && activity_log.length == 0) {
                        email_msg = "Based on your activity logs, the bot did not actually run over 8 hours due to some setup issue. Please make sure to add 20 account targets, then enable the likes and follows switch. Then check the chrome is not de-activating the instagram tab by leaving it in focus for 1 hour. If chrome deactivates the tab, make sure to disable javascript throttling, and run Instoo in a chrome based browser by itself to multitask in chrome yourself. Contact the live chat for help researching targets.";

                    }

                    if (Math.abs(last_ten_max - last_ten_min) < 5 && LikePoolSize > 0 && StoryPoolSize / LikePoolSize > 10) {
                        email_msg = "Based on your activity logs, you ran many stories but few likes. It is possible chrome is de-activating the tab to save CPU. To test this theory, lease Instagram in focus while Instoo runs for 1 hour. You can run Instoo in another chrome based browser to solve this problem. Contact the live chat for help researching targets."
                    }


                    if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize > 0 && LikePoolSize == 0 && FollowedPoolSize == 0) {
                        email_msg = "Based on your activity logs, only stories ran. Please check this article to fix: https://help.instoo.com/kb/337/690/stories-only-working-but-not-likesfollowsunfollows. Contact the live chat for help researching targets.";
                    }

                    if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize > 0 && LikePoolSize > 0 && FollowedPoolSize == 0) {
                        email_msg = "Based on your activity logs, only stories + likes ran. We highly recommend using follows as well to trigger the Instagram promotion algorithm and achieve the average growth rates on fast mode. Contact the live chat for help researching targets.";
                    }

                    if(last_ten_min != 100000 && 
                        last_ten_max != 0){
                 
                }else{
                  
                }

                }, status.hoursLeft * 60 * 60 * 1000);
            }else{


                $("#set-follow-check").prop("checked", false);
                SetFollowValue(false);
                $("#set-like-check").prop("checked", false);
                SetLikeValue(false);
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);
                $("#set-unfollow-check").prop("checked", false);
                SetUnfollowValue(false);

                SetStoryValue(false);
                $("#set-story-check").prop("checked", false);

                $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Congrats! Instoo has run for a full day. All actions turned off after 8 hours automatically. Turn it on again tomorrow to grow constantly daily =) Click 'reset limits' on the settings page if the daily 8 hour counter has not reset today accidentally.</div>");
             
            }
            console.log("Hours left: " + status.hoursLeft * 60 * 60 * 1000);
            console.log(hoursLeft);
            console.log(status.hoursLeft);
            hoursLeft = status.hoursLeft;
            var loaded = false;

            var obj = [];
            SendMessage("loadLocal", "Database", "obj");



            

            getFollowers();

        }


    }






    UpdateCollectJobStatus(status.AccountTargets);
   if (status.StoryTime.Time / status.StoryTime.Max < -.05 && $("#set-story-check").is(':checked')) {

        $("#errors").html("<div class='alert alert-danger alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>You have not added any targets. Please add some account targets.</div>");
    }
    if (status.StartStory) {
        $("#container").html((status.StoryTime.Time).toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
    }


    if (mode == "twitter" && (status.StartTwitterLike || status.StartTwitterFollow)) {
        $("#container").html((status.TwitterTime.Time).toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
    }

    if (mode == "tiktok" && (status.StartTikTokLike || status.StartTikTokFollow)) {
        $("#container").html((status.TikTokTime.Time).toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
    }

    if (mode == "facebook" && (status.StartfacebookLike || status.StartfacebookFollow)) {
        $("#container").html((status.facebookTime.Time).toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
    }


    var d = new Date();

}

function NewWhitelistUserSearch(input) {
    var text = $(input).val().toLowerCase();
    var Request = {};
    Request.Text = text;
    Request.Count = 20;
    SendMessage("RequestFilteredFollowings", "Request", Request);
}

function FilterWhitelistSearch(input) {
    var text = $(input).val().toLowerCase();
    var whitelist_block = $("#whitelisted-users");
    $(whitelist_block).find("tr").each(function() {
        if ($(this).text().toLowerCase().indexOf(text) < 0 && text != "") {
            $(this).hide();
        } else {
            $(this).show();
        }
    });
}





function onLicenseFetched(error, status, response) {
    function extensionIconSettings(badgeColorObject, badgeText, extensionTitle) {
        chrome.browserAction.setBadgeBackgroundColor(badgeColorObject);
        chrome.browserAction.setBadgeText({
            text: badgeText
        });
        chrome.browserAction.setTitle({
            title: extensionTitle
        });
    }
    var licenseStatus = "";
    if (status === 200 && response) {
        response = JSON.parse(response);
        licenseStatus = parseLicense(response);
    } else {
        licenseStatus = "unknown";
    }
    if (licenseStatus) {
        if (licenseStatus === "Full") {
            window.localStorage.setItem('instooislicensed', 'true');
            extensionIconSettings({
                color: [0, 0, 0, 0]
            }, "", "Instoo is enabled.");
        } else if (licenseStatus === "None") {
            extensionIconSettings({
                color: [0, 0, 0, 0]
            }, "", "Instoo is enabled.");
           
        } else if (licenseStatus === "Free") {
            window.localStorage.setItem('instooislicensed', 'true');
            extensionIconSettings({
                color: [255, 0, 0, 0]
            }, "", window.localStorage.getItem('daysLeftInappnameTrial') + " days left in free trial.");
        } else if (licenseStatus === "unknown") {
           
            $("#purchase").hide();

            window.localStorage.setItem('instooislicensed', 'false');
            extensionIconSettings({
                color: [0, 0, 0, 0]
            }, "", "Instoo is enabled.");
        }
    }
    window.localStorage.setItem('appnameLicenseCheckComplete', 'true');
}


function parseLicense(license) {
    var TRIAL_PERIOD_DAYS = 300;
    var licenseStatusText;
    var licenceStatus;


    if (license.result && license.accessLevel == "FULL") {

        start_license = parseInt(license.createdTime, 10);




        $("#purchase").hide();
        $("#upgrade").hide();
        $(".sub-user").hide();

        paid_sub = true;

        $("#customRange1").attr("max", speed_limit);
        $("#customRange2").attr("max", speed_limit);
        $("#customRange3").attr("max", speed_limit);


        LicenseStatus = "Full";



    } else if (license.result && license.accessLevel == "FREE_TRIAL") {

        start_license = parseInt(license.createdTime, 10);

        var daysAgoLicenseIssued = Date.now() - parseInt(license.createdTime, 10);
        daysAgoLicenseIssued = daysAgoLicenseIssued / 1000 / 60 / 60 / 24;
        if (daysAgoLicenseIssued <= TRIAL_PERIOD_DAYS) {
            window.localStorage.setItem('daysLeftInCGTrial', TRIAL_PERIOD_DAYS - daysAgoLicenseIssued);
         
            $("#upgrade").hide();
    LicenseStatus = "Free";
        } else {
           

            LicenseStatus = "None";
        }
    } else {

        $("#upgrade").show();


        LicenseStatus = "None";
   
    }




    if (license.createdTime != null) {

        start_license = parseInt(license.createdTime, 10);

    }
    return LicenseStatus;
}




function xhrWithAuth(method, url, interactive, callback) {
    var retry = true;
    var access_token;
    getToken();

    function getToken() {
        chrome.identity.getAuthToken({
            interactive: interactive
        }, function(token) {
            if (chrome.runtime.lastError) {
                callback(chrome.runtime.lastError);
                return;
            }
            access_token = token;
            requestStart();
        });
    }

    function requestStart() {
        var xhr = new XMLHttpRequest();
        xhr.open(method, url);
        xhr.setRequestHeader('Authorization', 'Bearer ' + access_token);
        xhr.onreadystatechange = function(oEvent) {
            if (xhr.readyState === 4) {
                if (xhr.status === 401 && retry) {
                    retry = false;
                    chrome.identity.removeCachedAuthToken({
                            'token': access_token
                        },
                        getToken);
                } else if (xhr.status === 200) {
                    callback(null, xhr.status, xhr.response);
                }
            } else {
            }
        }
        try {
            xhr.send();
        } catch (e) {
        }
    }
}



function ClearWhitelistTable() {
    $("#whitelisted-users").empty();
}


function AddUserToWhitelist(input) {
    var user_id = $(input).attr("user_id");
    $(input).closest("li").remove();

    SendMessage("AddUserToWhitelist", "user_id", user_id);
}

function ProcessFilteredFollowings(users) {
    var filter_users_block = $("#add-user-results");
    filter_users_block.empty();
    for (var i = 0; i < users.length; i++) {
        var user = users[i];
        var userRow = `
    <li class="add-whitelist-user" user_id=` + user.user_id + `>
    <div class="row">
    <div class="col-md-2"> ` + i + `. <a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64'  height='64' src='` + user.user_pic_url + `'/></a></div>
    <div class='col-md-5 align-mid-vertical text-instafollow-td'>` + user.username + `</div><div class='col-md-5 text-instafollow-td align-mid-vertical'>` + user.full_name + `</div>
    </div>
    </li>
    `;

        $(filter_users_block).append(userRow);
    }
}

function AddedWhitelistUsers(users) {
    var whitelist_block = $("#whitelisted-users");
    for (var i = 0; i < users.length; i++) {
        var user = users[i];
        var userRow = `
    <tr>
    <td> ` + i + `. <a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
    <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.full_name + `</td>
    <td style="vertical-align: middle;">
    <button class="btn-danger remove-user-whitelist" user_id=` + user.user_id + `><i class="fas fa-times"></i></button></td>
    </tr>
    `;
        $(whitelist_block).prepend(userRow);
    }

    FilterWhitelistSearch($("#user-search"));
}

function UpdateCollectJobStatus(Jobs) {
    var collect_block = $("#collect-users-block");
    var collect_table = $(collect_block).find("tbody");
    $(collect_table).empty();
    var added_tags = [];
    ////////console.log(Jobs);
    for (var i = 0; i < Jobs.length; i++) {
        var user = Jobs[i];

        if (user != null) {
            added_tags.push(user);

            var index = global_accounts.indexOf(user + "<br>");
            if (index == -1) {
                global_accounts.push(user + "<br>");
            }

            var userRow = `
    <tr><td style="vertical-align: middle;">
    <button class="btn-danger remove-user-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
    <td class='align-mid-vertical text-instafollow-td'><a href='https://www.instagram.com/` + user + `/' target='_blank'>@
    ` + user + `</a></td>
    
    </tr>
    `;
            $(collect_table).prepend(userRow);
        }
    }
}

function UpdateCollectTags(Jobs) {
    var tag_block = $("#collect-tags-block");
    var tag_table = $(tag_block).find("tbody");
    $(tag_table).empty();
    var added_tags = [];
    for (var i = 0; i < Jobs.length; i++) {
        var index = global_tags.indexOf(Jobs[i].tag_name + "<br>");
        if (index == -1) {
            global_tags.push(Jobs[i].tag_name + "<br>");
        }

        var user = Jobs[i].tag_name;
        if (true) {
            added_tags.push(user);

            var userRow = `
    <tr><td style="vertical-align: middle;">
    <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
    <td>#</td>
    <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
    
    </tr>
    `;
            $(tag_table).prepend(userRow);
        }
    }
}

function HandleError(Error) {


}
var current_edit = 0;

window.addEventListener("message", (event) => {

    if (event.data.mode == "email") {
        linkedin_data[event.data.edit].email = prompt("Enter new email:");

    }

    if (event.data.mode == "sales") {
        linkedin_data[event.data.edit].sales = prompt("Enter new sales:");

    }
    if (event.data.mode == "target") {
        linkedin_data[event.data.edit].target = prompt("Enter new target:");

    }
    if (event.data.mode == "website") {
        linkedin_data[event.data.edit].website = prompt("Enter new website:");

    }
    if (event.data.mode == "connected") {
        linkedin_data[event.data.edit].connected = prompt("Enter new connected:");

    }
    if (event.data.mode == "birthday") {
        linkedin_data[event.data.edit].birthday = prompt("Enter new birthday:");

    }
    if (event.data.mode == "twitter") {
        linkedin_data[event.data.edit].twitter = prompt("Enter new twitter:");

    }
    if (event.data.mode == "Instaemail") {
        instagram_data[event.data.edit].email = prompt("Enter new email:");

    }

    if (event.data.mode == "Instasales") {
        instagram_data[event.data.edit].sales = prompt("Enter new sales:");

    }
    if (event.data.mode == "Instatarget") {
        instagram_data[event.data.edit].target = prompt("Enter new target:");

    }
    if (event.data.mode == "Instawebsite") {
        instagram_data[event.data.edit].website = prompt("Enter new website:");

    }
    if (event.data.mode == "Instaconnected") {
        instagram_data[event.data.edit].connected = prompt("Enter new connected:");

    }
    if (event.data.mode == "Instabirthday") {
        instagram_data[event.data.edit].birthday = prompt("Enter new birthday:");

    }
    if (event.data.mode == "Instatwitter") {
        instagram_data[event.data.edit].twitter = prompt("Enter new twitter:");

    }

    SendMessage("UpdateInstagramData", "instagram_data", instagram_data);
    var target_dic = {};

    SendMessage("UpdateLinkedinData", "linkedin_data", linkedin_data);
    var like_block = $("#crm-table");
    var like_table = $(like_block).find("tbody");
    $(like_table).empty();
    var html = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td></td><td>Contact</td><td>Email</td><td>Sales</td><td>Target</td><td>Website</td><td>Twitter</td><td>Birthday</td><td>Connected</td></tr>";
    for (var i = 0; i < linkedin_data.length; i++) {
        if (typeof linkedin_data[i] != "undefined")
            html += "<tr><td><img width='100px' src='" + linkedin_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='https://linkedin" + linkedin_data[i].url.split("linkedin")[1] + "'>" + linkedin_data[i].username + "</a></td><td><a href='#' onclick='editEmail(" + i + ")'>" + linkedin_data[i].email + "</a></td><td><a href='#' onclick='editSales(" + i + ")'>" + linkedin_data[i].sales + "</a></td><td><a href='#' onclick='editTargret(" + i + ")'>" + linkedin_data[i].target + "</a></td><td><a href='#' onclick='editWebsite(" + i + ")'>" + linkedin_data[i].website + "</a></td><td><a href='#' onclick='editTwitter(" + i + ")'>" + linkedin_data[i].twitter + "</a></td><td><a href='#' onclick='editBirthday(" + i + ")'>" + linkedin_data[i].birthday + "</a></td><td><a href='#' onclick='editConnected(" + i + ")'>" + linkedin_data[i].connected + "</a></td></tr>";
        if (linkedin_data[i].target in target_dic) {
            target_dic[linkedin_data[i].target].leads++;
            target_dic[linkedin_data[i].target].sales += parseInt(linkedin_data[i].sales);
            if (linkedin_data[i].connected != "none") {
                target_dic[linkedin_data[i].target].connected++;
            }
        } else {
            var did_connect = 0;
            if (linkedin_data[i].connected != "none") {
                did_connect = 1;
            }


            target_dic[linkedin_data[i].target] = {
                leads: 1,
                sales: parseInt(linkedin_data[i].sales),
                connected: did_connect
            };
        }

    }


    for (var i = 0; i < instagram_data.length; i++) {
        if (typeof instagram_data[i] != "undefined")
            html += "<tr><td><img width='100px' src='" + instagram_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='" + instagram_data[i].url + "'>" + instagram_data[i].username + "</a></td><td><a href='#' onclick='editInstaEmail(" + i + ")'>" + instagram_data[i].email + "</a></td><td><a href='#' onclick='editInstaSales(" + i + ")'>" + instagram_data[i].sales + "</a></td><td><a href='#' onclick='editInstaTargret(" + i + ")'>" + instagram_data[i].target + "</a></td><td><a href='#' onclick='editInstaWebsite(" + i + ")'>" + instagram_data[i].website + "</a></td><td><a href='#' onclick='editInstaTwitter(" + i + ")'>" + instagram_data[i].twitter + "</a></td><td><a href='#' onclick='editInstaBirthday(" + i + ")'>" + instagram_data[i].birthday + "</a></td><td><a href='#' onclick='editInstaConnected(" + i + ")'>" + instagram_data[i].connected + "</a></td></tr>";
        if (instagram_data[i].target in target_dic) {
            target_dic[instagram_data[i].target].leads++;
            target_dic[instagram_data[i].target].sales += parseInt(instagram_data[i].sales);
            if (instagram_data[i].connected != "none") {
                target_dic[instagram_data[i].target].connected++;
            }
        } else {

            var did_connect = 0;
            if (instagram_data[i].connected != "none") {
                did_connect = 1;
            }

            target_dic[instagram_data[i].target] = {
                leads: 1,
                sales: parseInt(instagram_data[i].sales),
                connected: did_connect
            };
        }

    }
    html += "</table><script>function editInstaConnected(num){ window.postMessage({mode: 'Instaconnected' ,edit: num} , '*');} function editInstaBirthday(num){ window.postMessage({mode: 'Instabirthday' ,edit: num} , '*');}function editInstaTwitter(num){ window.postMessage({mode: 'Instatwitter' ,edit: num} , '*');} function editInstaWebsite(num){ window.postMessage({mode: 'Instawebsite' ,edit: num} , '*');} function editInstaTarget(num){ window.postMessage({mode: 'Instatarget' ,edit: num} , '*');} function editInstaSales(num){ window.postMessage({mode: 'Instasales' ,edit: num} , '*');}function editInstaEmail(num){ window.postMessage({mode: 'Instaemail' ,edit: num} , '*');}function editConnected(num){ window.postMessage({mode: 'connected' ,edit: num} , '*');} function editBirthday(num){ window.postMessage({mode: 'birthday' ,edit: num} , '*');}function editTwitter(num){ window.postMessage({mode: 'twitter' ,edit: num} , '*');} function editWebsite(num){ window.postMessage({mode: 'website' ,edit: num} , '*');} function editTarget(num){ window.postMessage({mode: 'target' ,edit: num} , '*');} function editSales(num){ window.postMessage({mode: 'sales' ,edit: num} , '*');}function editEmail(num){ window.postMessage({mode: 'email' ,edit: num} , '*');}</script>";
    $(like_block).html(html);

    var target_block = $("#target-table");
    var target_table = $(target_block).find("tbody");
    $(target_table).empty();
    var html_target = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td>Target</td><td>Sales</td><td>Leads</td><td>Gained Followers</td></tr>";
    for (var key in target_dic) {
        if (target_dic.hasOwnProperty(key)) {
            html_target += "<tr><td>" + key + "</td><td>" + target_dic[key].sales + "</td><td> " + target_dic[key].leads + "</td><td>" + target_dic[key].connected + "</td></tr>";
        }

    }
    html_target += "</table>";

    $(target_block).html(html_target);


});

