function GotDatabase(database) {

    cloud_db = database;
    update_interval = true;
    if (!loadedAccounts) {
        if (document.getElementById("accounts")) {
            document.getElementById("accounts").remove();
        }
        var usernames = [];
        for (var kk = 0; kk < cloud_db.length; kk++) {
            usernames.push(cloud_db[kk].username);

        }
        var values = usernames;
        var select = document.createElement("select");
        select.name = "accounts";
        select.id = "accounts";
        select.style.width = "80%";
        SendMessage("LoadAccount", "account", selectedAccount);

        select.value = selectedAccount;
        for (const val of values) {
            var option = document.createElement("option");
            option.value = val;
            option.text = val.charAt(0).toUpperCase() + val.slice(1);
            select.appendChild(option);
        }
        loadedAccounts = true;
        select.addEventListener("click", function() {
            selectedAccount = this.value;
            SendMessage("LoadAccount", "account", this.value);

            let element = document.getElementById("accounts");
            element.value = this.value;
            $("#accounts").val(this.value);


        });

    }


}

function ImportDatabase(event) {
    var file = event.target.files[0];
    if (file) {
        var fileReader = new FileReader();
        fileReader.onload = function(event) {
            var content = event.target.result;
            SendMessage("ImportDatabase", "Database", content);
        }
        fileReader.readAsText(file);
    }
    alert("Loaded Database Successfully!");

}