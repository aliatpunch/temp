console.log('model.js script loaded');
window.chartColors = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(75, 192, 192)',
    blue: 'rgb(54, 162, 235)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(201, 203, 207)'
};

class IndexModel {
    constructor() {
        console.log('model.js created');
        window.addEventListener("message", this.handleMessageEvent)

        // super();
        // this.init();
    }
    getFollowers() {
        if (CurrentUser && CurrentUser.username) {

            $(".img-current-user").attr("src", CurrentUser.user_pic_url);

            $(".img-current-user").show();


            if (gotAnalytics == false) {
                gotAnalytics = true;
                chart_data = [];
                live_snapshots = [];
                live_tags = [];
                live_accounts = [];
                var ranked_accounts = "";
                var limits = 1000;
                if (paid_sub) {
                    limits = 1000;
                    var ranked_data = [];
                    var totals = 0;

                }

                var d = new Date();
                var currentHour = d.getHours();

                var d_num = Date.parse(d);
                d_num = Math.floor(d_num / (1000 * 60 * 60));
                var dat = {
                    followers: follow_count_num,
                    hour: d_num,
                    user_id: CurrentUser.user_id,
                    mode: mode
                };
                if (follow_count_num != 0) {
                    var data = {
                        followers: follow_count_num,
                        hour: d_num,
                        user_id: CurrentUser.user_id,
                        mode: "instagram"
                    };

                    this.SendMessage("PostStats", "data", data);

                }

            }
            var account_name = CurrentUser.username;



        }

    }

    roughSizeOfObject(object) {

        var objectList = [];
        var stack = [object];
        var bytes = 0;

        while (stack.length) {
            var value = stack.pop();

            if (typeof value === 'boolean') {
                bytes += 4;
            } else if (typeof value === 'string') {
                bytes += value.length * 2;
            } else if (typeof value === 'number') {
                bytes += 8;
            } else if (
                typeof value === 'object' &&
                objectList.indexOf(value) === -1
            ) {
                objectList.push(value);

                for (var i in value) {
                    stack.push(value[i]);
                }
            }
        }
        return bytes;
    }

    timer(ms) {
        return new Promise(res => setTimeout(res, ms));
    }

    async sendSched() {

        var now = new Date(stopDate);
        var daysOfYear = [];
        for (var d = new Date(startDate); d <= now; d.setDate(d.getDate() + 1)) {
            await this.timer(1000);

            var td = new Date(d);
            var newD = td.toISOString().split("T")[0];

        }
    }

    hashCode(str) {
        return str.split('').reduce((prevHash, currVal) =>
            (((prevHash << 5) - prevHash) + currVal.charCodeAt(0)) | 0, 0);
    }
    User(username, user_id, full_name, user_pic_url, followed_time) {
        this.username = username;
        this.user_id = user_id;
        this.full_name = full_name;
        this.user_pic_url = user_pic_url;
        this.followed_time = followed_time;
    }

    CreateComPort() {
        ComPort = chrome.runtime.connect({
            name: "instafollow213index"
        });
        ComPort.onMessage.addListener(OnMessageReceive);
    }

    SendMessage(tag, msgTag, msg) {
        var sendObj = {
            "Tag": tag
        };
        sendObj[msgTag] = msg;
        if (typeof ComPort != "undefined") {
            ComPort.postMessage(sendObj);
        }
    }
    checkObject(user_id, array) {
        for (var jj = 0; jj < array.length; jj++) {
            if (array[jj].target == user_id) {
                return [array[jj]];
            }
        }

        return [];
    }

    SaveSettings() {
        var settings = {};
        settings.FollowSettings = {};
        settings.UnfollowSettings = {};
        settings.CollectFollowers = {};
        settings.CollectFollowings = {};
        settings.LikeSettings = {};
        settings.CommentSettings = {};

        settings.FollowSettings.TimeMin = follow_speed;
        settings.FollowSettings.TimeMax = follow_speed + 10;
        settings.FollowSettings.ErrorTime = 200;

        settings.UnfollowSettings.TimeMin = unfollow_speed;
        settings.UnfollowSettings.TimeMax = unfollow_speed + 10;
        settings.UnfollowSettings.ErrorTime = 200;

        settings.CommentSettings.TimeMin = comment_speed;
        settings.CommentSettings.TimeMax = 450;
        settings.CommentSettings.ErrorTime = 1800;

        settings.LikeSettings.TimeMin = like_speed;
        settings.LikeSettings.TimeMax = like_speed + 10;
        settings.LikeSettings.ErrorTime = 200;

        settings.StorySettings.TimeMin = story_speed;
        settings.StorySettings.TimeMax = story_speed + 10;
        settings.StorySettings.ErrorTime = 400;

        settings.CollectFollowers.Pool = 1000;
        settings.CollectFollowers.Interval = 100;
        settings.CollectFollowers.ErrorTime = 200;

        settings.CollectFollowings.Pool = 1000;
        settings.CollectFollowings.Interval = 100;
        settings.CollectFollowings.ErrorTime = 200;

        settings.TikTokSettings.TimeMin = tiktok_speed;
        settings.TikTokSettings.TimeMax = tiktok_speed + 10;
        settings.TikTokSettings.ErrorTime = 400;


        settings.CollectFollowers.Pool = $("#input-user-pool-num").val();
        settings.CollectFollowers.Interval = $("#input-user-collect-time").val();
        settings.CollectFollowers.ErrorTime = $("#input-user-error-time").val();

        settings.CollectFollowings.Pool = $("#input-following-pool-num").val();
        settings.CollectFollowings.Interval = $("#input-following-collect-time").val();
        settings.CollectFollowings.ErrorTime = $("#input-following-error-time").val();
        UnfollowAfterDays = $("#input-unfollow-days").val();
        settings.UnfollowAfterDays = $("#input-unfollow-days").val();
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        settings.Day = dd;
        day = dd;

        SendMessage("UpdateSettings", "Settings", settings);




    }

    UpdateMediaStatus(Status) {
        if (mode == "crm") {
            var like_block = $("#crm-table");
            instagram_data = Status.linkedin_data;
            instagram_data = Status.instagram_data;
            var target_dic = {};
            var like_table = $(like_block).find("tbody");
            $(like_table).empty();
            var html = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td></td><td>Contact</td><td>Email</td><td>Sales</td><td>Target</td><td>Website</td><td>Twitter</td><td>Birthday</td><td>Connected</td></tr>";
            for (var i = 0; i < instagram_data.length; i++) {
                if (typeof instagram_data[i] != "undefined")
                    html += "<tr><td><img width='100px' src='" + instagram_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='https://linkedin" + instagram_data[i].url.split("linkedin")[1] + "'>" + instagram_data[i].username + "</a></td><td><a href='#' onclick='editEmail(" + i + ")'>" + instagram_data[i].email + "</a></td><td><a href='#' onclick='editSales(" + i + ")'>" + instagram_data[i].sales + "</a></td><td><a href='#' onclick='editTargret(" + i + ")'>" + instagram_data[i].target + "</a></td><td><a href='#' onclick='editWebsite(" + i + ")'>" + instagram_data[i].website + "</a></td><td><a href='#' onclick='editTwitter(" + i + ")'>" + instagram_data[i].twitter + "</a></td><td><a href='#' onclick='editBirthday(" + i + ")'>" + instagram_data[i].birthday + "</a></td><td><a href='#' onclick='editConnected(" + i + ")'>" + instagram_data[i].connected + "</a></td></tr>";
                if (instagram_data[i].target in target_dic) {
                    target_dic[instagram_data[i].target].leads++;
                    target_dic[instagram_data[i].target].sales += parseInt(instagram_data[i].sales);
                    if (instagram_data[i].connected != "none") {
                        target_dic[instagram_data[i].target].connected++;
                    }
                } else {
                    var did_connect = 0;
                    if (instagram_data[i].connected != "none") {
                        did_connect = 1;
                    }


                    target_dic[instagram_data[i].target] = {
                        leads: 1,
                        sales: parseInt(instagram_data[i].sales),
                        connected: did_connect
                    };
                }
            }

            for (var i = 0; i < instagram_data.length; i++) {
                if (typeof instagram_data[i] != "undefined")
                    html += "<tr><td><img width='100px' src='" + instagram_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='" + instagram_data[i].url + "'>" + instagram_data[i].username + "</a></td><td><a href='#' onclick='editInstaEmail(" + i + ")'>" + instagram_data[i].email + "</a></td><td><a href='#' onclick='editInstaSales(" + i + ")'>" + instagram_data[i].sales + "</a></td><td><a href='#' onclick='editInstaTargret(" + i + ")'>" + instagram_data[i].target + "</a></td><td><a href='#' onclick='editInstaWebsite(" + i + ")'>" + instagram_data[i].website + "</a></td><td><a href='#' onclick='editInstaTwitter(" + i + ")'>" + instagram_data[i].twitter + "</a></td><td><a href='#' onclick='editInstaBirthday(" + i + ")'>" + instagram_data[i].birthday + "</a></td><td><a href='#' onclick='editInstaConnected(" + i + ")'>" + instagram_data[i].connected + "</a></td></tr>";
                if (instagram_data[i].target in target_dic) {
                    target_dic[instagram_data[i].target].leads++;
                    target_dic[instagram_data[i].target].sales += parseInt(instagram_data[i].sales);
                    if (instagram_data[i].connected != "none") {
                        target_dic[instagram_data[i].target].connected++;
                    }
                } else {

                    var did_connect = 0;
                    if (instagram_data[i].connected != "none") {
                        did_connect = 1;
                    }

                    target_dic[instagram_data[i].target] = {
                        leads: 1,
                        sales: parseInt(instagram_data[i].sales),
                        connected: did_connect
                    };
                }
            }
            html += "</table><script>editInstaConnected(num){ window.postMessage({mode: 'Instaconnected' ,edit: num} , '*');} editInstaBirthday(num){ window.postMessage({mode: 'Instabirthday' ,edit: num} , '*');}editInstaTwitter(num){ window.postMessage({mode: 'Instatwitter' ,edit: num} , '*');} editInstaWebsite(num){ window.postMessage({mode: 'Instawebsite' ,edit: num} , '*');} editInstaTarget(num){ window.postMessage({mode: 'Instatarget' ,edit: num} , '*');} editInstaSales(num){ window.postMessage({mode: 'Instasales' ,edit: num} , '*');}editInstaEmail(num){ window.postMessage({mode: 'Instaemail' ,edit: num} , '*');}editConnected(num){ window.postMessage({mode: 'connected' ,edit: num} , '*');} editBirthday(num){ window.postMessage({mode: 'birthday' ,edit: num} , '*');}editTwitter(num){ window.postMessage({mode: 'twitter' ,edit: num} , '*');} editWebsite(num){ window.postMessage({mode: 'website' ,edit: num} , '*');} editTarget(num){ window.postMessage({mode: 'target' ,edit: num} , '*');} editSales(num){ window.postMessage({mode: 'sales' ,edit: num} , '*');}editEmail(num){ window.postMessage({mode: 'email' ,edit: num} , '*');}</script>";


            $(like_block).prepend(html);


            var target_block = $("#target-table");
            var target_table = $(target_block).find("tbody");
            $(target_table).empty();
            var html_target = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td>Target</td><td>Sales</td><td>Leads</td><td>Gained Followers</td></tr>";
            for (var key in target_dic) {
                if (target_dic.hasOwnProperty(key)) {
                    html_target += "<tr><td>" + key + "</td><td>" + target_dic[key].sales + "</td><td> " + target_dic[key].leads + "</td><td>" + target_dic[key].connected + "</td></tr>";
                }

            }
            html_target += "</table>";

            $(target_block).html(html_target);

        } else
            if (mode == "instagram") {
                var like_block = $("#like-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMedias.length; i++) {
                    this.OnLikedMedia(Status.LikedMedias[i]);
                }
                var story_block = $("#story-block");
                var story_table = $(story_block).find("tbody");
                $(story_table).empty();

                for (var i = 0; i < Status.StoryMedia.length; i++) {

                    this.OnStoryMedia(Status.StoryMedia[i]);
                }


                var comment_block = $("#comment-block");
                var comment_table = $(comment_block).find("tbody");
                $(comment_table).empty();

                for (var i = 0; i < Status.CommentedMedias.length; i++) {
                    this.OnCommentedMedia(Status.CommentedMedias[i]);
                }




                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.Tags.length; i++) {
                    var index = global_tags.indexOf(Status.Tags[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.Tags[i].tag_name + "<br>");
                    }

                    var user = Status.Tags[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }
                var tag_block2 = $("#collect-locations-block");
                var tag_table2 = $(tag_block2).find("tbody");
                $(tag_table2).empty();
                for (var i = 0; i < Status.Locations.length; i++) {
                    if (index == -1) {
                    }

                    var user = Status.Locations[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-location-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table2).prepend(userRow);
                    }
                }

                var tag_block3 = $("#collect-comments-block");
                var tag_table3 = $(tag_block3).find("tbody");
                $(tag_table3).empty();
                for (var i = 0; i < Status.Comments.length; i++) {
                    if (index == -1) {
                    }

                    var user = Status.Comments[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-comment-collect" user_id="` + user + `"><i class="fas fa-times"></i></button></td>
        
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table3).prepend(userRow);
                    }
                }


            } else if (mode == "twitter") {
                var like_block = $("#like-twitter-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediaTwitter.length; i++) {
                    if (Status.LikedMediaTwitter[i]) {
                        this.OnLikedMediaTwitter(Status.LikedMediaTwitter[i]);
                    }
                }
                var follow_block = $("#follow-block-twitter");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolTwitter.length; i++) {
                    if (Status.FollowedPoolTwitter[i]) {
                        this.OnFollowedUserTwitter(Status.FollowedPoolTwitter[i]);
                    }
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagPoolTwitter.length; i++) {
                    var index = global_tags.indexOf(Status.TagPoolTwitter[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagPoolTwitter[i].tag_name + "<br>");
                    }

                    var user = Status.TagPoolTwitter[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td></td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "tiktok") {
                var like_block = $("#like-tiktok-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediaTikTok.length; i++) {
                    this.OnLikedMediaTikTok(Status.LikedMediaTikTok[i]);
                }
                var follow_block = $("#follow-block-tiktok");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolTikTok.length; i++) {
                    this.OnFollowedUserTikTok(Status.FollowedPoolTikTok[i]);
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagsTikTok.length; i++) {
                    var index = global_tags.indexOf(Status.TagsTikTok[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagsTikTok[i].tag_name + "<br>");
                    }

                    var user = Status.TagsTikTok[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "facebook") {
                var like_block = $("#like-facebook-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediafacebook.length; i++) {
                    this.OnLikedMediafacebook(Status.LikedMediafacebook[i]);
                }
                var follow_block = $("#follow-block-facebook");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolfacebook.length; i++) {
                    this.OnFollowedUserfacebook(Status.FollowedPoolfacebook[i]);
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                // console.log(Status);
                var added_tags = [];
                for (var i = 0; i < Status.Tagsfacebook.length; i++) {
                    var index = global_tags.indexOf(Status.Tagsfacebook[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.Tagsfacebook[i].tag_name + "<br>");
                    }

                    var user = Status.Tagsfacebook[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);

                    }
                }



                var tag_block = $("#collect-accounts-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                console.log(Status);
                var added_tags = [];
                for (var i = 0; i < Status.AccountPoolfacebook.length; i++) {
                    var index = global_tags.indexOf(Status.AccountPoolfacebook[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.AccountPoolfacebook[i].tag_name + "<br>");
                    }

                    var user = Status.AccountPoolfacebook[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);


                    }

                }

            } else if (mode == "pinterest") {
                var like_block = $("#like-pinterest-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediaPinterest.length; i++) {
                    this.OnLikedMediaPinterest(Status.LikedMediaPinterest[i]);
                }
                var follow_block = $("#follow-block-pinterest");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolPinterest.length; i++) {
                    this.OnFollowedUserPinterest(Status.FollowedPoolPinterest[i]);
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagsPinterest.length; i++) {
                    var index = global_tags.indexOf(Status.TagsPinterest[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagsPinterest[i].tag_name + "<br>");
                    }

                    var user = Status.TagsPinterest[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "linkedin") {
                var like_block = $("#like-linkedin-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.linkedin_data.length; i++) {
                    this.OnLikedMediaLinkedin(Status.linkedin_data[i]);
                }
                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagPoolLinkedin.length; i++) {
                    var index = global_tags.indexOf(Status.TagPoolLinkedin[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagPoolLinkedin[i].tag_name + "<br>");
                    }

                    var user = Status.TagPoolLinkedin[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "tinder") {

                var tag_block3 = $("#collect-comments-block");
                var tag_table3 = $(tag_block3).find("tbody");
                $(tag_table3).empty();
                for (var i = 0; i < Status.CommentsTinder.length; i++) {


                    var user = Status.CommentsTinder[i].tag_name;
                    if (true) {

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-comment-collect" user_id="` + user + `"><i class="fas fa-times"></i></button></td>
        
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table3).prepend(userRow);
                    }
                }

            }
    }

    UpdateFollowStatus(AllUsers) {
        var FollowedUsers = AllUsers.FollowedUsers;
        var UnfollowedUsers = AllUsers.UnfollowedUsers;

        var follow_block = $("#follow-block");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).empty()

        var unfollow_block = $("#unfollow-block");
        var unfollow_table = $(unfollow_block).find("tbody");
        $(unfollow_table).empty();

        for (var i = 0; i < FollowedUsers.length; i++) {
            this.OnFollowedUser(FollowedUsers[i]);
        }

        for (var i = 0; i < UnfollowedUsers.length; i++) {
            this.OnUnfollowedUser(UnfollowedUsers[i]);
        }
    }

    OnStoryMedia(user) {
        var userRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.full_name + `(@` + user.target + `)</td>
      </tr>
      `;

        var follow_block = $("#story-block");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserTwitter(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-twitter");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserLinkedin(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-linkedin");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserPinterest(user) {
        //console.log(user);
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-pinterest");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserTikTok(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-tiktok");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserfacebook(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-facebook");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUser(user) {
        var userRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.full_name + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnUnfollowedUser(user) {
        var userRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td>
      </tr>
      `;

        var unfollow_block = $("#unfollow-block");
        var unfollow_table = $(unfollow_block).find("tbody");
        $(unfollow_table).prepend(userRow);

        var table_rows = $(unfollow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }

    }

    OnLikedMediaLinkedin(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='https://linkedin` + media.url.split("linkedin")[1] + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-linkedin-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaTwitter(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-twitter-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaTinder(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='https://` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-tinder-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaPinterest(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-pinterest-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaTikTok(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-tiktok-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediafacebook(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-facebook-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMedia(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + media.shortcode + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.media_src + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.shortcode + `</td>
      </tr>
      `;

        var like_bock = $("#like-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnCommentedMedia(media) {
        var mediaRow = `
      <tr>
      <td><a href='https://www.instagram.com` + media.shortcode + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + media.media_src + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.caption + `</td>
      </tr>
      `;

        var like_bock = $("#comment-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }
    ResetSettings() {
        this.SendMessage("ResetSettings", "", "");
    }
    SetWhitelistStatus(status) {
        $("#whitelist-followings").prop("checked", status.Enabled);

    }

    RemoveWhitelistedUser(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();

        this.SendMessage("RemoveWhitelistUser", "user_id", user_id);
    }

    RemoveCollectJobTagLinkedin(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();


        this.SendMessage("RemoveTagFromListLinkedin", "TagName", user_id);
        var index = global_tags.indexOf(user_id);
        if (index > -1) {
            global_tags.splice(index, 1);
        }
        this.SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


    }

    RemoveCollectJobTagPinterest(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();


        this.SendMessage("RemoveTagFromListPinterest", "TagName", user_id);
        var index = global_tags.indexOf(user_id);
        if (index > -1) {
            global_tags.splice(index, 1);
        }
        this.SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


    }

    RemoveCollectJobTagTikTok(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();


        this.SendMessage("RemoveTagFromListTikTok", "TagName", user_id);
        var index = global_tags.indexOf(user_id);
        if (index > -1) {
            global_tags.splice(index, 1);
        }
        this.SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


    }

    RemoveCollectJobTagfacebook(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();


        this.SendMessage("RemoveTagFromListfacebook", "TagName", user_id);
        var index = global_tags.indexOf(user_id);
        if (index > -1) {
            global_tags.splice(index, 1);
        }
        this.SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


    }

    RemoveCollectJobTagTwitter(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();


        this.SendMessage("RemoveTagFromListTwitter", "TagName", user_id);
        var index = global_tags.indexOf(user_id);
        if (index > -1) {
            global_tags.splice(index, 1);
        }
        this.SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


    }

    RemoveCollectJobTag(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();


        this.SendMessage("RemoveTagFromList", "TagName", user_id);
        var index = global_tags.indexOf(user_id);
        if (index > -1) {
            global_tags.splice(index, 1);
        }
        this.SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


    }

    RemoveLocationJobTag(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();


        this.SendMessage("RemoveLocationFromList", "TagName", user_id);
        if (index > -1) {
        }
        this.SendMessage("RequestMediaStatus", "Num", DisplayLikesNum);


    }

    RemoveCollectJobUser(button) {
        var user_id = $(button).attr("user_id");
        $(button).closest("tr").remove();
        this.SendMessage("RemoveCollectJob", "user_id", user_id);
        this.SendMessage("RemoveAccountFromList", "TagName", user_id);
    }

    UpdateFollowers(status) {
        my_followers = my_followers.concat(status);
        this.SendMessage("SendMyFollowers", "followers", my_followers);

    }


    UpdateAccountsDict(status) {
        account_dict = status;


    }

    UpdateTagsDict(status) {
        hashtag_dict = status;


    }

    UpdateStatus(status) {
        const outerThis = this;

        hoursLeft = status.hoursLeft;


        if (updated_cloud) {
            if (this.roughSizeOfObject(cloud_db) < 15000000) {


            }
            updated_cloud = false;
        }
        if (emailed == false && follow_count_num < 1000 && follow_count_num != 0) {
            this.SendMessage("SetSpeed", "Num", 2);

            $("#fast").removeClass('active');
            $("#slow").removeClass('active');
            $("#medium").addClass('active');

            $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account with under 1,000 followers. Speeds will naturally ramp up to 2x faster after you pass 1,000 followers.<br><br></div>");

        }


        if (emailed == false && following_count_num < 1000 && following_count_num != 0) {
            this.SendMessage("SetSpeed", "Num", 2);

            $("#fast").removeClass('active');
            $("#slow").removeClass('active');
            $("#medium").addClass('active');

            $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account that is following under 1000 other users(as in people you follow). Speeds will naturally ramp up to 2x faster after you follow more than 1000 users.<br><br></div>");

        }
        if (emailed == false && following_count_num < 200 && following_count_num != 0) {

            $("#fast").removeClass('active');
            $("#slow").addClass('active');
            $("#medium").removeClass('active');

            this.SendMessage("SetSpeed", "Num", 8);
            $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account, following under 200 users(meaning users you follow). Please pause Instoo and manually follow over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers and following. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. <br><br></div>");
            alert("Instoo has detected you have a smaller account, following under 200 users(meaning users you follow). Please pause Instoo and manually follow over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers and following. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. ");

            this.SetFollowValue(false);
            this.SetUnfollowValue(false);
            this.SetStoryValue(false);
            $("#set-story-check").prop("checked", false);

            $("#set-follow-check").prop("checked", false);
            $("#set-unfollow-check").prop("checked", false);
            $("#set-story-check").prop("checked", false);
            $("#set-like-check").prop("checked", false);
            $("#set-comment-check").prop("checked", false);
            if (emailed == false) {

                emailed = true;
            }
        }


        if (emailed == false && follow_count_num < 200 && follow_count_num != 0) {


            this.SendMessage("SetSpeed", "Num", 8);


            $("#fast").removeClass('active');
            $("#slow").addClass('active');
            $("#medium").removeClass('active');

            $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button> Instoo has detected you have a smaller account with under 200 followers. Please pause Instoo and manually raise your followers over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. <br><br></div>");
            alert(" Instoo has detected you have a smaller account with under 200 followers. Please pause Instoo and manually raise your followers over 200, since Instoo allows medium(4x faster speeds) after 200. You should post photos regularly, and use the account by liking/following until you pass 200 followers. This takes most users a few days. Then it takes most users 1-2 months on medium mode to reach 1,000 followers, which allows fast mode. Contact the live chat to request target research from our account manager to help start. ");

            this.SetFollowValue(false);
            this.SetUnfollowValue(false);
            this.SetStoryValue(false);
            $("#set-story-check").prop("checked", false);

            $("#set-follow-check").prop("checked", false);
            $("#set-unfollow-check").prop("checked", false);
            $("#set-story-check").prop("checked", false);
            $("#set-like-check").prop("checked", false);
            $("#set-comment-check").prop("checked", false);
            if (emailed == false) {

                emailed = true;
            }
        }
        // console.log(status);
        user_stats = status.user_stats;
        reacts = status.reacts;
        StartReact = status.StartReact;
        EnableFilters = status.EnableFilters;
        unfollow_mode = status.unfollow_mode;
        activity_log = status.activity_log;
        blacklist = status.blacklist;
        filters = status.filters;
        minFollowing = status.minFollowing;
        maxFollowing = status.maxFollowing;
        minPhotos = status.minPhotos;
        minFollowers = status.minFollowers;
        maxFollowers = status.maxFollowers;

        user_followers = status.user_followers;
        analytics = status.true_analytics;
        IdealTargets = status.IdealTargets;
        DMMode = status.backgroundDMs;
        addIdeal = status.addIdeal;
        unfollowInstoo = status.unfollowInstoo;
        collectSelfFollowers = status.collectSelfFollowers;
        if (status.UserPool.length > 1000 || status.MediaPool.length > 1000) {
            this.SendMessage("ClearMemory", "story", "");
        }

        UnfollowedPoolSize = status.UnfollowedPoolSize;
        FollowedPoolSize = status.FollowedPoolSize;
        LikePoolSize = status.LikePoolSize;
        StoryPoolSize = status.StoryPoolSize;
        CommentPoolSize = status.CommentPoolSize;

        if (dashboardMode == 1) {

            $("#follow-pool-tiktok-num").text(status.FollowedPoolTikTokSize);
            $("#like-pool-tiktok-num").text(status.LikedPoolTikTokSize);
            $("#tiktok-pool-num").text(status.TikTokSize);
            $("#customRangeTikTokFollows").val(status.MaxTikTokFollows);
            $("#customRangeTikTokLikes").val(status.MaxTikTokLikes);

            $("#follow_tiktok_set").html("Follows/day: " + status.MaxTikTokFollows);
            $("#like_tiktok_set").html("Likes/day: " + status.MaxTikTokLikes);

            $("#set-follow-tiktok-check").prop("checked", status.StartTikTokFollow);
            $("#set-like-tiktok-check").prop("checked", status.StartTikTokLike);
        } else if (dashboardMode == 7) {

            $("#follow_facebook_set").html("Friends/day: " + status.MaxfacebookFollows);
            $("#like_facebook_set").html("Likes/day: " + status.MaxfacebookLikes);

            $("#follow-pool-facebook-num").text(status.FollowedPoolfacebook.length);
            $("#like-pool-facebook-num").text(status.LikedPoolfacebookSize);
            $("#facebook-pool-num").text(status.facebookSize);
            $("#customRangefacebookFollows").val(status.MaxfacebookFollows);
            $("#customRangefacebookLikes").val(status.MaxfacebookLikes);

            $("#set-follow-facebook-check").prop("checked", status.StartfacebookFollow);
            $("#set-like-facebook-check").prop("checked", status.StartfacebookLike);
        } else if (dashboardMode == 6) {

            $("#follow-pool-pinterest-num").text(status.FollowedPoolPinterestSize);
            $("#like-pool-pinterest-num").text(status.LikedPoolPinterestSize);
            $("#pinterest-pool-num").text(status.PinterestSize);
            $("#customRangePinterestFollows").val(status.MaxPinterestFollows);
            $("#customRangePinterestLikes").val(status.MaxPinterestLikes);

            $("#follow_pinterest_set").html("Follows/day: " + status.MaxPinterestFollows);
            $("#like_pinterest_set").html("Likes/day: " + status.MaxPinterestLikes);

            $("#set-follow-pinterest-check").prop("checked", status.StartPinterestFollow);
            $("#set-like-pinterest-check").prop("checked", status.StartPinterestLike);
        } else if (dashboardMode == 0) {


            $("#user-pool-num").text(status.UserPoolSize);
            $("#follow-pool-num").text(status.FollowedPoolSize);
            $("#unfollow-pool-num").text(status.UnfollowedPoolSize);
            $("#like-pool-num").text(status.LikePoolSize);

            $("#story-pool-num").text(status.StoryCount);
            $("#comment-pool-num").text(status.CommentPoolSize);

            $("#customRange1").val(status.maxFollows);
            $("#customRange2").val(status.maxUnfollows);
            $("#customRange3").val(status.maxLikes);
            $("#customRange4").val(status.maxComments);
            $("#customRange5").val(status.maxStories);
            $("#follow_set").html("Follows/day: " + status.maxFollows);
            $("#unfollow_set").html("Unfollows/day: " + status.maxUnfollows);
            $("#like_set").html("Likes/day: " + status.maxLikes);
            $("#story_set").html("Stories/day: " + status.maxStories);
            $("#comment_set").html("DMs/day: " + status.maxComments);

            $("#set-follow-check").prop("checked", status.StartFollow);
            $("#set-unfollow-check").prop("checked", status.StartUnfollow);
            $("#set-story-check").prop("checked", status.StartStory);
            $("#set-like-check").prop("checked", status.StartLike);
            $("#set-comment-check").prop("checked", status.StartComment);
        } else if (dashboardMode == 2) {
            $("#follow-pool-twitter-num").text(status.FollowedPoolTwitter.length);
            $("#like-pool-twitter-num").text(status.LikedMediaTwitter.length);
            $("#customRangeTwitterFollows").val(status.MaxTwitterFollows);
            $("#customRangeTwitterLikes").val(status.MaxTwitterLikes);

            $("#follow_twitter_set").html("Retweets/day: " + status.MaxTwitterFollows);
            $("#like_twitter_set").html("Likes/day: " + status.MaxTwitterLikes);

            $("#set-follow-twitter-check").prop("checked", status.StartTwitterFollow);
            $("#set-like-twitter-check").prop("checked", status.StartTwitterLike);
        } else if (dashboardMode == 3) {


            $("#like-pool-tinder-num").text(status.LikedMediaTinder.length);
            $("#customRangeTinderLikes").val(status.MaxTinderLikes);
            $("#customRangeTinderComments").val(status.maxTinderComments);
            $("#comment_tinder_set").html("DMs/day: " + status.maxTinderComments);

            $("#like_tinder_set").html("Likes/day: " + status.MaxTinderLikes);
            $("#set-comment-tinder-check").prop("checked", status.StartComment);

            $("#set-like-tinder-check").prop("checked", status.StartTinderLike);
        } else if (dashboardMode == 5) {
            instagram_data = status.linkedin_data;
            $("#follow-pool-linkedin-num").text(status.FollowedPoolLinkedin.length);

            $("#like-pool-linkedin-num").text(status.linkedin_data.length);
            $("#customRangeLinkedinLikes").val(status.MaxLinkedinLikes);
            $("#customRangeLinkedinFollows").val(status.maxLinkedinFollows);
            $("#follow_linkedin_set").html("Connections/day: " + status.MaxLinkedinFollows);

            $("#like_linkedin_set").html("Leads/day: " + status.MaxLinkedinLikes);
            $("#set-follow-Linkedin-check").prop("checked", status.StartLinkedinFollow);

            $("#set-like-Linkedin-check").prop("checked", status.StartLinkedinLike);
        }
        if (status.CurrentUser) {

            $("#overlay").hide();


            $(".img-current-user").attr("src", status.CurrentUser.user_pic_url);
            $(".img-current-user").show();
            if (typeof CurrentUser != "undefined" && CurrentUser.username != status.CurrentUser.username && status.CurrentUser.username.length > 0) {
                this.SendMessage("LoadAccount", "account", status.CurrentUser.username);

            }
            CurrentUser = status.CurrentUser;

            if (CurrentUser.username.length > 0 && postedInst == false) {
                postedInst = true;
                user_email = $("#email").attr("name");
                var user_plan = $("#plan").attr("name");

                $.post('https://instoo.com/user/postInst', {
                    email: user_email,
                    username: CurrentUser.username
                },
                    function (returnedData) {
                        if (returnedData && returnedData.length > 1 && user_plan != "lifetime") {
                            $("#trial").show();
                            outerThis.SetFollowValue(false);
                            outerThis.SetUnfollowValue(false);
                            outerThis.SetStoryValue(false);
                            $("#set-story-check").prop("checked", false);

                            $("#set-follow-check").prop("checked", false);
                            $("#set-unfollow-check").prop("checked", false);
                            $("#set-story-check").prop("checked", false);
                            $("#set-like-check").prop("checked", false);
                            $("#set-comment-check").prop("checked", false);
                        }
                    });
            }

            $("#accounts").val(CurrentUser.username);

            if (started == false) {


                $("#errors").html("");
                var user_plan = "lifetime";


                if (status.CurrentUser.user_id) {
                    var data2 = status.user_stats;
                    if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                        data2 = [];
                    }
                    var chart_data = null;
                    chart_data = [];
                    follower_data = data2;
                    var min = 10000000;
                    var max = 0;

                    var dailys = [];
                    daily_data = dailys;
                    var minimum = 10000;
                    var labels = [];
                    var counter = 0;
                    var minimum = 10000;
                    var labels = [];
                    for (var index = data2.length - 1; index > data2.length - 100; index--) {
                        if (index >= 0) {
                            var obj = data2[index];
                            if (CurrentUser && obj.user_id == CurrentUser.user_id && (chart_data.length < 2 || Math.abs(parseInt(obj.followers) - chart_data[chart_data.length - 1]) < 200)) {
                                chart_data.push(
                                    parseInt(obj.followers)
                                );
                                if (obj.followers > max) {
                                    max = obj.followers;
                                }

                                if (obj.followers < min) {
                                    min = obj.followers;
                                }
                                labels.push(counter);
                                counter++;
                                if (parseInt(obj.followers) < minimum) {
                                    minimum = parseInt(obj.followers);
                                }
                            }
                        }
                    }
                    chart_data.reverse();

                    if (chart_data.length > 1) {
                        $('#growth').html(max - min);
                        if (max - min > 100) {
                        }
                    }
                    let config = {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Instagram Followers',
                                backgroundColor: window.chartColors.red,
                                borderColor: window.chartColors.red,
                                data: chart_data,
                                fill: false,
                            }]
                        },
                        options: {
                            maintainAspectRatio: false,

                            responsive: true,
                            title: {
                                display: false,
                                text: 'Followers'
                            },
                            tooltips: {
                                mode: 'index',
                                intersect: false,
                            },
                            hover: {
                                mode: 'nearest',
                                intersect: true
                            },
                            scales: {
                                xAxes: [{
                                    display: true,
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Hour'
                                    }
                                }],
                                yAxes: [{
                                    display: true,
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Folowers'
                                    }
                                }]
                            }
                        }
                    };

                    let ctx = document.getElementById('canvas').getContext('2d');
                    ctx.height = 250;

                    let myLine = new Chart(ctx, config);

                }




                started = true;
                if (status.hoursLeft > 0) {
                    setTimeout(function () {
                        hoursLeft = 0;
                        $("#set-follow-check").prop("checked", false);
                        outerThis.SetFollowValue(false);

                        $("#set-like-check").prop("checked", false);
                        outerThis.SetLikeValue(false);
                        $("#set-unfollow-check").prop("checked", false);
                        outerThis.SetUnfollowValue(false);
                        $("#set-unfollow-check").prop("checked", false);
                        outerThis.SetUnfollowValue(false);
                        outerThis.SendMessage("ZeroHour", "Database", "obj");

                        outerThis.SetStoryValue(false);
                        $("#set-story-check").prop("checked", false);

                        $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Congrats! Instoo has run for a full day. All actions turned off after 8 hours automatically. Turn it on again tomorrow to grow constantly daily =)</div>");
                        var data2 = [];
                        if ($("#data2").attr("name") && $("#data2").attr("name").length > 2) {
                            data2 = [];
                        }
                        var chart_data = null;
                        chart_data = [];
                        var minimum = 10000;
                        var labels = [];
                        var min = 10000000;
                        var max = 0;


                        for (var index = 0; index < data2.length; index++) {
                            var obj = data2[index];
                            if (CurrentUser && obj.user_id == CurrentUser.user_id) {
                                chart_data.push(
                                    parseInt(obj.followers)
                                );

                            }

                        }

                        for (var kk = chart_data.length - 1; kk > chart_data.length - 11; kk--) {
                            if (chart_data[kk] < last_ten_min) {
                                last_ten_min = chart_data[kk];
                            }
                            if (chart_data[kk] > last_ten_max) {
                                last_ten_max = chart_data[kk];
                            }
                        }






                        var email_msg = "";
                        if (StoryPoolSize > 0 && Math.abs(last_ten_max - last_ten_min) > 5 && Math.abs(last_ten_max - last_ten_min) != 10000000 && Math.abs(last_ten_max - last_ten_min) < 1000) {
                            if (user_plan == "lifetime") {
                                email_msg = "Based on your activity logs, it appears you figured out how to use Instoo properly. We recommend a/b testing targets and photos to optimize your growth rate to 30-50 per day. Also increase your followers and following counter over 1000 to be able to use fast mode. If you have free time anytime, please consider leaving a short review: https://appsumo.com/instoo/#reviews";
                            } else {
                                email_msg = "Based on your activity logs, it appears you figured out how to use Instoo properly. We recommend a/b testing targets and photos to optimize your growth rate to 30-50 per day. Also increase your followers and following counter over 1000 to be able to use fast mode.";

                            }
                        }

                        if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize > 100 && Math.abs(last_ten_max - last_ten_min) == 0) {
                            email_msg = "Based on your activity logs, you did not gain followers despite running all day. We recommend changing targets and posting more photos with the same theme. Contact the live chat for help researching targets.";

                        }

                        if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize == 0 && activity_log.length == 0) {
                            email_msg = "Based on your activity logs, the bot did not actually run over 8 hours due to some setup issue. Please make sure to add 20 account targets, then enable the likes and follows switch. Then check the chrome is not de-activating the instagram tab by leaving it in focus for 1 hour. If chrome deactivates the tab, make sure to disable javascript throttling, and run Instoo in a chrome based browser by itself to multitask in chrome yourself. Contact the live chat for help researching targets.";

                        }

                        if (Math.abs(last_ten_max - last_ten_min) < 5 && LikePoolSize > 0 && StoryPoolSize / LikePoolSize > 10) {
                            email_msg = "Based on your activity logs, you ran many stories but few likes. It is possible chrome is de-activating the tab to save CPU. To test this theory, lease Instagram in focus while Instoo runs for 1 hour. You can run Instoo in another chrome based browser to solve this problem. Contact the live chat for help researching targets."
                        }


                        if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize > 0 && LikePoolSize == 0 && FollowedPoolSize == 0) {
                            email_msg = "Based on your activity logs, only stories ran. Please check this article to fix: https://help.instoo.com/kb/337/690/stories-only-working-but-not-likesfollowsunfollows. Contact the live chat for help researching targets.";
                        }

                        if (Math.abs(last_ten_max - last_ten_min) < 5 && StoryPoolSize > 0 && LikePoolSize > 0 && FollowedPoolSize == 0) {
                            email_msg = "Based on your activity logs, only stories + likes ran. We highly recommend using follows as well to trigger the Instagram promotion algorithm and achieve the average growth rates on fast mode. Contact the live chat for help researching targets.";
                        }

                        if (last_ten_min != 100000 &&
                            last_ten_max != 0) {

                        } else {

                        }

                    }, status.hoursLeft * 60 * 60 * 1000);
                } else {


                    $("#set-follow-check").prop("checked", false);
                    this.SetFollowValue(false);
                    $("#set-like-check").prop("checked", false);
                    this.SetLikeValue(false);
                    $("#set-unfollow-check").prop("checked", false);
                    this.SetUnfollowValue(false);
                    $("#set-unfollow-check").prop("checked", false);
                    this.SetUnfollowValue(false);

                    this.SetStoryValue(false);
                    $("#set-story-check").prop("checked", false);

                    $("#errors").html("<div class='alert alert-success alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>Congrats! Instoo has run for a full day. All actions turned off after 8 hours automatically. Turn it on again tomorrow to grow constantly daily =) Click 'reset limits' on the settings page if the daily 8 hour counter has not reset today accidentally.</div>");

                }
                console.log("Hours left: " + status.hoursLeft * 60 * 60 * 1000);
                console.log(hoursLeft);
                console.log(status.hoursLeft);
                hoursLeft = status.hoursLeft;
                var loaded = false;

                var obj = [];
                this.SendMessage("loadLocal", "Database", "obj");
                this.getFollowers();

            }


        }






        this.UpdateCollectJobStatus(status.AccountTargets);
        if (status.StoryTime.Time / status.StoryTime.Max < -.05 && $("#set-story-check").is(':checked')) {

            $("#errors").html("<div class='alert alert-danger alert-dismissible' role='alert'><button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>You have not added any targets. Please add some account targets.</div>");
        }
        if (status.StartStory) {
            $("#container").html((status.StoryTime.Time)?.toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
        }


        if (mode == "twitter" && (status.StartTwitterLike || status.StartTwitterFollow)) {
            $("#container").html((status.TwitterTime.Time)?.toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
        }

        if (mode == "tiktok" && (status.StartTikTokLike || status.StartTikTokFollow)) {
            $("#container").html((status.TikTokTime.Time)?.toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
        }

        if (mode == "facebook" && (status.StartfacebookLike || status.StartfacebookFollow)) {
            $("#container").html((status.facebookTime.Time)?.toFixed(0) + " seconds till next action<br>" + hoursLeft + " Hours Left Today");
        }


        var d = new Date();

    }

    NewWhitelistUserSearch(input) {
        var text = $(input).val().toLowerCase();
        var Request = {};
        Request.Text = text;
        Request.Count = 20;
        this.SendMessage("RequestFilteredFollowings", "Request", Request);
    }

    FilterWhitelistSearch(input) {
        var text = $(input).val().toLowerCase();
        var whitelist_block = $("#whitelisted-users");
        $(whitelist_block).find("tr").each(function () {
            if ($(this).text().toLowerCase().indexOf(text) < 0 && text != "") {
                $(this).hide();
            } else {
                $(this).show();
            }
        });
    }
    onLicenseFetched(error, status, response) {
        function extensionIconSettings(badgeColorObject, badgeText, extensionTitle) {
            chrome.browserAction.setBadgeBackgroundColor(badgeColorObject);
            chrome.browserAction.setBadgeText({
                text: badgeText
            });
            chrome.browserAction.setTitle({
                title: extensionTitle
            });
        }
        var licenseStatus = "";
        if (status === 200 && response) {
            response = JSON.parse(response);
            licenseStatus = this.parseLicense(response);
        } else {
            licenseStatus = "unknown";
        }
        if (licenseStatus) {
            if (licenseStatus === "Full") {
                window.localStorage.setItem('instooislicensed', 'true');
                extensionIconSettings({
                    color: [0, 0, 0, 0]
                }, "", "Instoo is enabled.");
            } else if (licenseStatus === "None") {
                extensionIconSettings({
                    color: [0, 0, 0, 0]
                }, "", "Instoo is enabled.");

            } else if (licenseStatus === "Free") {
                window.localStorage.setItem('instooislicensed', 'true');
                extensionIconSettings({
                    color: [255, 0, 0, 0]
                }, "", window.localStorage.getItem('daysLeftInappnameTrial') + " days left in free trial.");
            } else if (licenseStatus === "unknown") {

                $("#purchase").hide();

                window.localStorage.setItem('instooislicensed', 'false');
                extensionIconSettings({
                    color: [0, 0, 0, 0]
                }, "", "Instoo is enabled.");
            }
        }
        window.localStorage.setItem('appnameLicenseCheckComplete', 'true');
    }


    parseLicense(license) {
        var TRIAL_PERIOD_DAYS = 300;
        var licenseStatusText;
        var licenceStatus;


        if (license.result && license.accessLevel == "FULL") {

            start_license = parseInt(license.createdTime, 10);




            $("#purchase").hide();
            $("#upgrade").hide();
            $(".sub-user").hide();

            paid_sub = true;

            $("#customRange1").attr("max", speed_limit);
            $("#customRange2").attr("max", speed_limit);
            $("#customRange3").attr("max", speed_limit);


            LicenseStatus = "Full";



        } else if (license.result && license.accessLevel == "FREE_TRIAL") {

            start_license = parseInt(license.createdTime, 10);

            var daysAgoLicenseIssued = Date.now() - parseInt(license.createdTime, 10);
            daysAgoLicenseIssued = daysAgoLicenseIssued / 1000 / 60 / 60 / 24;
            if (daysAgoLicenseIssued <= TRIAL_PERIOD_DAYS) {
                window.localStorage.setItem('daysLeftInCGTrial', TRIAL_PERIOD_DAYS - daysAgoLicenseIssued);

                $("#upgrade").hide();
                LicenseStatus = "Free";
            } else {


                LicenseStatus = "None";
            }
        } else {

            $("#upgrade").show();


            LicenseStatus = "None";

        }




        if (license.createdTime != null) {

            start_license = parseInt(license.createdTime, 10);

        }
        return LicenseStatus;
    }
    xhrWithAuth(method, url, interactive, callback) {
        var retry = true;
        var access_token;
        getToken();

        function getToken() {
            chrome.identity.getAuthToken({
                interactive: interactive
            }, function (token) {
                if (chrome.runtime.lastError) {
                    callback(chrome.runtime.lastError);
                    return;
                }
                access_token = token;
                requestStart();
            });
        }

        function requestStart() {
            var xhr = new XMLHttpRequest();
            xhr.open(method, url);
            xhr.setRequestHeader('Authorization', 'Bearer ' + access_token);
            xhr.onreadystatechange = function (oEvent) {
                if (xhr.readyState === 4) {
                    if (xhr.status === 401 && retry) {
                        retry = false;
                        chrome.identity.removeCachedAuthToken({
                            'token': access_token
                        },
                            getToken);
                    } else if (xhr.status === 200) {
                        callback(null, xhr.status, xhr.response);
                    }
                } else {
                }
            }
            try {
                xhr.send();
            } catch (e) {
            }
        }
    }

    ClearWhitelistTable() {
        $("#whitelisted-users").empty();
    }
    
    AddUserToWhitelist(input) {
        var user_id = $(input).attr("user_id");
        $(input).closest("li").remove();

        this.SendMessage("AddUserToWhitelist", "user_id", user_id);
    }

    ProcessFilteredFollowings(users) {
        var filter_users_block = $("#add-user-results");
        filter_users_block.empty();
        for (var i = 0; i < users.length; i++) {
            var user = users[i];
            var userRow = `
    <li class="add-whitelist-user" user_id=` + user.user_id + `>
    <div class="row">
    <div class="col-md-2"> ` + i + `. <a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64'  height='64' src='` + user.user_pic_url + `'/></a></div>
    <div class='col-md-5 align-mid-vertical text-instafollow-td'>` + user.username + `</div><div class='col-md-5 text-instafollow-td align-mid-vertical'>` + user.full_name + `</div>
    </div>
    </li>
    `;

            $(filter_users_block).append(userRow);
        }
    }

    AddedWhitelistUsers(users) {
        var whitelist_block = $("#whitelisted-users");
        for (var i = 0; i < users.length; i++) {
            var user = users[i];
            var userRow = `
    <tr>
    <td> ` + i + `. <a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
    <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.full_name + `</td>
    <td style="vertical-align: middle;">
    <button class="btn-danger remove-user-whitelist" user_id=` + user.user_id + `><i class="fas fa-times"></i></button></td>
    </tr>
    `;
            $(whitelist_block).prepend(userRow);
        }

        this.FilterWhitelistSearch($("#user-search"));
    }

    UpdateCollectJobStatus(Jobs) {
        var collect_block = $("#collect-users-block");
        var collect_table = $(collect_block).find("tbody");
        $(collect_table).empty();
        var added_tags = [];
        ////////console.log(Jobs);
        for (var i = 0; i < Jobs.length; i++) {
            var user = Jobs[i];

            if (user != null) {
                added_tags.push(user);

                var index = global_accounts.indexOf(user + "<br>");
                if (index == -1) {
                    global_accounts.push(user + "<br>");
                }

                var userRow = `
    <tr><td style="vertical-align: middle;">
    <button class="btn-danger remove-user-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
    <td class='align-mid-vertical text-instafollow-td'><a href='https://www.instagram.com/` + user + `/' target='_blank'>@
    ` + user + `</a></td>
    
    </tr>
    `;
                $(collect_table).prepend(userRow);
            }
        }
    }

    UpdateCollectTags(Jobs) {
        var tag_block = $("#collect-tags-block");
        var tag_table = $(tag_block).find("tbody");
        $(tag_table).empty();
        var added_tags = [];
        for (var i = 0; i < Jobs.length; i++) {
            var index = global_tags.indexOf(Jobs[i].tag_name + "<br>");
            if (index == -1) {
                global_tags.push(Jobs[i].tag_name + "<br>");
            }

            var user = Jobs[i].tag_name;
            if (true) {
                added_tags.push(user);

                var userRow = `
    <tr><td style="vertical-align: middle;">
    <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
    <td>#</td>
    <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
    
    </tr>
    `;
                $(tag_table).prepend(userRow);
            }
        }
    }
    ImportDatabase(event) {
        var file = event.target.files[0];
        if (file) {
            var fileReader = new FileReader();
            fileReader.onload = function (event) {
                var content = event.target.result;
                this.SendMessage("ImportDatabase", "Database", content);
            }
            fileReader.readAsText(file);
        }
        alert("Loaded Database Successfully!");
    }
    GotDatabase(database) {

        cloud_db = database;
        update_interval = true;
        if (!loadedAccounts) {
            if (document.getElementById("accounts")) {
                document.getElementById("accounts").remove();
            }
            var usernames = [];
            for (var kk = 0; kk < cloud_db.length; kk++) {
                usernames.push(cloud_db[kk].username);

            }
            var values = usernames;
            var select = document.createElement("select");
            select.name = "accounts";
            select.id = "accounts";
            select.style.width = "80%";
            this.SendMessage("LoadAccount", "account", selectedAccount);

            select.value = selectedAccount;
            for (const val of values) {
                var option = document.createElement("option");
                option.value = val;
                option.text = val.charAt(0).toUpperCase() + val.slice(1);
                select.appendChild(option);
            }
            loadedAccounts = true;
            select.addEventListener("click", function () {
                selectedAccount = this.value;
                this.SendMessage("LoadAccount", "account", this.value);

                let element = document.getElementById("accounts");
                element.value = this.value;
                $("#accounts").val(this.value);


            });

        }


    }
    handleMessageEvent(event) {

        if (event.data.mode == "email") {
            instagram_data[event.data.edit].email = prompt("Enter new email:");

        }

        if (event.data.mode == "sales") {
            instagram_data[event.data.edit].sales = prompt("Enter new sales:");

        }
        if (event.data.mode == "target") {
            instagram_data[event.data.edit].target = prompt("Enter new target:");

        }
        if (event.data.mode == "website") {
            instagram_data[event.data.edit].website = prompt("Enter new website:");

        }
        if (event.data.mode == "connected") {
            instagram_data[event.data.edit].connected = prompt("Enter new connected:");

        }
        if (event.data.mode == "birthday") {
            instagram_data[event.data.edit].birthday = prompt("Enter new birthday:");

        }
        if (event.data.mode == "twitter") {
            instagram_data[event.data.edit].twitter = prompt("Enter new twitter:");

        }
        if (event.data.mode == "Instaemail") {
            instagram_data[event.data.edit].email = prompt("Enter new email:");

        }

        if (event.data.mode == "Instasales") {
            instagram_data[event.data.edit].sales = prompt("Enter new sales:");

        }
        if (event.data.mode == "Instatarget") {
            instagram_data[event.data.edit].target = prompt("Enter new target:");

        }
        if (event.data.mode == "Instawebsite") {
            instagram_data[event.data.edit].website = prompt("Enter new website:");

        }
        if (event.data.mode == "Instaconnected") {
            instagram_data[event.data.edit].connected = prompt("Enter new connected:");

        }
        if (event.data.mode == "Instabirthday") {
            instagram_data[event.data.edit].birthday = prompt("Enter new birthday:");

        }
        if (event.data.mode == "Instatwitter") {
            instagram_data[event.data.edit].twitter = prompt("Enter new twitter:");

        }

        this.SendMessage("UpdateInstagramData", "instagram_data", instagram_data);
        var target_dic = {};

        this.SendMessage("UpdateLinkedinData", "linkedin_data", instagram_data);
        var like_block = $("#crm-table");
        var like_table = $(like_block).find("tbody");
        $(like_table).empty();
        var html = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td></td><td>Contact</td><td>Email</td><td>Sales</td><td>Target</td><td>Website</td><td>Twitter</td><td>Birthday</td><td>Connected</td></tr>";
        for (var i = 0; i < instagram_data.length; i++) {
            if (typeof instagram_data[i] != "undefined")
                html += "<tr><td><img width='100px' src='" + instagram_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='https://linkedin" + instagram_data[i].url.split("linkedin")[1] + "'>" + instagram_data[i].username + "</a></td><td><a href='#' onclick='editEmail(" + i + ")'>" + instagram_data[i].email + "</a></td><td><a href='#' onclick='editSales(" + i + ")'>" + instagram_data[i].sales + "</a></td><td><a href='#' onclick='editTargret(" + i + ")'>" + instagram_data[i].target + "</a></td><td><a href='#' onclick='editWebsite(" + i + ")'>" + instagram_data[i].website + "</a></td><td><a href='#' onclick='editTwitter(" + i + ")'>" + instagram_data[i].twitter + "</a></td><td><a href='#' onclick='editBirthday(" + i + ")'>" + instagram_data[i].birthday + "</a></td><td><a href='#' onclick='editConnected(" + i + ")'>" + instagram_data[i].connected + "</a></td></tr>";
            if (instagram_data[i].target in target_dic) {
                target_dic[instagram_data[i].target].leads++;
                target_dic[instagram_data[i].target].sales += parseInt(instagram_data[i].sales);
                if (instagram_data[i].connected != "none") {
                    target_dic[instagram_data[i].target].connected++;
                }
            } else {
                var did_connect = 0;
                if (instagram_data[i].connected != "none") {
                    did_connect = 1;
                }


                target_dic[instagram_data[i].target] = {
                    leads: 1,
                    sales: parseInt(instagram_data[i].sales),
                    connected: did_connect
                };
            }

        }


        for (var i = 0; i < instagram_data.length; i++) {
            if (typeof instagram_data[i] != "undefined")
                html += "<tr><td><img width='100px' src='" + instagram_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='" + instagram_data[i].url + "'>" + instagram_data[i].username + "</a></td><td><a href='#' onclick='editInstaEmail(" + i + ")'>" + instagram_data[i].email + "</a></td><td><a href='#' onclick='editInstaSales(" + i + ")'>" + instagram_data[i].sales + "</a></td><td><a href='#' onclick='editInstaTargret(" + i + ")'>" + instagram_data[i].target + "</a></td><td><a href='#' onclick='editInstaWebsite(" + i + ")'>" + instagram_data[i].website + "</a></td><td><a href='#' onclick='editInstaTwitter(" + i + ")'>" + instagram_data[i].twitter + "</a></td><td><a href='#' onclick='editInstaBirthday(" + i + ")'>" + instagram_data[i].birthday + "</a></td><td><a href='#' onclick='editInstaConnected(" + i + ")'>" + instagram_data[i].connected + "</a></td></tr>";
            if (instagram_data[i].target in target_dic) {
                target_dic[instagram_data[i].target].leads++;
                target_dic[instagram_data[i].target].sales += parseInt(instagram_data[i].sales);
                if (instagram_data[i].connected != "none") {
                    target_dic[instagram_data[i].target].connected++;
                }
            } else {

                var did_connect = 0;
                if (instagram_data[i].connected != "none") {
                    did_connect = 1;
                }

                target_dic[instagram_data[i].target] = {
                    leads: 1,
                    sales: parseInt(instagram_data[i].sales),
                    connected: did_connect
                };
            }

        }
        html += "</table><script>  editInstaConnected(num){ window.postMessage({mode: 'Instaconnected' ,edit: num} , '*');}   editInstaBirthday(num){ window.postMessage({mode: 'Instabirthday' ,edit: num} , '*');}  editInstaTwitter(num){ window.postMessage({mode: 'Instatwitter' ,edit: num} , '*');}   editInstaWebsite(num){ window.postMessage({mode: 'Instawebsite' ,edit: num} , '*');}   editInstaTarget(num){ window.postMessage({mode: 'Instatarget' ,edit: num} , '*');}   editInstaSales(num){ window.postMessage({mode: 'Instasales' ,edit: num} , '*');}  editInstaEmail(num){ window.postMessage({mode: 'Instaemail' ,edit: num} , '*');}  editConnected(num){ window.postMessage({mode: 'connected' ,edit: num} , '*');}   editBirthday(num){ window.postMessage({mode: 'birthday' ,edit: num} , '*');}  editTwitter(num){ window.postMessage({mode: 'twitter' ,edit: num} , '*');}   editWebsite(num){ window.postMessage({mode: 'website' ,edit: num} , '*');}   editTarget(num){ window.postMessage({mode: 'target' ,edit: num} , '*');}   editSales(num){ window.postMessage({mode: 'sales' ,edit: num} , '*');}  editEmail(num){ window.postMessage({mode: 'email' ,edit: num} , '*');}</script>";
        $(like_block).html(html);

        var target_block = $("#target-table");
        var target_table = $(target_block).find("tbody");
        $(target_table).empty();
        var html_target = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td>Target</td><td>Sales</td><td>Leads</td><td>Gained Followers</td></tr>";
        for (var key in target_dic) {
            if (target_dic.hasOwnProperty(key)) {
                html_target += "<tr><td>" + key + "</td><td>" + target_dic[key].sales + "</td><td> " + target_dic[key].leads + "</td><td>" + target_dic[key].connected + "</td></tr>";
            }

        }
        html_target += "</table>";

        $(target_block).html(html_target);


    };


}



Array.prototype.unique = function () {
    var a = this.concat();
    for (var i = 0; i < a.length; ++i) {
        for (var j = i + 1; j < a.length; ++j) {
            if (a[i] === a[j])
                a.splice(j--, 1);
        }
    }

    return a;
};
Date.prototype.isSameDateAs = function (pDate) {
    return (
        this.getFullYear() === pDate.getFullYear() &&
        this.getMonth() === pDate.getMonth() &&
        this.getDate() === pDate.getDate()
    );
}

