console.log('tinder2.js script loaded');

class TinderModel {
    constructor() {
        this.ComPort = null;
        this.CurrentUser = null;
        this.LastUsername = "";
        this.SharedData = null;
        this.UserTag = "._7UhW9";
        this.StartStory = false;
        this.msg_user = "";
        this.tag_dict = {};
        this.account_dict = {};
        this.that = this;
        this.image_src = "";
        this.story_set = false;
    }

    CreateComPort() {
        this.ComPort = chrome.runtime.connect({
            name: "tinder"
        });
        this.ComPort.onMessage.addListener(this.OnMessageReceive.bind(this));

        window.addEventListener("message", (event) => {
            if (event.source != window) return;
            if (event.data.Tag && (event.data.Tag == "SharedData")) {
                this.SharedData = event.data.SharedData;
            }
        }, false);
    }

    OnMessageReceive(msg) {
        console.log(msg);

        if (msg.Tag == "UpdateTinder") {
            // Handle UpdateTinder message
        } else if (msg.Tag == "LikeFollow") {
            console.log(msg.story);
            if (msg.story.StartTinderLike && msg.story.LikedMediaTinderSize < msg.story.MaxTinderLikes) {
                setTimeout(() => {
                    let username;
                    let img;
                    const spans = document.getElementsByTagName('span');
                    for (let kk = 0; kk < spans.length; kk++) {
                        if (spans[kk].getAttribute("itemprop") == "name") {
                            username = spans[kk].innerText;
                        }
                    }

                    const divs = document.getElementsByTagName('div');
                    for (let kk = 0; kk < divs.length; kk++) {
                        if (divs[kk].getAttribute("aria-label") == username && divs[kk].getAttribute("style")) {
                            img = divs[kk].getAttribute("style").split('"')[1];
                        }
                    }
                    console.log(img);
                    console.log(username);
                    const msg_data = { url: "tinder.com", username: username, img: img };
                    const buttons = document.getElementsByTagName('button');
                    for (let kk = 0; kk < buttons.length; kk++) {
                        if (buttons[kk].innerHTML.includes("Like") && !buttons[kk].innerHTML.includes("Super Like")) {
                            buttons[kk].click();
                            console.log(buttons[kk]);
                            break;
                        }
                    }

                    this.SendMessage("DoneTinderLike", "User", msg_data);
                    setTimeout(() => {
                        const buttons = document.getElementsByTagName('button');
                        for (let kk = 0; kk < buttons.length; kk++) {
                            if (buttons[kk].innerText.includes("NO THANKS")) {
                                buttons[kk].click();
                                break;
                            }
                        }
                    }, 5000);
                }, 4000);
            }
        }
    }

    SendMessage(tag, msgTag, msg) {
        const sendObj = { "Tag": tag };
        sendObj[msgTag] = msg;
        console.log(sendObj);
        console.log(this.ComPort);
        this.ComPort.postMessage(sendObj);
    }
}

class TinderView {
    constructor(controller) {
        this.controller = controller;
        $(document).ready(this.onDocumentReady.bind(this));
    }

    onDocumentReady() {
        this.controller.CreateComPort();
        console.log("SETUp!");
        if (window.location.href.includes("tag")) {
            window.scrollTo(0, document.body.scrollHeight);
            this.scrollTop(20);
        }
    }

    scrollTop(starter) {
        if (starter > 0) {
            window.scrollTo(0, document.body.scrollHeight);
            setTimeout(() => {
                this.scrollTop(starter - 1);
            }, 300);
        }
    }
}

class TinderController {
    constructor(model) {
        this.model = model;
    }

    CreateComPort() {
        this.model.CreateComPort();
    }

    SendMessage(tag, msgTag, msg) {
        this.model.SendMessage(tag, msgTag, msg);
    }
}

const model = new TinderModel();
const controller = new TinderController(model);
const view = new TinderView(controller);