console.log('twitter.js script loaded');

class TwitterModel {
    constructor() {
        this.ComPort = null;
        this.CurrentUser = null;
        this.LastUsername = "";
        this.SharedData = null;
        this.lastMsg = null;
        this.UserTag = "._7UhW9";
        this.StartStory = false;
        this.msg_user = "";
        this.tag_dict = {};
        this.account_dict = {};
        this.that = this;
        this.image_src = "";
        this.story_set = false;
    }

    CreateComPort() {
        this.ComPort = chrome.runtime.connect({
            name: "twitter"
        });
        this.ComPort.onMessage.addListener(this.OnMessageReceive.bind(this));

        window.addEventListener("message", (event) => {
            if (event.source != window) return;
            if (event.data.Tag && (event.data.Tag == "SharedData")) {
                this.SharedData = event.data.SharedData;
            }
        }, false);
    }

    OnMessageReceive(msg) {
        console.log(msg);
        this.lastMsg = msg;
        if (msg.Tag == "UpdateTwitter") {
            console.log(msg.story);
        } else if (msg.Tag == "LikeFollow") {
            this.scrollLike(3);
        }
    }

    scrollLike(num) {
        window.scrollBy(0, 600);
        const links = document.getElementsByTagName('div');

        if (num > 0) {
            const timer = this.getRandomInt(50000, 120000);
            setTimeout(() => {
                this.scrollLike(num - 1);
            }, timer);
        }

        for (let kk = 0; kk < links.length; kk++) {
            if (links[kk] && links[kk].getAttribute("aria-label") && links[kk].getAttribute("aria-label").includes("Like") && links[kk].getAttribute("data-testid") && links[kk].getAttribute("data-testid") == "like") {
                const url = window.location.href;
                const username = links[kk].parentNode.parentNode.parentNode.parentNode.parentNode.firstElementChild.firstElementChild.firstElementChild.firstElementChild.getAttribute("href").split("/").join("");
                const img = links[kk].parentNode.parentNode.parentNode.parentNode.parentNode.firstElementChild.firstElementChild.firstElementChild.firstElementChild.children[0].children[1].children[0].children[1].getAttribute("src");
                const msg_data = { url: url, username: username, img: img };

                if (this.lastMsg.story.StartTwitterLike) {
                    links[kk].click();
                    this.SendMessage("DoneTwitterLike", "User", msg_data);
                }

                setTimeout(() => {
                    links[kk].parentNode.parentNode.children[1].children[0].click();
                    setTimeout(() => {
                        const links2 = document.getElementsByTagName('div');
                        for (let kk = 0; kk < links2.length; kk++) {
                            if (links2[kk].getAttribute("testid") && links2[kk].getAttribute("testid").includes("tweetButton") && this.lastMsg.story.StartTwitterFollow) {
                                links2[kk].firstElementChild.firstElementChild.firstElementChild.click();
                                this.SendMessage("DoneTwitterRetweet", "User", msg_data);
                            }
                        }

                        const spans = document.getElementsByTagName('span');
                        for (let kk = 0; kk < spans.length; kk++) {
                            if (spans[kk].innerHTML.includes("Retweet") && this.lastMsg.story.StartTwitterFollow) {
                                spans[kk].click();
                                this.SendMessage("DoneTwitterRetweet", "User", msg_data);
                            }
                        }
                    }, 5000);

                    setTimeout(() => {
                        const spans = document.getElementsByTagName('span');
                        for (let kk = 0; kk < spans.length; kk++) {
                            if (spans[kk].innerText.includes("Retweet") && this.lastMsg.story.StartTwitterFollow) {
                                spans[kk].click();
                                this.SendMessage("DoneTwitterRetweet", "User", msg_data);
                            }
                        }
                    }, 5000);
                }, 1000);

                break;
            }
        }
    }

    getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    SendMessage(tag, msgTag, msg) {
        const sendObj = { "Tag": tag };
        sendObj[msgTag] = msg;
        console.log(sendObj);
        console.log(this.ComPort);
        this.ComPort.postMessage(sendObj);
    }
}

class TwitterView {
    constructor(controller) {
        this.controller = controller;
        $(document).ready(this.onDocumentReady.bind(this));
    }

    onDocumentReady() {
        this.controller.CreateComPort();
        console.log("SETUp!");
    }

    scrollTop(starter) {
        if (starter > 0) {
            window.scrollTo(0, document.body.scrollHeight);
            setTimeout(() => {
                this.scrollTop(starter - 1);
            }, 300);
        }
    }
}

class TwitterController {
    constructor(model) {
        this.model = model;
    }

    CreateComPort() {
        this.model.CreateComPort();
    }

    SendMessage(tag, msgTag, msg) {
        this.model.SendMessage(tag, msgTag, msg);
    }
}

const model = new TwitterModel();
const controller = new TwitterController(model);
const view = new TwitterView(controller);