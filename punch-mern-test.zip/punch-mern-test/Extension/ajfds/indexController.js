console.log('controller.js script loaded');
class IndexController extends IndexModel{
    constructor(model) {
        console.log('IndexController constructor called');
        this.model = model;
        // this.master = master;
    }

    getFollowers() {
        this.model.getFollowers();
    }
    roughSizeOfObject(object) {
        this.model.roughSizeOfObject(object);
    }
    CreateComPort() {
        this.model.CreateComPort();
    }
    SendMessage(tag, msgTag, msg) {
        this.model.SendMessage(tag, msgTag, msg);
    }
    SaveSettings() {
        this.model.SaveSettings();
    }
    UpdateMediaStatus(Status) {
        this.model.UpdateMediaStatus(Status);
    }
    UpdateFollowStatus(AllUsers) {
        this.model.UpdateFollowStatus(AllUsers);
    }
    OnStoryMedia(user) {
        this.model.OnStoryMedia(user);
    }
    OnFollowedUserTwitter(user) {
        this.model.OnFollowedUserTwitter(user);
    }
    OnFollowedUserLinkedin(user) {
        this.model.OnFollowedUserLinkedin(user);
    }
    OnFollowedUserPinterest(user) {
        this.model.OnFollowedUserPinterest(user);
    }
    OnFollowedUserTikTok(user) {
        this.model.OnFollowedUserTikTok(user);
    }
    OnFollowedUserfacebook(user) {
        this.model.OnFollowedUserfacebook(user);
    }
    OnFollowedUser(user) {
        this.model.OnFollowedUser(user);
    }
    OnUnfollowedUser(user) {
        this.model.OnUnfollowedUser(user);
    }
    OnLikedMediaLinkedin(media) {
        this.model.OnLikedMediaLinkedin(media);
    }
    OnLikedMediaTwitter(media) {
        this.model.OnLikedMediaTwitter(media);
    }
    OnLikedMediaTinder(media) {
        this.model.OnLikedMediaTinder(media);
    }
    OnLikedMediaPinterest(media) {
        this.model.OnLikedMediaPinterest(media);
    }
    OnLikedMediaTikTok(media) {
        this.model.OnLikedMediaTikTok(media);
    }
    OnLikedMediafacebook(media) {
        this.model.OnLikedMediafacebook(media);
    }
    OnLikedMedia(media) {
        this.model.OnLikedMedia(media);
    }
    OnCommentedMedia(media) {
        this.model.OnCommentedMedia(media);
    }
    SetFollowValue(value) {
        this.model.SendMessage("SetFollowValue", "Value", value);
    }
    SetCommentValue(value) {
        this.SendMessage("SetCommentValue", "Value", value);
    }
    SetLikeValue(value) {
        this.model.SendMessage("SetLikeValue", "Value", value);
    }
    SetStoryValue(value) {
        this.model.SendMessage("SetStoryValue", "Value", value);
    }
    SetUnfollowValue(value) {
        this.model.SendMessage("SetUnfollowValue", "Value", value);
    }
    WhitelistFollowings(start) {
        this.model.SendMessage("WhitelistFollowings", "Start", start);
    }
    SetWhitelistStatus(status) {
        this.model.SetWhitelistStatus(status);
    }
    RemoveWhitelistedUser(button) {
        this.model.RemoveWhitelistedUser(button);
    }
    RemoveCollectJobTagLinkedin(button) {
        this.model.RemoveCollectJobTagLinkedin(button);
    }
    RemoveCollectJobTagPinterest(button) {
        this.model.RemoveCollectJobTagPinterest(button);    
    }
    RemoveCollectJobTagTikTok(button) {
        this.model.RemoveCollectJobTagTikTok(button);
    }
    RemoveCollectJobTagfacebook(button) {
        this.model.RemoveCollectJobTagfacebook(button);
    }
    RemoveCollectJobTagTwitter(button) {
        this.model.RemoveCollectJobTagTwitter(button);
    }
    RemoveCollectJobTag(button) {
        this.model.RemoveCollectJobTag(button);
    }
    RemoveLocationJobTag(button) {
        this.model.RemoveLocationJobTag(button);
    }
    RemoveCollectJobUser(button) {
        this.model.RemoveCollectJobUser(button);
    }
    UpdateFollowers(status) {
        this.model.UpdateFollowers(status);
    }
    UpdateAccountsDict(status) {
        this.model.UpdateAccountsDict(status);
    }
    UpdateTagsDict(status) {
        this.model.UpdateTagsDict(status);
    }
    UpdateStatus(status) {
        this.model.UpdateStatus(status);
    }
    NewWhitelistUserSearch(input) {
        this.model.NewWhitelistUserSearch(input);
    }
    FilterWhitelistSearch(input) {
        this.model.FilterWhitelistSearch(input);
    }
    ClearWhitelistTable() {
        this.model.ClearWhitelistTable();
    }
    AddUserToWhitelist(input) {
        this.model.AddUserToWhitelist(input);
    }
    ProcessFilteredFollowings(users) {
        this.model.ProcessFilteredFollowings(users);
    }
    AddedWhitelistUsers(users) {
        this.model.AddedWhitelistUsers(users);
    }
    ImportDatabase(event) {
        this.model.ImportDatabase(event);
    }
    GotDatabase(database) {
        this.model.GotDatabase(database);
    }
}





