console.log('controller.js script loaded');
class Controller {
    constructor() {
        // this.master = master;
    }
    getFollowers() {
        if (CurrentUser && CurrentUser.username) {

            $(".img-current-user").attr("src", CurrentUser.user_pic_url);

            $(".img-current-user").show();


            if (gotAnalytics == false) {
                gotAnalytics = true;
                chart_data = [];
                live_snapshots = [];
                live_tags = [];
                live_accounts = [];
                var ranked_accounts = "";
                var limits = 1000;
                if (paid_sub) {
                    limits = 1000;
                    var ranked_data = [];
                    var totals = 0;

                }

                var d = new Date();
                var currentHour = d.getHours();

                var d_num = Date.parse(d);
                d_num = Math.floor(d_num / (1000 * 60 * 60));
                var dat = {
                    followers: follow_count_num,
                    hour: d_num,
                    user_id: CurrentUser.user_id,
                    mode: mode
                };
                if (follow_count_num != 0) {
                    var data = {
                        followers: follow_count_num,
                        hour: d_num,
                        user_id: CurrentUser.user_id,
                        mode: "instagram"
                    };

                    SendMessage("PostStats", "data", data);

                }

            }
            var account_name = CurrentUser.username;



        }

    }

    roughSizeOfObject(object) {

        var objectList = [];
        var stack = [object];
        var bytes = 0;

        while (stack.length) {
            var value = stack.pop();

            if (typeof value === 'boolean') {
                bytes += 4;
            } else if (typeof value === 'string') {
                bytes += value.length * 2;
            } else if (typeof value === 'number') {
                bytes += 8;
            } else if (
                typeof value === 'object' &&
                objectList.indexOf(value) === -1
            ) {
                objectList.push(value);

                for (var i in value) {
                    stack.push(value[i]);
                }
            }
        }
        return bytes;
    }

    timer(ms) {
        return new Promise(res => setTimeout(res, ms));
    }

    async sendSched() {

        var now = new Date(stopDate);
        var daysOfYear = [];
        for (var d = new Date(startDate); d <= now; d.setDate(d.getDate() + 1)) {
            await this.timer(1000);

            var td = new Date(d);
            var newD = td.toISOString().split("T")[0];

        }
    }
    
    hashCode(str) {
        return str.split('').reduce((prevHash, currVal) =>
            (((prevHash << 5) - prevHash) + currVal.charCodeAt(0)) | 0, 0);
    }
    User(username, user_id, full_name, user_pic_url, followed_time) {
        this.username = username;
        this.user_id = user_id;
        this.full_name = full_name;
        this.user_pic_url = user_pic_url;
        this.followed_time = followed_time;
    }

    CreateComPort() {
        ComPort = chrome.runtime.connect({
            name: "instafollow213index"
        });
        ComPort.onMessage.addListener(OnMessageReceive);
    }

    SendMessage(tag, msgTag, msg) {
        var sendObj = {
            "Tag": tag
        };
        sendObj[msgTag] = msg;
        if (typeof ComPort != "undefined") {
            ComPort.postMessage(sendObj);
        }
    }
    checkObject(user_id, array) {
        for (var jj = 0; jj < array.length; jj++) {
            if (array[jj].target == user_id) {
                return [array[jj]];
            }
        }

        return [];
    }

    SaveSettings() {
        var settings = {};
        settings.FollowSettings = {};
        settings.UnfollowSettings = {};
        settings.CollectFollowers = {};
        settings.CollectFollowings = {};
        settings.LikeSettings = {};
        settings.CommentSettings = {};

        settings.FollowSettings.TimeMin = follow_speed;
        settings.FollowSettings.TimeMax = follow_speed + 10;
        settings.FollowSettings.ErrorTime = 200;

        settings.UnfollowSettings.TimeMin = unfollow_speed;
        settings.UnfollowSettings.TimeMax = unfollow_speed + 10;
        settings.UnfollowSettings.ErrorTime = 200;

        settings.CommentSettings.TimeMin = comment_speed;
        settings.CommentSettings.TimeMax = 450;
        settings.CommentSettings.ErrorTime = 1800;

        settings.LikeSettings.TimeMin = like_speed;
        settings.LikeSettings.TimeMax = like_speed + 10;
        settings.LikeSettings.ErrorTime = 200;

        settings.StorySettings.TimeMin = story_speed;
        settings.StorySettings.TimeMax = story_speed + 10;
        settings.StorySettings.ErrorTime = 400;

        settings.CollectFollowers.Pool = 1000;
        settings.CollectFollowers.Interval = 100;
        settings.CollectFollowers.ErrorTime = 200;

        settings.CollectFollowings.Pool = 1000;
        settings.CollectFollowings.Interval = 100;
        settings.CollectFollowings.ErrorTime = 200;

        settings.TikTokSettings.TimeMin = tiktok_speed;
        settings.TikTokSettings.TimeMax = tiktok_speed + 10;
        settings.TikTokSettings.ErrorTime = 400;


        settings.CollectFollowers.Pool = $("#input-user-pool-num").val();
        settings.CollectFollowers.Interval = $("#input-user-collect-time").val();
        settings.CollectFollowers.ErrorTime = $("#input-user-error-time").val();

        settings.CollectFollowings.Pool = $("#input-following-pool-num").val();
        settings.CollectFollowings.Interval = $("#input-following-collect-time").val();
        settings.CollectFollowings.ErrorTime = $("#input-following-error-time").val();
        UnfollowAfterDays = $("#input-unfollow-days").val();
        settings.UnfollowAfterDays = $("#input-unfollow-days").val();
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        settings.Day = dd;
        day = dd;

        SendMessage("UpdateSettings", "Settings", settings);




    }

    UpdateMediaStatus(Status) {
        if (mode == "crm") {
            var like_block = $("#crm-table");
            linkedin_data = Status.linkedin_data;
            instagram_data = Status.instagram_data;
            var target_dic = {};
            var like_table = $(like_block).find("tbody");
            $(like_table).empty();
            var html = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td></td><td>Contact</td><td>Email</td><td>Sales</td><td>Target</td><td>Website</td><td>Twitter</td><td>Birthday</td><td>Connected</td></tr>";
            for (var i = 0; i < linkedin_data.length; i++) {
                if (typeof linkedin_data[i] != "undefined")
                    html += "<tr><td><img width='100px' src='" + linkedin_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='https://linkedin" + linkedin_data[i].url.split("linkedin")[1] + "'>" + linkedin_data[i].username + "</a></td><td><a href='#' onclick='editEmail(" + i + ")'>" + linkedin_data[i].email + "</a></td><td><a href='#' onclick='editSales(" + i + ")'>" + linkedin_data[i].sales + "</a></td><td><a href='#' onclick='editTargret(" + i + ")'>" + linkedin_data[i].target + "</a></td><td><a href='#' onclick='editWebsite(" + i + ")'>" + linkedin_data[i].website + "</a></td><td><a href='#' onclick='editTwitter(" + i + ")'>" + linkedin_data[i].twitter + "</a></td><td><a href='#' onclick='editBirthday(" + i + ")'>" + linkedin_data[i].birthday + "</a></td><td><a href='#' onclick='editConnected(" + i + ")'>" + linkedin_data[i].connected + "</a></td></tr>";
                if (linkedin_data[i].target in target_dic) {
                    target_dic[linkedin_data[i].target].leads++;
                    target_dic[linkedin_data[i].target].sales += parseInt(linkedin_data[i].sales);
                    if (linkedin_data[i].connected != "none") {
                        target_dic[linkedin_data[i].target].connected++;
                    }
                } else {
                    var did_connect = 0;
                    if (linkedin_data[i].connected != "none") {
                        did_connect = 1;
                    }


                    target_dic[linkedin_data[i].target] = {
                        leads: 1,
                        sales: parseInt(linkedin_data[i].sales),
                        connected: did_connect
                    };
                }
            }

            for (var i = 0; i < instagram_data.length; i++) {
                if (typeof instagram_data[i] != "undefined")
                    html += "<tr><td><img width='100px' src='" + instagram_data[i].img + "'></img></td><td><a target='_blank' rel='noopener noreferrer' href='" + instagram_data[i].url + "'>" + instagram_data[i].username + "</a></td><td><a href='#' onclick='editInstaEmail(" + i + ")'>" + instagram_data[i].email + "</a></td><td><a href='#' onclick='editInstaSales(" + i + ")'>" + instagram_data[i].sales + "</a></td><td><a href='#' onclick='editInstaTargret(" + i + ")'>" + instagram_data[i].target + "</a></td><td><a href='#' onclick='editInstaWebsite(" + i + ")'>" + instagram_data[i].website + "</a></td><td><a href='#' onclick='editInstaTwitter(" + i + ")'>" + instagram_data[i].twitter + "</a></td><td><a href='#' onclick='editInstaBirthday(" + i + ")'>" + instagram_data[i].birthday + "</a></td><td><a href='#' onclick='editInstaConnected(" + i + ")'>" + instagram_data[i].connected + "</a></td></tr>";
                if (instagram_data[i].target in target_dic) {
                    target_dic[instagram_data[i].target].leads++;
                    target_dic[instagram_data[i].target].sales += parseInt(instagram_data[i].sales);
                    if (instagram_data[i].connected != "none") {
                        target_dic[instagram_data[i].target].connected++;
                    }
                } else {

                    var did_connect = 0;
                    if (instagram_data[i].connected != "none") {
                        did_connect = 1;
                    }

                    target_dic[instagram_data[i].target] = {
                        leads: 1,
                        sales: parseInt(instagram_data[i].sales),
                        connected: did_connect
                    };
                }
            }
            html += "</table><script>editInstaConnected(num){ window.postMessage({mode: 'Instaconnected' ,edit: num} , '*');} editInstaBirthday(num){ window.postMessage({mode: 'Instabirthday' ,edit: num} , '*');}editInstaTwitter(num){ window.postMessage({mode: 'Instatwitter' ,edit: num} , '*');} editInstaWebsite(num){ window.postMessage({mode: 'Instawebsite' ,edit: num} , '*');} editInstaTarget(num){ window.postMessage({mode: 'Instatarget' ,edit: num} , '*');} editInstaSales(num){ window.postMessage({mode: 'Instasales' ,edit: num} , '*');}editInstaEmail(num){ window.postMessage({mode: 'Instaemail' ,edit: num} , '*');}editConnected(num){ window.postMessage({mode: 'connected' ,edit: num} , '*');} editBirthday(num){ window.postMessage({mode: 'birthday' ,edit: num} , '*');}editTwitter(num){ window.postMessage({mode: 'twitter' ,edit: num} , '*');} editWebsite(num){ window.postMessage({mode: 'website' ,edit: num} , '*');} editTarget(num){ window.postMessage({mode: 'target' ,edit: num} , '*');} editSales(num){ window.postMessage({mode: 'sales' ,edit: num} , '*');}editEmail(num){ window.postMessage({mode: 'email' ,edit: num} , '*');}</script>";


            $(like_block).prepend(html);


            var target_block = $("#target-table");
            var target_table = $(target_block).find("tbody");
            $(target_table).empty();
            var html_target = "<br><br><table style='  border: 1px solid black; padding:10px; width:100%;'><tr><td>Target</td><td>Sales</td><td>Leads</td><td>Gained Followers</td></tr>";
            for (var key in target_dic) {
                if (target_dic.hasOwnProperty(key)) {
                    html_target += "<tr><td>" + key + "</td><td>" + target_dic[key].sales + "</td><td> " + target_dic[key].leads + "</td><td>" + target_dic[key].connected + "</td></tr>";
                }

            }
            html_target += "</table>";

            $(target_block).html(html_target);

        } else
            if (mode == "instagram") {
                var like_block = $("#like-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMedias.length; i++) {
                    this.OnLikedMedia(Status.LikedMedias[i]);
                }
                var story_block = $("#story-block");
                var story_table = $(story_block).find("tbody");
                $(story_table).empty();

                for (var i = 0; i < Status.StoryMedia.length; i++) {

                    this.OnStoryMedia(Status.StoryMedia[i]);
                }


                var comment_block = $("#comment-block");
                var comment_table = $(comment_block).find("tbody");
                $(comment_table).empty();

                for (var i = 0; i < Status.CommentedMedias.length; i++) {
                    this.OnCommentedMedia(Status.CommentedMedias[i]);
                }




                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.Tags.length; i++) {
                    var index = global_tags.indexOf(Status.Tags[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.Tags[i].tag_name + "<br>");
                    }

                    var user = Status.Tags[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }
                var tag_block2 = $("#collect-locations-block");
                var tag_table2 = $(tag_block2).find("tbody");
                $(tag_table2).empty();
                for (var i = 0; i < Status.Locations.length; i++) {
                    if (index == -1) {
                    }

                    var user = Status.Locations[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-location-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table2).prepend(userRow);
                    }
                }

                var tag_block3 = $("#collect-comments-block");
                var tag_table3 = $(tag_block3).find("tbody");
                $(tag_table3).empty();
                for (var i = 0; i < Status.Comments.length; i++) {
                    if (index == -1) {
                    }

                    var user = Status.Comments[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-comment-collect" user_id="` + user + `"><i class="fas fa-times"></i></button></td>
        
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table3).prepend(userRow);
                    }
                }


            } else if (mode == "twitter") {
                var like_block = $("#like-twitter-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediaTwitter.length; i++) {
                    if (Status.LikedMediaTwitter[i]) {
                        this.OnLikedMediaTwitter(Status.LikedMediaTwitter[i]);
                    }
                }
                var follow_block = $("#follow-block-twitter");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolTwitter.length; i++) {
                    if (Status.FollowedPoolTwitter[i]) {
                        this.OnFollowedUserTwitter(Status.FollowedPoolTwitter[i]);
                    }
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagPoolTwitter.length; i++) {
                    var index = global_tags.indexOf(Status.TagPoolTwitter[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagPoolTwitter[i].tag_name + "<br>");
                    }

                    var user = Status.TagPoolTwitter[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td></td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "tiktok") {
                var like_block = $("#like-tiktok-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediaTikTok.length; i++) {
                    this.OnLikedMediaTikTok(Status.LikedMediaTikTok[i]);
                }
                var follow_block = $("#follow-block-tiktok");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolTikTok.length; i++) {
                    this.OnFollowedUserTikTok(Status.FollowedPoolTikTok[i]);
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagsTikTok.length; i++) {
                    var index = global_tags.indexOf(Status.TagsTikTok[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagsTikTok[i].tag_name + "<br>");
                    }

                    var user = Status.TagsTikTok[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "facebook") {
                var like_block = $("#like-facebook-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediafacebook.length; i++) {
                    this.OnLikedMediafacebook(Status.LikedMediafacebook[i]);
                }
                var follow_block = $("#follow-block-facebook");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolfacebook.length; i++) {
                    this.OnFollowedUserfacebook(Status.FollowedPoolfacebook[i]);
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                // console.log(Status);
                var added_tags = [];
                for (var i = 0; i < Status.Tagsfacebook.length; i++) {
                    var index = global_tags.indexOf(Status.Tagsfacebook[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.Tagsfacebook[i].tag_name + "<br>");
                    }

                    var user = Status.Tagsfacebook[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);

                    }
                }



                var tag_block = $("#collect-accounts-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                console.log(Status);
                var added_tags = [];
                for (var i = 0; i < Status.AccountPoolfacebook.length; i++) {
                    var index = global_tags.indexOf(Status.AccountPoolfacebook[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.AccountPoolfacebook[i].tag_name + "<br>");
                    }

                    var user = Status.AccountPoolfacebook[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);


                    }

                }

            } else if (mode == "pinterest") {
                var like_block = $("#like-pinterest-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.LikedMediaPinterest.length; i++) {
                    this.OnLikedMediaPinterest(Status.LikedMediaPinterest[i]);
                }
                var follow_block = $("#follow-block-pinterest");
                var follow_table = $(follow_block).find("tbody");
                $(follow_table).empty()

                for (var i = 0; i < Status.FollowedPoolPinterest.length; i++) {
                    this.OnFollowedUserPinterest(Status.FollowedPoolPinterest[i]);
                }

                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagsPinterest.length; i++) {
                    var index = global_tags.indexOf(Status.TagsPinterest[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagsPinterest[i].tag_name + "<br>");
                    }

                    var user = Status.TagsPinterest[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "linkedin") {
                var like_block = $("#like-linkedin-block");
                var like_table = $(like_block).find("tbody");
                $(like_table).empty();

                for (var i = 0; i < Status.linkedin_data.length; i++) {
                    this.OnLikedMediaLinkedin(Status.linkedin_data[i]);
                }
                var tag_block = $("#collect-tags-block");
                var tag_table = $(tag_block).find("tbody");
                $(tag_table).empty();
                var added_tags = [];
                for (var i = 0; i < Status.TagPoolLinkedin.length; i++) {
                    var index = global_tags.indexOf(Status.TagPoolLinkedin[i].tag_name + "<br>");
                    if (index == -1) {
                        global_tags.push(Status.TagPoolLinkedin[i].tag_name + "<br>");
                    }

                    var user = Status.TagPoolLinkedin[i].tag_name;
                    if (true) {
                        added_tags.push(user);

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-tag-collect" user_id='` + user + `'><i class="fas fa-times"></i></button></td>
        <td>#</td>
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table).prepend(userRow);
                    }
                }

            } else if (mode == "tinder") {

                var tag_block3 = $("#collect-comments-block");
                var tag_table3 = $(tag_block3).find("tbody");
                $(tag_table3).empty();
                for (var i = 0; i < Status.CommentsTinder.length; i++) {


                    var user = Status.CommentsTinder[i].tag_name;
                    if (true) {

                        var userRow = `
        <tr><td style="vertical-align: middle;">
        <button class="btn-danger remove-comment-collect" user_id="` + user + `"><i class="fas fa-times"></i></button></td>
        
        <td class='align-mid-vertical text-instafollow-td'>` + user + `</td>
        
        </tr>
        `;
                        $(tag_table3).prepend(userRow);
                    }
                }

            }
    }

    UpdateFollowStatus(AllUsers) {
        var FollowedUsers = AllUsers.FollowedUsers;
        var UnfollowedUsers = AllUsers.UnfollowedUsers;

        var follow_block = $("#follow-block");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).empty()

        var unfollow_block = $("#unfollow-block");
        var unfollow_table = $(unfollow_block).find("tbody");
        $(unfollow_table).empty();

        for (var i = 0; i < FollowedUsers.length; i++) {
            this.OnFollowedUser(FollowedUsers[i]);
        }

        for (var i = 0; i < UnfollowedUsers.length; i++) {
            this.OnUnfollowedUser(UnfollowedUsers[i]);
        }
    }

    OnStoryMedia(user) {
        var userRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.full_name + `(@` + user.target + `)</td>
      </tr>
      `;

        var follow_block = $("#story-block");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserTwitter(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-twitter");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserLinkedin(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-linkedin");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserPinterest(user) {
        //console.log(user);
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-pinterest");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserTikTok(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-tiktok");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUserfacebook(user) {
        var userRow = `
      <tr>
      <td><a href='` + user.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.username + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block-facebook");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnFollowedUser(user) {
        var userRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td><td class='text-instafollow-td align-mid-vertical'>` + user.full_name + `</td>
      </tr>
      `;

        var follow_block = $("#follow-block");
        var follow_table = $(follow_block).find("tbody");
        $(follow_table).prepend(userRow);

        var table_rows = $(follow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnUnfollowedUser(user) {
        ////////////console.log(user);
        var userRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + user.username + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + user.user_pic_url + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + user.username + `</td>
      </tr>
      `;

        var unfollow_block = $("#unfollow-block");
        var unfollow_table = $(unfollow_block).find("tbody");
        $(unfollow_table).prepend(userRow);

        var table_rows = $(unfollow_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayFollowersNum) {
            var start_delete = num_rows - (num_rows - DisplayFollowersNum);
            $(table_rows).slice(start_delete).remove();
        }

    }

    OnLikedMediaLinkedin(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='https://linkedin` + media.url.split("linkedin")[1] + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-linkedin-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaTwitter(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-twitter-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaTinder(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='https://` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-tinder-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaPinterest(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-pinterest-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediaTikTok(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-tiktok-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMediafacebook(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='` + media.url + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.img + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.username + `</td>
      </tr>
      `;

        var like_bock = $("#like-facebook-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnLikedMedia(media) {
        likeCount++;
        var mediaRow = `
      <tr>
      <td><a href='https://www.instagram.com/` + media.shortcode + `/' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'   src='` + media.media_src + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.shortcode + `</td>
      </tr>
      `;

        var like_bock = $("#like-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }

    OnCommentedMedia(media) {
        var mediaRow = `
      <tr>
      <td><a href='https://www.instagram.com` + media.shortcode + `' target='_blank'><img class='backup_picture img-rounded' width='64' height='64'    src='` + media.media_src + `'/></a></td>
      <td class='align-mid-vertical text-instafollow-td'>` + media.caption + `</td>
      </tr>
      `;

        var like_bock = $("#comment-block");
        var like_table = $(like_bock).find("tbody");
        $(like_table).prepend(mediaRow);

        var table_rows = $(like_table).find("tr");
        var num_rows = table_rows.length;
        if (num_rows > DisplayLikesNum) {
            var start_delete = num_rows - (num_rows - DisplayLikesNum);
            $(table_rows).slice(start_delete).remove();
        }
    }
}





