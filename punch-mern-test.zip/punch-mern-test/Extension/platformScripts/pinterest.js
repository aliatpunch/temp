console.log('pinterest.js script loaded');

class PinterestModel {
    constructor() {
        this.ComPort = null;
        this.CurrentUser = null;
        this.LastUsername = "";
        this.SharedData = null;
        this.UserTag = "._7UhW9";
        this.StartStory = false;
        this.msg_user = "";
        this.tag_dict = {};
        this.account_dict = {};
        this.that = this;
        this.image_src = "";
        this.story_set = false;
    }

    CreateComPort() {
        this.ComPort = chrome.runtime.connect({
            name: "pinterest"
        });
        this.ComPort.onMessage.addListener(this.OnMessageReceive.bind(this));

        window.addEventListener("message", (event) => {
            if (event.source != window) return;
            if (event.data.Tag && (event.data.Tag == "SharedData")) {
                this.SharedData = event.data.SharedData;
            }
        }, false);
    }

    OnMessageReceive(msg) {
        console.log(msg);

        if (msg.Tag == "UpdatePinterest") {
            const videos = document.getElementsByTagName('a');
            for (let kk = 0; kk < videos.length; kk++) {
                if (videos[kk].getAttribute("class").includes("result-item")) {
                    this.SendMessage("PinterestTarget", "target", videos[kk].getAttribute("href"));
                }
            }
        } else if (msg.Tag == "LikeFollow") {
            this.SendMessage("DonePinterest", "target", window.location.href);
            const vid = parseInt(Math.floor(Math.random() * 20) + 1);
            let counter = 0;
            const videos = document.getElementsByTagName('a');
            for (let kk = 0; kk < videos.length; kk++) {
                if (videos[kk].getAttribute("href") && videos[kk].getAttribute("href").includes("/pin/")) {
                    counter++;
                    if (counter == vid) {
                        videos[kk].click();
                        setTimeout(() => {
                            this.handleLikeFollow(msg);
                        }, 5000);
                        break;
                    }
                }
            }
        }
    }

    handleLikeFollow(msg) {
        let username = window.location.href.split("/")[3];
        const url = window.location.href;
        let img = "https://instoo.com/logo.png";
        const images = document.getElementsByTagName('img');
        let counter = 0;
        for (let kk = 0; kk < images.length; kk++) {
            if (images[kk].getAttribute("src") && images[kk].getAttribute("src").includes("pinimg")) {
                counter++;
                if (counter == 2) {
                    img = images[kk].src;
                    break;
                }
            }
        }

        const divs = document.getElementsByTagName('div');
        for (let kk = 0; kk < divs.length; kk++) {
            if (divs[kk].getAttribute("data-test-id") && divs[kk].getAttribute("data-test-id").includes("creator-profile-name")) {
                username = divs[kk].innerText;
                break;
            }
        }

        const msg_data = {
            url: url,
            username: username,
            img: img,
            website: "none",
            twitter: "none",
            sales: 0,
            email: "none",
            connected: "none"
        };
        console.log(msg_data);
        this.SendMessage("DonePinterestData", "User", msg_data);

        if (msg.story.StartPinterestFollow && msg.story.FollowedPoolPinterestSize < msg.story.MaxPinterestFollows) {
            const buttons = document.getElementsByTagName('button');
            for (let jj = 0; jj < buttons.length; jj++) {
                if (buttons[jj].innerText.includes("Follow") && !buttons[jj].innerText.includes("Following")) {
                    buttons[jj].click();
                    break;
                }
            }

            const msg_data_follow = {
                url: url,
                username: username,
                img: img
            };
            this.SendMessage("DonePinterestFollow", "User", msg_data_follow);
        }

        if (msg.story.StartPinterestLike && msg.story.LikedMediaPinterestSize < msg.story.MaxPinterestLikes) {
            setTimeout(() => {
                const divs = document.getElementsByTagName('div');
                for (let jj = 0; jj < divs.length; jj++) {
                    if (divs[jj].getAttribute("class") && divs[jj].getAttribute("class").includes("engagement-icon")) {
                        divs[jj].click();
                        break;
                    }
                }
                const buttons = document.getElementsByTagName('button');
                for (let jj = 0; jj < buttons.length; jj++) {
                    if (buttons[jj].getAttribute("aria-label") && buttons[jj].getAttribute("aria-label").includes("reaction")) {
                        buttons[jj].click();
                        break;
                    }
                }
                const msg_data_like = {
                    url: url,
                    username: username,
                    img: img
                };
                this.SendMessage("DonePinterestLike", "User", msg_data_like);
            }, 4000);
        }
    }

    SendMessage(tag, msgTag, msg) {
        const sendObj = { "Tag": tag };
        sendObj[msgTag] = msg;
        this.ComPort.postMessage(sendObj);
    }
}

class PinterestView {
    constructor(controller) {
        this.controller = controller;
        $(document).ready(this.onDocumentReady.bind(this));
    }

    onDocumentReady() {
        this.controller.CreateComPort();
        console.log("SETUp!");
        if (window.location.href.includes("videos")) {
            window.scrollTo(0, document.body.scrollHeight);
            this.controller.SendMessage("GetPinterest", "target", "");
        }
    }
}

class PinterestController {
    constructor(model) {
        this.model = model;
    }

    CreateComPort() {
        this.model.CreateComPort();
    }

    SendMessage(tag, msgTag, msg) {
        this.model.SendMessage(tag, msgTag, msg);
    }
}

const model = new PinterestModel();
const controller = new PinterestController(model);
const view = new PinterestView(controller);