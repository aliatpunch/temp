# AutoBaiter
Bait them and Gain Them

Gain Autogram Followers for Free.  
Features:   
    ► Choose a user to collect followers.   
    ► Schedule unfollow.   
    ► Whitelist users.   
    ► Export or import database.   
    ► Allows multiple users.
